(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_22482330._.js",
  "static/chunks/8fc7d_next_dist_compiled_react-dom_136125f1._.js",
  "static/chunks/8fc7d_next_dist_compiled_next-devtools_index_cd8f740e.js",
  "static/chunks/8fc7d_next_dist_compiled_cba3ee4e._.js",
  "static/chunks/8fc7d_next_dist_client_634f429a._.js",
  "static/chunks/8fc7d_next_dist_4a5f466b._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
