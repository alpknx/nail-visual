(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
            case REACT_ACTIVITY_TYPE:
                return "Activity";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_CONTEXT_TYPE:
                return type.displayName || "Context";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function getTaskName(type) {
        if (type === REACT_FRAGMENT_TYPE) return "<>";
        if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
        try {
            var name = getComponentNameFromType(type);
            return name ? "<" + name + ">" : "<...>";
        } catch (x) {
            return "<...>";
        }
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
        return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
        var refProp = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.defineProperty(type, "_debugStack", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugStack
        });
        Object.defineProperty(type, "_debugTask", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: debugTask
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
        var children = config.children;
        if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
            for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren]);
            Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
        else validateChildKeys(children);
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
        "object" === typeof node && null !== node && node.$$typeof === REACT_ELEMENT_TYPE && node._store && (node._store.validated = 1);
    }
    var React = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_ACTIVITY_TYPE = Symbol.for("react.activity"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, isArrayImpl = Array.isArray, createTask = console.createTask ? console.createTask : function() {
        return null;
    };
    React = {
        react_stack_bottom_frame: function(callStackForError) {
            return callStackForError();
        }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren) {
        var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, trackActualOwner ? Error("react-stack-top-frame") : unknownOwnerDebugStack, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
}();
}),
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/router/utils/querystring.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    assign: null,
    searchParamsToUrlQuery: null,
    urlQueryToSearchParams: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    assign: function() {
        return assign;
    },
    searchParamsToUrlQuery: function() {
        return searchParamsToUrlQuery;
    },
    urlQueryToSearchParams: function() {
        return urlQueryToSearchParams;
    }
});
function searchParamsToUrlQuery(searchParams) {
    const query = {};
    for (const [key, value] of searchParams.entries()){
        const existing = query[key];
        if (typeof existing === 'undefined') {
            query[key] = value;
        } else if (Array.isArray(existing)) {
            existing.push(value);
        } else {
            query[key] = [
                existing,
                value
            ];
        }
    }
    return query;
}
function stringifyUrlQueryParam(param) {
    if (typeof param === 'string') {
        return param;
    }
    if (typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
        return String(param);
    } else {
        return '';
    }
}
function urlQueryToSearchParams(query) {
    const searchParams = new URLSearchParams();
    for (const [key, value] of Object.entries(query)){
        if (Array.isArray(value)) {
            for (const item of value){
                searchParams.append(key, stringifyUrlQueryParam(item));
            }
        } else {
            searchParams.set(key, stringifyUrlQueryParam(value));
        }
    }
    return searchParams;
}
function assign(target) {
    for(var _len = arguments.length, searchParamsList = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
        searchParamsList[_key - 1] = arguments[_key];
    }
    for (const searchParams of searchParamsList){
        for (const key of searchParams.keys()){
            target.delete(key);
        }
        for (const [key, value] of searchParams.entries()){
            target.append(key, value);
        }
    }
    return target;
} //# sourceMappingURL=querystring.js.map
}),
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/router/utils/format-url.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    formatUrl: null,
    formatWithValidation: null,
    urlObjectKeys: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    formatUrl: function() {
        return formatUrl;
    },
    formatWithValidation: function() {
        return formatWithValidation;
    },
    urlObjectKeys: function() {
        return urlObjectKeys;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _querystring = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/router/utils/querystring.js [app-client] (ecmascript)"));
const slashedProtocols = /https?|ftp|gopher|file/;
function formatUrl(urlObj) {
    let { auth, hostname } = urlObj;
    let protocol = urlObj.protocol || '';
    let pathname = urlObj.pathname || '';
    let hash = urlObj.hash || '';
    let query = urlObj.query || '';
    let host = false;
    auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';
    if (urlObj.host) {
        host = auth + urlObj.host;
    } else if (hostname) {
        host = auth + (~hostname.indexOf(':') ? "[" + hostname + "]" : hostname);
        if (urlObj.port) {
            host += ':' + urlObj.port;
        }
    }
    if (query && typeof query === 'object') {
        query = String(_querystring.urlQueryToSearchParams(query));
    }
    let search = urlObj.search || query && "?" + query || '';
    if (protocol && !protocol.endsWith(':')) protocol += ':';
    if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
        host = '//' + (host || '');
        if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
    } else if (!host) {
        host = '';
    }
    if (hash && hash[0] !== '#') hash = '#' + hash;
    if (search && search[0] !== '?') search = '?' + search;
    pathname = pathname.replace(/[?#]/g, encodeURIComponent);
    search = search.replace('#', '%23');
    return "" + protocol + host + pathname + search + hash;
}
const urlObjectKeys = [
    'auth',
    'hash',
    'host',
    'hostname',
    'href',
    'path',
    'pathname',
    'port',
    'protocol',
    'query',
    'search',
    'slashes'
];
function formatWithValidation(url) {
    if ("TURBOPACK compile-time truthy", 1) {
        if (url !== null && typeof url === 'object') {
            Object.keys(url).forEach((key)=>{
                if (!urlObjectKeys.includes(key)) {
                    console.warn("Unknown key passed via urlObject into url.format: " + key);
                }
            });
        }
    }
    return formatUrl(url);
} //# sourceMappingURL=format-url.js.map
}),
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/use-merged-ref.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useMergedRef", {
    enumerable: true,
    get: function() {
        return useMergedRef;
    }
});
const _react = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
function useMergedRef(refA, refB) {
    const cleanupA = (0, _react.useRef)(null);
    const cleanupB = (0, _react.useRef)(null);
    // NOTE: In theory, we could skip the wrapping if only one of the refs is non-null.
    // (this happens often if the user doesn't pass a ref to Link/Form/Image)
    // But this can cause us to leak a cleanup-ref into user code (e.g. via `<Link legacyBehavior>`),
    // and the user might pass that ref into ref-merging library that doesn't support cleanup refs
    // (because it hasn't been updated for React 19)
    // which can then cause things to blow up, because a cleanup-returning ref gets called with `null`.
    // So in practice, it's safer to be defensive and always wrap the ref, even on React 19.
    return (0, _react.useCallback)((current)=>{
        if (current === null) {
            const cleanupFnA = cleanupA.current;
            if (cleanupFnA) {
                cleanupA.current = null;
                cleanupFnA();
            }
            const cleanupFnB = cleanupB.current;
            if (cleanupFnB) {
                cleanupB.current = null;
                cleanupFnB();
            }
        } else {
            if (refA) {
                cleanupA.current = applyRef(refA, current);
            }
            if (refB) {
                cleanupB.current = applyRef(refB, current);
            }
        }
    }, [
        refA,
        refB
    ]);
}
function applyRef(refA, current) {
    if (typeof refA === 'function') {
        const cleanup = refA(current);
        if (typeof cleanup === 'function') {
            return cleanup;
        } else {
            return ()=>refA(null);
        }
    } else {
        refA.current = current;
        return ()=>{
            refA.current = null;
        };
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=use-merged-ref.js.map
}),
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    DecodeError: null,
    MiddlewareNotFoundError: null,
    MissingStaticPage: null,
    NormalizeError: null,
    PageNotFoundError: null,
    SP: null,
    ST: null,
    WEB_VITALS: null,
    execOnce: null,
    getDisplayName: null,
    getLocationOrigin: null,
    getURL: null,
    isAbsoluteUrl: null,
    isResSent: null,
    loadGetInitialProps: null,
    normalizeRepeatedSlashes: null,
    stringifyError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    DecodeError: function() {
        return DecodeError;
    },
    MiddlewareNotFoundError: function() {
        return MiddlewareNotFoundError;
    },
    MissingStaticPage: function() {
        return MissingStaticPage;
    },
    NormalizeError: function() {
        return NormalizeError;
    },
    PageNotFoundError: function() {
        return PageNotFoundError;
    },
    SP: function() {
        return SP;
    },
    ST: function() {
        return ST;
    },
    WEB_VITALS: function() {
        return WEB_VITALS;
    },
    execOnce: function() {
        return execOnce;
    },
    getDisplayName: function() {
        return getDisplayName;
    },
    getLocationOrigin: function() {
        return getLocationOrigin;
    },
    getURL: function() {
        return getURL;
    },
    isAbsoluteUrl: function() {
        return isAbsoluteUrl;
    },
    isResSent: function() {
        return isResSent;
    },
    loadGetInitialProps: function() {
        return loadGetInitialProps;
    },
    normalizeRepeatedSlashes: function() {
        return normalizeRepeatedSlashes;
    },
    stringifyError: function() {
        return stringifyError;
    }
});
const WEB_VITALS = [
    'CLS',
    'FCP',
    'FID',
    'INP',
    'LCP',
    'TTFB'
];
function execOnce(fn) {
    let used = false;
    let result;
    return function() {
        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
            args[_key] = arguments[_key];
        }
        if (!used) {
            used = true;
            result = fn(...args);
        }
        return result;
    };
}
// Scheme: https://tools.ietf.org/html/rfc3986#section-3.1
// Absolute URL: https://tools.ietf.org/html/rfc3986#section-4.3
const ABSOLUTE_URL_REGEX = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/;
const isAbsoluteUrl = (url)=>ABSOLUTE_URL_REGEX.test(url);
function getLocationOrigin() {
    const { protocol, hostname, port } = window.location;
    return protocol + "//" + hostname + (port ? ':' + port : '');
}
function getURL() {
    const { href } = window.location;
    const origin = getLocationOrigin();
    return href.substring(origin.length);
}
function getDisplayName(Component) {
    return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}
function isResSent(res) {
    return res.finished || res.headersSent;
}
function normalizeRepeatedSlashes(url) {
    const urlParts = url.split('?');
    const urlNoQuery = urlParts[0];
    return urlNoQuery // first we replace any non-encoded backslashes with forward
    // then normalize repeated forward slashes
    .replace(/\\/g, '/').replace(/\/\/+/g, '/') + (urlParts[1] ? "?" + urlParts.slice(1).join('?') : '');
}
async function loadGetInitialProps(App, ctx) {
    if ("TURBOPACK compile-time truthy", 1) {
        var _App_prototype;
        if ((_App_prototype = App.prototype) == null ? void 0 : _App_prototype.getInitialProps) {
            const message = '"' + getDisplayName(App) + '.getInitialProps()" is defined as an instance method - visit https://nextjs.org/docs/messages/get-initial-props-as-an-instance-method for more information.';
            throw Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
                value: "E394",
                enumerable: false,
                configurable: true
            });
        }
    }
    // when called from _app `ctx` is nested in `ctx`
    const res = ctx.res || ctx.ctx && ctx.ctx.res;
    if (!App.getInitialProps) {
        if (ctx.ctx && ctx.Component) {
            // @ts-ignore pageProps default
            return {
                pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
            };
        }
        return {};
    }
    const props = await App.getInitialProps(ctx);
    if (res && isResSent(res)) {
        return props;
    }
    if (!props) {
        const message = '"' + getDisplayName(App) + '.getInitialProps()" should resolve to an object. But found "' + props + '" instead.';
        throw Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
    }
    if ("TURBOPACK compile-time truthy", 1) {
        if (Object.keys(props).length === 0 && !ctx.ctx) {
            console.warn("" + getDisplayName(App) + " returned an empty object from `getInitialProps`. This de-optimizes and prevents automatic static optimization. https://nextjs.org/docs/messages/empty-object-getInitialProps");
        }
    }
    return props;
}
const SP = typeof performance !== 'undefined';
const ST = SP && [
    'mark',
    'measure',
    'getEntriesByName'
].every((method)=>typeof performance[method] === 'function');
class DecodeError extends Error {
}
class NormalizeError extends Error {
}
class PageNotFoundError extends Error {
    constructor(page){
        super();
        this.code = 'ENOENT';
        this.name = 'PageNotFoundError';
        this.message = "Cannot find module for page: " + page;
    }
}
class MissingStaticPage extends Error {
    constructor(page, message){
        super();
        this.message = "Failed to load static file for page: " + page + " " + message;
    }
}
class MiddlewareNotFoundError extends Error {
    constructor(){
        super();
        this.code = 'ENOENT';
        this.message = "Cannot find the middleware module";
    }
}
function stringifyError(error) {
    return JSON.stringify({
        message: error.message,
        stack: error.stack
    });
} //# sourceMappingURL=utils.js.map
}),
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/router/utils/is-local-url.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "isLocalURL", {
    enumerable: true,
    get: function() {
        return isLocalURL;
    }
});
const _utils = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/utils.js [app-client] (ecmascript)");
const _hasbasepath = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/has-base-path.js [app-client] (ecmascript)");
function isLocalURL(url) {
    // prevent a hydration mismatch on href for url with anchor refs
    if (!(0, _utils.isAbsoluteUrl)(url)) return true;
    try {
        // absolute urls can be local if they are on the same origin
        const locationOrigin = (0, _utils.getLocationOrigin)();
        const resolved = new URL(url, locationOrigin);
        return resolved.origin === locationOrigin && (0, _hasbasepath.hasBasePath)(resolved.pathname);
    } catch (_) {
        return false;
    }
} //# sourceMappingURL=is-local-url.js.map
}),
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/utils/error-once.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "errorOnce", {
    enumerable: true,
    get: function() {
        return errorOnce;
    }
});
let errorOnce = (_)=>{};
if ("TURBOPACK compile-time truthy", 1) {
    const errors = new Set();
    errorOnce = (msg)=>{
        if (!errors.has(msg)) {
            console.error(msg);
        }
        errors.add(msg);
    };
} //# sourceMappingURL=error-once.js.map
}),
"[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    default: null,
    useLinkStatus: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    /**
 * A React component that extends the HTML `<a>` element to provide
 * [prefetching](https://nextjs.org/docs/app/building-your-application/routing/linking-and-navigating#2-prefetching)
 * and client-side navigation. This is the primary way to navigate between routes in Next.js.
 *
 * @remarks
 * - Prefetching is only enabled in production.
 *
 * @see https://nextjs.org/docs/app/api-reference/components/link
 */ default: function() {
        return LinkComponent;
    },
    useLinkStatus: function() {
        return useLinkStatus;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _formaturl = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/router/utils/format-url.js [app-client] (ecmascript)");
const _approutercontextsharedruntime = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)");
const _usemergedref = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/use-merged-ref.js [app-client] (ecmascript)");
const _utils = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/utils.js [app-client] (ecmascript)");
const _addbasepath = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/add-base-path.js [app-client] (ecmascript)");
const _warnonce = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/utils/warn-once.js [app-client] (ecmascript)");
const _links = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/components/links.js [app-client] (ecmascript)");
const _islocalurl = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/router/utils/is-local-url.js [app-client] (ecmascript)");
const _approuterinstance = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/components/app-router-instance.js [app-client] (ecmascript)");
const _erroronce = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/shared/lib/utils/error-once.js [app-client] (ecmascript)");
const _segmentcache = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/client/components/segment-cache.js [app-client] (ecmascript)");
function isModifiedEvent(event) {
    const eventTarget = event.currentTarget;
    const target = eventTarget.getAttribute('target');
    return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
    event.nativeEvent && event.nativeEvent.which === 2;
}
function linkClicked(e, href, as, linkInstanceRef, replace, scroll, onNavigate) {
    const { nodeName } = e.currentTarget;
    // anchors inside an svg have a lowercase nodeName
    const isAnchorNodeName = nodeName.toUpperCase() === 'A';
    if (isAnchorNodeName && isModifiedEvent(e) || e.currentTarget.hasAttribute('download')) {
        // ignore click for browser’s default behavior
        return;
    }
    if (!(0, _islocalurl.isLocalURL)(href)) {
        if (replace) {
            // browser default behavior does not replace the history state
            // so we need to do it manually
            e.preventDefault();
            location.replace(href);
        }
        // ignore click for browser’s default behavior
        return;
    }
    e.preventDefault();
    if (onNavigate) {
        let isDefaultPrevented = false;
        onNavigate({
            preventDefault: ()=>{
                isDefaultPrevented = true;
            }
        });
        if (isDefaultPrevented) {
            return;
        }
    }
    _react.default.startTransition(()=>{
        (0, _approuterinstance.dispatchNavigateAction)(as || href, replace ? 'replace' : 'push', scroll != null ? scroll : true, linkInstanceRef.current);
    });
}
function formatStringOrUrl(urlObjOrString) {
    if (typeof urlObjOrString === 'string') {
        return urlObjOrString;
    }
    return (0, _formaturl.formatUrl)(urlObjOrString);
}
function LinkComponent(props) {
    const [linkStatus, setOptimisticLinkStatus] = (0, _react.useOptimistic)(_links.IDLE_LINK_STATUS);
    let children;
    const linkInstanceRef = (0, _react.useRef)(null);
    const { href: hrefProp, as: asProp, children: childrenProp, prefetch: prefetchProp = null, passHref, replace, shallow, scroll, onClick, onMouseEnter: onMouseEnterProp, onTouchStart: onTouchStartProp, legacyBehavior = false, onNavigate, ref: forwardedRef, unstable_dynamicOnHover, ...restProps } = props;
    children = childrenProp;
    if (legacyBehavior && (typeof children === 'string' || typeof children === 'number')) {
        children = /*#__PURE__*/ (0, _jsxruntime.jsx)("a", {
            children: children
        });
    }
    const router = _react.default.useContext(_approutercontextsharedruntime.AppRouterContext);
    const prefetchEnabled = prefetchProp !== false;
    const fetchStrategy = prefetchProp !== false ? getFetchStrategyFromPrefetchProp(prefetchProp) : _segmentcache.FetchStrategy.PPR;
    if ("TURBOPACK compile-time truthy", 1) {
        function createPropError(args) {
            return Object.defineProperty(new Error("Failed prop type: The prop `" + args.key + "` expects a " + args.expected + " in `<Link>`, but got `" + args.actual + "` instead." + (typeof window !== 'undefined' ? "\nOpen your browser's console to view the Component stack trace." : '')), "__NEXT_ERROR_CODE", {
                value: "E319",
                enumerable: false,
                configurable: true
            });
        }
        // TypeScript trick for type-guarding:
        const requiredPropsGuard = {
            href: true
        };
        const requiredProps = Object.keys(requiredPropsGuard);
        requiredProps.forEach((key)=>{
            if (key === 'href') {
                if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
                    throw createPropError({
                        key,
                        expected: '`string` or `object`',
                        actual: props[key] === null ? 'null' : typeof props[key]
                    });
                }
            } else {
                // TypeScript trick for type-guarding:
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const _ = key;
            }
        });
        // TypeScript trick for type-guarding:
        const optionalPropsGuard = {
            as: true,
            replace: true,
            scroll: true,
            shallow: true,
            passHref: true,
            prefetch: true,
            unstable_dynamicOnHover: true,
            onClick: true,
            onMouseEnter: true,
            onTouchStart: true,
            legacyBehavior: true,
            onNavigate: true
        };
        const optionalProps = Object.keys(optionalPropsGuard);
        optionalProps.forEach((key)=>{
            const valType = typeof props[key];
            if (key === 'as') {
                if (props[key] && valType !== 'string' && valType !== 'object') {
                    throw createPropError({
                        key,
                        expected: '`string` or `object`',
                        actual: valType
                    });
                }
            } else if (key === 'onClick' || key === 'onMouseEnter' || key === 'onTouchStart' || key === 'onNavigate') {
                if (props[key] && valType !== 'function') {
                    throw createPropError({
                        key,
                        expected: '`function`',
                        actual: valType
                    });
                }
            } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'legacyBehavior' || key === 'unstable_dynamicOnHover') {
                if (props[key] != null && valType !== 'boolean') {
                    throw createPropError({
                        key,
                        expected: '`boolean`',
                        actual: valType
                    });
                }
            } else if (key === 'prefetch') {
                if (props[key] != null && valType !== 'boolean' && props[key] !== 'auto' && props[key] !== 'unstable_forceStale') {
                    throw createPropError({
                        key,
                        expected: '`boolean | "auto" | "unstable_forceStale"`',
                        actual: valType
                    });
                }
            } else {
                // TypeScript trick for type-guarding:
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const _ = key;
            }
        });
    }
    if ("TURBOPACK compile-time truthy", 1) {
        if (props.locale) {
            (0, _warnonce.warnOnce)('The `locale` prop is not supported in `next/link` while using the `app` router. Read more about app router internalization: https://nextjs.org/docs/app/building-your-application/routing/internationalization');
        }
        if (!asProp) {
            let href;
            if (typeof hrefProp === 'string') {
                href = hrefProp;
            } else if (typeof hrefProp === 'object' && typeof hrefProp.pathname === 'string') {
                href = hrefProp.pathname;
            }
            if (href) {
                const hasDynamicSegment = href.split('/').some((segment)=>segment.startsWith('[') && segment.endsWith(']'));
                if (hasDynamicSegment) {
                    throw Object.defineProperty(new Error("Dynamic href `" + href + "` found in <Link> while using the `/app` router, this is not supported. Read more: https://nextjs.org/docs/messages/app-dir-dynamic-href"), "__NEXT_ERROR_CODE", {
                        value: "E267",
                        enumerable: false,
                        configurable: true
                    });
                }
            }
        }
    }
    const { href, as } = _react.default.useMemo({
        "LinkComponent.useMemo": ()=>{
            const resolvedHref = formatStringOrUrl(hrefProp);
            return {
                href: resolvedHref,
                as: asProp ? formatStringOrUrl(asProp) : resolvedHref
            };
        }
    }["LinkComponent.useMemo"], [
        hrefProp,
        asProp
    ]);
    // This will return the first child, if multiple are provided it will throw an error
    let child;
    if (legacyBehavior) {
        if ("TURBOPACK compile-time truthy", 1) {
            if (onClick) {
                console.warn('"onClick" was passed to <Link> with `href` of `' + hrefProp + '` but "legacyBehavior" was set. The legacy behavior requires onClick be set on the child of next/link');
            }
            if (onMouseEnterProp) {
                console.warn('"onMouseEnter" was passed to <Link> with `href` of `' + hrefProp + '` but "legacyBehavior" was set. The legacy behavior requires onMouseEnter be set on the child of next/link');
            }
            try {
                child = _react.default.Children.only(children);
            } catch (err) {
                if (!children) {
                    throw Object.defineProperty(new Error("No children were passed to <Link> with `href` of `" + hrefProp + "` but one child is required https://nextjs.org/docs/messages/link-no-children"), "__NEXT_ERROR_CODE", {
                        value: "E320",
                        enumerable: false,
                        configurable: true
                    });
                }
                throw Object.defineProperty(new Error("Multiple children were passed to <Link> with `href` of `" + hrefProp + "` but only one child is supported https://nextjs.org/docs/messages/link-multiple-children" + (typeof window !== 'undefined' ? " \nOpen your browser's console to view the Component stack trace." : '')), "__NEXT_ERROR_CODE", {
                    value: "E266",
                    enumerable: false,
                    configurable: true
                });
            }
        } else //TURBOPACK unreachable
        ;
    } else {
        if ("TURBOPACK compile-time truthy", 1) {
            if ((children == null ? void 0 : children.type) === 'a') {
                throw Object.defineProperty(new Error('Invalid <Link> with <a> child. Please remove <a> or use <Link legacyBehavior>.\nLearn more: https://nextjs.org/docs/messages/invalid-new-link-with-extra-anchor'), "__NEXT_ERROR_CODE", {
                    value: "E209",
                    enumerable: false,
                    configurable: true
                });
            }
        }
    }
    const childRef = legacyBehavior ? child && typeof child === 'object' && child.ref : forwardedRef;
    // Use a callback ref to attach an IntersectionObserver to the anchor tag on
    // mount. In the future we will also use this to keep track of all the
    // currently mounted <Link> instances, e.g. so we can re-prefetch them after
    // a revalidation or refresh.
    const observeLinkVisibilityOnMount = _react.default.useCallback({
        "LinkComponent.useCallback[observeLinkVisibilityOnMount]": (element)=>{
            if (router !== null) {
                linkInstanceRef.current = (0, _links.mountLinkInstance)(element, href, router, fetchStrategy, prefetchEnabled, setOptimisticLinkStatus);
            }
            return ({
                "LinkComponent.useCallback[observeLinkVisibilityOnMount]": ()=>{
                    if (linkInstanceRef.current) {
                        (0, _links.unmountLinkForCurrentNavigation)(linkInstanceRef.current);
                        linkInstanceRef.current = null;
                    }
                    (0, _links.unmountPrefetchableInstance)(element);
                }
            })["LinkComponent.useCallback[observeLinkVisibilityOnMount]"];
        }
    }["LinkComponent.useCallback[observeLinkVisibilityOnMount]"], [
        prefetchEnabled,
        href,
        router,
        fetchStrategy,
        setOptimisticLinkStatus
    ]);
    const mergedRef = (0, _usemergedref.useMergedRef)(observeLinkVisibilityOnMount, childRef);
    const childProps = {
        ref: mergedRef,
        onClick (e) {
            if ("TURBOPACK compile-time truthy", 1) {
                if (!e) {
                    throw Object.defineProperty(new Error('Component rendered inside next/link has to pass click event to "onClick" prop.'), "__NEXT_ERROR_CODE", {
                        value: "E312",
                        enumerable: false,
                        configurable: true
                    });
                }
            }
            if (!legacyBehavior && typeof onClick === 'function') {
                onClick(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onClick === 'function') {
                child.props.onClick(e);
            }
            if (!router) {
                return;
            }
            if (e.defaultPrevented) {
                return;
            }
            linkClicked(e, href, as, linkInstanceRef, replace, scroll, onNavigate);
        },
        onMouseEnter (e) {
            if (!legacyBehavior && typeof onMouseEnterProp === 'function') {
                onMouseEnterProp(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onMouseEnter === 'function') {
                child.props.onMouseEnter(e);
            }
            if (!router) {
                return;
            }
            if ("TURBOPACK compile-time truthy", 1) {
                return;
            }
            //TURBOPACK unreachable
            ;
            const upgradeToDynamicPrefetch = undefined;
        },
        onTouchStart: ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : function onTouchStart(e) {
            if (!legacyBehavior && typeof onTouchStartProp === 'function') {
                onTouchStartProp(e);
            }
            if (legacyBehavior && child.props && typeof child.props.onTouchStart === 'function') {
                child.props.onTouchStart(e);
            }
            if (!router) {
                return;
            }
            if (!prefetchEnabled) {
                return;
            }
            const upgradeToDynamicPrefetch = unstable_dynamicOnHover === true;
            (0, _links.onNavigationIntent)(e.currentTarget, upgradeToDynamicPrefetch);
        }
    };
    // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
    // defined, we specify the current 'href', so that repetition is not needed by the user.
    // If the url is absolute, we can bypass the logic to prepend the basePath.
    if ((0, _utils.isAbsoluteUrl)(as)) {
        childProps.href = as;
    } else if (!legacyBehavior || passHref || child.type === 'a' && !('href' in child.props)) {
        childProps.href = (0, _addbasepath.addBasePath)(as);
    }
    let link;
    if (legacyBehavior) {
        if ("TURBOPACK compile-time truthy", 1) {
            (0, _erroronce.errorOnce)('`legacyBehavior` is deprecated and will be removed in a future ' + 'release. A codemod is available to upgrade your components:\n\n' + 'npx @next/codemod@latest new-link .\n\n' + 'Learn more: https://nextjs.org/docs/app/building-your-application/upgrading/codemods#remove-a-tags-from-link-components');
        }
        link = /*#__PURE__*/ _react.default.cloneElement(child, childProps);
    } else {
        link = /*#__PURE__*/ (0, _jsxruntime.jsx)("a", {
            ...restProps,
            ...childProps,
            children: children
        });
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(LinkStatusContext.Provider, {
        value: linkStatus,
        children: link
    });
}
const LinkStatusContext = /*#__PURE__*/ (0, _react.createContext)(_links.IDLE_LINK_STATUS);
const useLinkStatus = ()=>{
    return (0, _react.useContext)(LinkStatusContext);
};
function getFetchStrategyFromPrefetchProp(prefetchProp) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        return prefetchProp === null || prefetchProp === 'auto' ? _segmentcache.FetchStrategy.PPR : // (although invalid values should've been filtered out by prop validation in dev)
        _segmentcache.FetchStrategy.Full;
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=link.js.map
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/interopRequireDefault.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        "default": e
    };
}
module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/typeof.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _typeof(o) {
    "@babel/helpers - typeof";
    return module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
        return typeof o;
    } : function(o) {
        return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof(o);
}
module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/OverloadYield.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _OverloadYield(e, d) {
    this.v = e, this.k = d;
}
module.exports = _OverloadYield, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorDefine.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _regeneratorDefine(e, r, n, t) {
    var i = Object.defineProperty;
    try {
        i({}, "", {});
    } catch (e) {
        i = 0;
    }
    module.exports = _regeneratorDefine = function regeneratorDefine(e, r, n, t) {
        function o(r, n) {
            _regeneratorDefine(e, r, function(e) {
                return this._invoke(r, n, e);
            });
        }
        r ? i ? i(e, r, {
            value: n,
            enumerable: !t,
            configurable: !t,
            writable: !t
        }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2));
    }, module.exports.__esModule = true, module.exports["default"] = module.exports, _regeneratorDefine(e, r, n, t);
}
module.exports = _regeneratorDefine, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regenerator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var regeneratorDefine = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorDefine.js [app-client] (ecmascript)");
function _regenerator() {
    /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag";
    function i(r, n, o, i) {
        var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype);
        return regeneratorDefine(u, "_invoke", function(r, n, o) {
            var i, c, u, f = 0, p = o || [], y = !1, G = {
                p: 0,
                n: 0,
                v: e,
                a: d,
                f: d.bind(e, 4),
                d: function d(t, r) {
                    return i = t, c = 0, u = e, G.n = r, a;
                }
            };
            function d(r, n) {
                for(c = r, u = n, t = 0; !y && f && !o && t < p.length; t++){
                    var o, i = p[t], d = G.p, l = i[2];
                    r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0));
                }
                if (o || r > 1) return a;
                throw y = !0, n;
            }
            return function(o, p, l) {
                if (f > 1) throw TypeError("Generator is already running");
                for(y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;){
                    i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u);
                    try {
                        if (f = 2, i) {
                            if (c || (o = "next"), t = i[o]) {
                                if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object");
                                if (!t.done) return t;
                                u = t.value, c < 2 && (c = 0);
                            } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1);
                            i = e;
                        } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break;
                    } catch (t) {
                        i = e, c = 1, u = t;
                    } finally{
                        f = 1;
                    }
                }
                return {
                    value: t,
                    done: y
                };
            };
        }(r, o, i), !0), u;
    }
    var a = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    t = Object.getPrototypeOf;
    var c = [][n] ? t(t([][n]())) : (regeneratorDefine(t = {}, n, function() {
        return this;
    }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c);
    function f(e) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, regeneratorDefine(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e;
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, regeneratorDefine(u, "constructor", GeneratorFunctionPrototype), regeneratorDefine(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", regeneratorDefine(GeneratorFunctionPrototype, o, "GeneratorFunction"), regeneratorDefine(u), regeneratorDefine(u, o, "Generator"), regeneratorDefine(u, n, function() {
        return this;
    }), regeneratorDefine(u, "toString", function() {
        return "[object Generator]";
    }), (module.exports = _regenerator = function _regenerator() {
        return {
            w: i,
            m: f
        };
    }, module.exports.__esModule = true, module.exports["default"] = module.exports)();
}
module.exports = _regenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorAsyncIterator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var OverloadYield = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/OverloadYield.js [app-client] (ecmascript)");
var regeneratorDefine = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorDefine.js [app-client] (ecmascript)");
function AsyncIterator(t, e) {
    function n(r, o, i, f) {
        try {
            var c = t[r](o), u = c.value;
            return u instanceof OverloadYield ? e.resolve(u.v).then(function(t) {
                n("next", t, i, f);
            }, function(t) {
                n("throw", t, i, f);
            }) : e.resolve(u).then(function(t) {
                c.value = t, i(c);
            }, function(t) {
                return n("throw", t, i, f);
            });
        } catch (t) {
            f(t);
        }
    }
    var r;
    this.next || (regeneratorDefine(AsyncIterator.prototype), regeneratorDefine(AsyncIterator.prototype, "function" == typeof Symbol && Symbol.asyncIterator || "@asyncIterator", function() {
        return this;
    })), regeneratorDefine(this, "_invoke", function(t, o, i) {
        function f() {
            return new e(function(e, r) {
                n(t, i, e, r);
            });
        }
        return r = r ? r.then(f, f) : f();
    }, !0);
}
module.exports = AsyncIterator, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorAsyncGen.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var regenerator = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regenerator.js [app-client] (ecmascript)");
var regeneratorAsyncIterator = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorAsyncIterator.js [app-client] (ecmascript)");
function _regeneratorAsyncGen(r, e, t, o, n) {
    return new regeneratorAsyncIterator(regenerator().w(r, e, t, o), n || Promise);
}
module.exports = _regeneratorAsyncGen, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorAsync.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var regeneratorAsyncGen = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorAsyncGen.js [app-client] (ecmascript)");
function _regeneratorAsync(n, e, r, t, o) {
    var a = regeneratorAsyncGen(n, e, r, t, o);
    return a.next().then(function(n) {
        return n.done ? n.value : a.next();
    });
}
module.exports = _regeneratorAsync, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorKeys.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _regeneratorKeys(e) {
    var n = Object(e), r = [];
    for(var t in n)r.unshift(t);
    return function e() {
        for(; r.length;)if ((t = r.pop()) in n) return e.value = t, e.done = !1, e;
        return e.done = !0, e;
    };
}
module.exports = _regeneratorKeys, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorValues.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var _typeof = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/typeof.js [app-client] (ecmascript)")["default"];
function _regeneratorValues(e) {
    if (null != e) {
        var t = e["function" == typeof Symbol && Symbol.iterator || "@@iterator"], r = 0;
        if (t) return t.call(e);
        if ("function" == typeof e.next) return e;
        if (!isNaN(e.length)) return {
            next: function next() {
                return e && r >= e.length && (e = void 0), {
                    value: e && e[r++],
                    done: !e
                };
            }
        };
    }
    throw new TypeError(_typeof(e) + " is not iterable");
}
module.exports = _regeneratorValues, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorRuntime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var OverloadYield = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/OverloadYield.js [app-client] (ecmascript)");
var regenerator = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regenerator.js [app-client] (ecmascript)");
var regeneratorAsync = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorAsync.js [app-client] (ecmascript)");
var regeneratorAsyncGen = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorAsyncGen.js [app-client] (ecmascript)");
var regeneratorAsyncIterator = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorAsyncIterator.js [app-client] (ecmascript)");
var regeneratorKeys = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorKeys.js [app-client] (ecmascript)");
var regeneratorValues = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorValues.js [app-client] (ecmascript)");
function _regeneratorRuntime() {
    "use strict";
    var r = regenerator(), e = r.m(_regeneratorRuntime), t = (Object.getPrototypeOf ? Object.getPrototypeOf(e) : e.__proto__).constructor;
    function n(r) {
        var e = "function" == typeof r && r.constructor;
        return !!e && (e === t || "GeneratorFunction" === (e.displayName || e.name));
    }
    var o = {
        "throw": 1,
        "return": 2,
        "break": 3,
        "continue": 3
    };
    function a(r) {
        var e, t;
        return function(n) {
            e || (e = {
                stop: function stop() {
                    return t(n.a, 2);
                },
                "catch": function _catch() {
                    return n.v;
                },
                abrupt: function abrupt(r, e) {
                    return t(n.a, o[r], e);
                },
                delegateYield: function delegateYield(r, o, a) {
                    return e.resultName = o, t(n.d, regeneratorValues(r), a);
                },
                finish: function finish(r) {
                    return t(n.f, r);
                }
            }, t = function t(r, _t, o) {
                n.p = e.prev, n.n = e.next;
                try {
                    return r(_t, o);
                } finally{
                    e.next = n.n;
                }
            }), e.resultName && (e[e.resultName] = n.v, e.resultName = void 0), e.sent = n.v, e.next = n.n;
            try {
                return r.call(this, e);
            } finally{
                n.p = e.prev, n.n = e.next;
            }
        };
    }
    return (module.exports = _regeneratorRuntime = function _regeneratorRuntime() {
        return {
            wrap: function wrap(e, t, n, o) {
                return r.w(a(e), t, n, o && o.reverse());
            },
            isGeneratorFunction: n,
            mark: r.m,
            awrap: function awrap(r, e) {
                return new OverloadYield(r, e);
            },
            AsyncIterator: regeneratorAsyncIterator,
            async: function async(r, e, t, o, u) {
                return (n(e) ? regeneratorAsyncGen : regeneratorAsync)(a(r), e, t, o, u);
            },
            keys: regeneratorKeys,
            values: regeneratorValues
        };
    }, module.exports.__esModule = true, module.exports["default"] = module.exports)();
}
module.exports = _regeneratorRuntime, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/regenerator/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// TODO(Babel 8): Remove this file.
var runtime = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/regeneratorRuntime.js [app-client] (ecmascript)")();
module.exports = runtime;
// Copied from https://github.com/facebook/regenerator/blob/main/packages/runtime/runtime.js#L736=
try {
    regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
    if (typeof globalThis === "object") {
        globalThis.regeneratorRuntime = runtime;
    } else {
        Function("r", "regeneratorRuntime = r")(runtime);
    }
}
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/toPrimitive.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var _typeof = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/typeof.js [app-client] (ecmascript)")["default"];
function toPrimitive(t, r) {
    if ("object" != _typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
module.exports = toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/toPropertyKey.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var _typeof = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/typeof.js [app-client] (ecmascript)")["default"];
var toPrimitive = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/toPrimitive.js [app-client] (ecmascript)");
function toPropertyKey(t) {
    var i = toPrimitive(t, "string");
    return "symbol" == _typeof(i) ? i : i + "";
}
module.exports = toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/defineProperty.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var toPropertyKey = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/toPropertyKey.js [app-client] (ecmascript)");
function _defineProperty(e, r, t) {
    return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}
module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/asyncToGenerator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function asyncGeneratorStep(n, t, e, r, o, a, c) {
    try {
        var i = n[a](c), u = i.value;
    } catch (n) {
        return void e(n);
    }
    i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
    return function() {
        var t = this, e = arguments;
        return new Promise(function(r, o) {
            var a = n.apply(t, e);
            function _next(n) {
                asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
            }
            function _throw(n) {
                asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
            }
            _next(void 0);
        });
    };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/arrayWithHoles.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _arrayWithHoles(r) {
    if (Array.isArray(r)) return r;
}
module.exports = _arrayWithHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/iterableToArrayLimit.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _iterableToArrayLimit(r, l) {
    var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (null != t) {
        var e, n, i, u, a = [], f = !0, o = !1;
        try {
            if (i = (t = t.call(r)).next, 0 === l) {
                if (Object(t) !== t) return;
                f = !1;
            } else for(; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
        } catch (r) {
            o = !0, n = r;
        } finally{
            try {
                if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
            } finally{
                if (o) throw n;
            }
        }
        return a;
    }
}
module.exports = _iterableToArrayLimit, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/arrayLikeToArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for(var e = 0, n = Array(a); e < a; e++)n[e] = r[e];
    return n;
}
module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var arrayLikeToArray = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/arrayLikeToArray.js [app-client] (ecmascript)");
function _unsupportedIterableToArray(r, a) {
    if (r) {
        if ("string" == typeof r) return arrayLikeToArray(r, a);
        var t = ({}).toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? arrayLikeToArray(r, a) : void 0;
    }
}
module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/nonIterableRest.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
module.exports = _nonIterableRest, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/slicedToArray.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var arrayWithHoles = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/arrayWithHoles.js [app-client] (ecmascript)");
var iterableToArrayLimit = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/iterableToArrayLimit.js [app-client] (ecmascript)");
var unsupportedIterableToArray = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js [app-client] (ecmascript)");
var nonIterableRest = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/nonIterableRest.js [app-client] (ecmascript)");
function _slicedToArray(r, e) {
    return arrayWithHoles(r) || iterableToArrayLimit(r, e) || unsupportedIterableToArray(r, e) || nonIterableRest();
}
module.exports = _slicedToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/classCallCheck.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
module.exports = _classCallCheck, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/createClass.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var toPropertyKey = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/toPropertyKey.js [app-client] (ecmascript)");
function _defineProperties(e, r) {
    for(var t = 0; t < r.length; t++){
        var o = r[t];
        o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, toPropertyKey(o.key), o);
    }
}
function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
        writable: !1
    }), e;
}
module.exports = _createClass, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/assertThisInitialized.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
}
module.exports = _assertThisInitialized, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/possibleConstructorReturn.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var _typeof = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/typeof.js [app-client] (ecmascript)")["default"];
var assertThisInitialized = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/assertThisInitialized.js [app-client] (ecmascript)");
function _possibleConstructorReturn(t, e) {
    if (e && ("object" == _typeof(e) || "function" == typeof e)) return e;
    if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
    return assertThisInitialized(t);
}
module.exports = _possibleConstructorReturn, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/getPrototypeOf.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _getPrototypeOf(t) {
    return module.exports = _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
        return t.__proto__ || Object.getPrototypeOf(t);
    }, module.exports.__esModule = true, module.exports["default"] = module.exports, _getPrototypeOf(t);
}
module.exports = _getPrototypeOf, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/setPrototypeOf.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _setPrototypeOf(t, e) {
    return module.exports = _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
        return t.__proto__ = e, t;
    }, module.exports.__esModule = true, module.exports["default"] = module.exports, _setPrototypeOf(t, e);
}
module.exports = _setPrototypeOf, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/inherits.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var setPrototypeOf = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/setPrototypeOf.js [app-client] (ecmascript)");
function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            writable: !0,
            configurable: !0
        }
    }), Object.defineProperty(t, "prototype", {
        writable: !1
    }), e && setPrototypeOf(t, e);
}
module.exports = _inherits, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/isNativeFunction.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _isNativeFunction(t) {
    try {
        return -1 !== Function.toString.call(t).indexOf("[native code]");
    } catch (n) {
        return "function" == typeof t;
    }
}
module.exports = _isNativeFunction, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/isNativeReflectConstruct.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function _isNativeReflectConstruct() {
    try {
        var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (t) {}
    return (module.exports = _isNativeReflectConstruct = function _isNativeReflectConstruct() {
        return !!t;
    }, module.exports.__esModule = true, module.exports["default"] = module.exports)();
}
module.exports = _isNativeReflectConstruct, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/construct.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var isNativeReflectConstruct = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/isNativeReflectConstruct.js [app-client] (ecmascript)");
var setPrototypeOf = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/setPrototypeOf.js [app-client] (ecmascript)");
function _construct(t, e, r) {
    if (isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments);
    var o = [
        null
    ];
    o.push.apply(o, e);
    var p = new (t.bind.apply(t, o))();
    return r && setPrototypeOf(p, r.prototype), p;
}
module.exports = _construct, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/wrapNativeSuper.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var getPrototypeOf = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/getPrototypeOf.js [app-client] (ecmascript)");
var setPrototypeOf = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/setPrototypeOf.js [app-client] (ecmascript)");
var isNativeFunction = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/isNativeFunction.js [app-client] (ecmascript)");
var construct = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/construct.js [app-client] (ecmascript)");
function _wrapNativeSuper(t) {
    var r = "function" == typeof Map ? new Map() : void 0;
    return module.exports = _wrapNativeSuper = function _wrapNativeSuper(t) {
        if (null === t || !isNativeFunction(t)) return t;
        if ("function" != typeof t) throw new TypeError("Super expression must either be null or a function");
        if (void 0 !== r) {
            if (r.has(t)) return r.get(t);
            r.set(t, Wrapper);
        }
        function Wrapper() {
            return construct(t, arguments, getPrototypeOf(this).constructor);
        }
        return Wrapper.prototype = Object.create(t.prototype, {
            constructor: {
                value: Wrapper,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), setPrototypeOf(Wrapper, t);
    }, module.exports.__esModule = true, module.exports["default"] = module.exports, _wrapNativeSuper(t);
}
module.exports = _wrapNativeSuper, module.exports.__esModule = true, module.exports["default"] = module.exports;
}),
"[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/core/errors.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var _interopRequireDefault = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/interopRequireDefault.js [app-client] (ecmascript)");
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.UnsupportedStrategy = exports.UnknownError = exports.OAuthCallbackError = exports.MissingSecret = exports.MissingAuthorize = exports.MissingAdapterMethods = exports.MissingAdapter = exports.MissingAPIRoute = exports.InvalidCallbackUrl = exports.AccountNotLinkedError = void 0;
exports.adapterErrorHandler = adapterErrorHandler;
exports.capitalize = capitalize;
exports.eventsErrorHandler = eventsErrorHandler;
exports.upperSnake = upperSnake;
var _regenerator = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/regenerator/index.js [app-client] (ecmascript)"));
var _asyncToGenerator2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/asyncToGenerator.js [app-client] (ecmascript)"));
var _defineProperty2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/defineProperty.js [app-client] (ecmascript)"));
var _classCallCheck2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/classCallCheck.js [app-client] (ecmascript)"));
var _createClass2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/createClass.js [app-client] (ecmascript)"));
var _possibleConstructorReturn2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/possibleConstructorReturn.js [app-client] (ecmascript)"));
var _getPrototypeOf2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/getPrototypeOf.js [app-client] (ecmascript)"));
var _inherits2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/inherits.js [app-client] (ecmascript)"));
var _wrapNativeSuper2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/wrapNativeSuper.js [app-client] (ecmascript)"));
function _callSuper(t, o, e) {
    return o = (0, _getPrototypeOf2.default)(o), (0, _possibleConstructorReturn2.default)(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], (0, _getPrototypeOf2.default)(t).constructor) : o.apply(t, e));
}
function _isNativeReflectConstruct() {
    try {
        var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
    } catch (t) {}
    return (_isNativeReflectConstruct = function _isNativeReflectConstruct() {
        return !!t;
    })();
}
var UnknownError = exports.UnknownError = function(_Error) {
    function UnknownError(error) {
        var _message;
        var _this;
        (0, _classCallCheck2.default)(this, UnknownError);
        _this = _callSuper(this, UnknownError, [
            (_message = error === null || error === void 0 ? void 0 : error.message) !== null && _message !== void 0 ? _message : error
        ]);
        _this.name = "UnknownError";
        _this.code = error.code;
        if (error instanceof Error) {
            _this.stack = error.stack;
        }
        return _this;
    }
    (0, _inherits2.default)(UnknownError, _Error);
    return (0, _createClass2.default)(UnknownError, [
        {
            key: "toJSON",
            value: function toJSON() {
                return {
                    name: this.name,
                    message: this.message,
                    stack: this.stack
                };
            }
        }
    ]);
}((0, _wrapNativeSuper2.default)(Error));
var OAuthCallbackError = exports.OAuthCallbackError = function(_UnknownError) {
    function OAuthCallbackError() {
        var _this2;
        (0, _classCallCheck2.default)(this, OAuthCallbackError);
        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
            args[_key] = arguments[_key];
        }
        _this2 = _callSuper(this, OAuthCallbackError, [].concat(args));
        (0, _defineProperty2.default)(_this2, "name", "OAuthCallbackError");
        return _this2;
    }
    (0, _inherits2.default)(OAuthCallbackError, _UnknownError);
    return (0, _createClass2.default)(OAuthCallbackError);
}(UnknownError);
var AccountNotLinkedError = exports.AccountNotLinkedError = function(_UnknownError2) {
    function AccountNotLinkedError() {
        var _this3;
        (0, _classCallCheck2.default)(this, AccountNotLinkedError);
        for(var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++){
            args[_key2] = arguments[_key2];
        }
        _this3 = _callSuper(this, AccountNotLinkedError, [].concat(args));
        (0, _defineProperty2.default)(_this3, "name", "AccountNotLinkedError");
        return _this3;
    }
    (0, _inherits2.default)(AccountNotLinkedError, _UnknownError2);
    return (0, _createClass2.default)(AccountNotLinkedError);
}(UnknownError);
var MissingAPIRoute = exports.MissingAPIRoute = function(_UnknownError3) {
    function MissingAPIRoute() {
        var _this4;
        (0, _classCallCheck2.default)(this, MissingAPIRoute);
        for(var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++){
            args[_key3] = arguments[_key3];
        }
        _this4 = _callSuper(this, MissingAPIRoute, [].concat(args));
        (0, _defineProperty2.default)(_this4, "name", "MissingAPIRouteError");
        (0, _defineProperty2.default)(_this4, "code", "MISSING_NEXTAUTH_API_ROUTE_ERROR");
        return _this4;
    }
    (0, _inherits2.default)(MissingAPIRoute, _UnknownError3);
    return (0, _createClass2.default)(MissingAPIRoute);
}(UnknownError);
var MissingSecret = exports.MissingSecret = function(_UnknownError4) {
    function MissingSecret() {
        var _this5;
        (0, _classCallCheck2.default)(this, MissingSecret);
        for(var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++){
            args[_key4] = arguments[_key4];
        }
        _this5 = _callSuper(this, MissingSecret, [].concat(args));
        (0, _defineProperty2.default)(_this5, "name", "MissingSecretError");
        (0, _defineProperty2.default)(_this5, "code", "NO_SECRET");
        return _this5;
    }
    (0, _inherits2.default)(MissingSecret, _UnknownError4);
    return (0, _createClass2.default)(MissingSecret);
}(UnknownError);
var MissingAuthorize = exports.MissingAuthorize = function(_UnknownError5) {
    function MissingAuthorize() {
        var _this6;
        (0, _classCallCheck2.default)(this, MissingAuthorize);
        for(var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++){
            args[_key5] = arguments[_key5];
        }
        _this6 = _callSuper(this, MissingAuthorize, [].concat(args));
        (0, _defineProperty2.default)(_this6, "name", "MissingAuthorizeError");
        (0, _defineProperty2.default)(_this6, "code", "CALLBACK_CREDENTIALS_HANDLER_ERROR");
        return _this6;
    }
    (0, _inherits2.default)(MissingAuthorize, _UnknownError5);
    return (0, _createClass2.default)(MissingAuthorize);
}(UnknownError);
var MissingAdapter = exports.MissingAdapter = function(_UnknownError6) {
    function MissingAdapter() {
        var _this7;
        (0, _classCallCheck2.default)(this, MissingAdapter);
        for(var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++){
            args[_key6] = arguments[_key6];
        }
        _this7 = _callSuper(this, MissingAdapter, [].concat(args));
        (0, _defineProperty2.default)(_this7, "name", "MissingAdapterError");
        (0, _defineProperty2.default)(_this7, "code", "EMAIL_REQUIRES_ADAPTER_ERROR");
        return _this7;
    }
    (0, _inherits2.default)(MissingAdapter, _UnknownError6);
    return (0, _createClass2.default)(MissingAdapter);
}(UnknownError);
var MissingAdapterMethods = exports.MissingAdapterMethods = function(_UnknownError7) {
    function MissingAdapterMethods() {
        var _this8;
        (0, _classCallCheck2.default)(this, MissingAdapterMethods);
        for(var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++){
            args[_key7] = arguments[_key7];
        }
        _this8 = _callSuper(this, MissingAdapterMethods, [].concat(args));
        (0, _defineProperty2.default)(_this8, "name", "MissingAdapterMethodsError");
        (0, _defineProperty2.default)(_this8, "code", "MISSING_ADAPTER_METHODS_ERROR");
        return _this8;
    }
    (0, _inherits2.default)(MissingAdapterMethods, _UnknownError7);
    return (0, _createClass2.default)(MissingAdapterMethods);
}(UnknownError);
var UnsupportedStrategy = exports.UnsupportedStrategy = function(_UnknownError8) {
    function UnsupportedStrategy() {
        var _this9;
        (0, _classCallCheck2.default)(this, UnsupportedStrategy);
        for(var _len8 = arguments.length, args = new Array(_len8), _key8 = 0; _key8 < _len8; _key8++){
            args[_key8] = arguments[_key8];
        }
        _this9 = _callSuper(this, UnsupportedStrategy, [].concat(args));
        (0, _defineProperty2.default)(_this9, "name", "UnsupportedStrategyError");
        (0, _defineProperty2.default)(_this9, "code", "CALLBACK_CREDENTIALS_JWT_ERROR");
        return _this9;
    }
    (0, _inherits2.default)(UnsupportedStrategy, _UnknownError8);
    return (0, _createClass2.default)(UnsupportedStrategy);
}(UnknownError);
var InvalidCallbackUrl = exports.InvalidCallbackUrl = function(_UnknownError9) {
    function InvalidCallbackUrl() {
        var _this10;
        (0, _classCallCheck2.default)(this, InvalidCallbackUrl);
        for(var _len9 = arguments.length, args = new Array(_len9), _key9 = 0; _key9 < _len9; _key9++){
            args[_key9] = arguments[_key9];
        }
        _this10 = _callSuper(this, InvalidCallbackUrl, [].concat(args));
        (0, _defineProperty2.default)(_this10, "name", "InvalidCallbackUrl");
        (0, _defineProperty2.default)(_this10, "code", "INVALID_CALLBACK_URL_ERROR");
        return _this10;
    }
    (0, _inherits2.default)(InvalidCallbackUrl, _UnknownError9);
    return (0, _createClass2.default)(InvalidCallbackUrl);
}(UnknownError);
function upperSnake(s) {
    return s.replace(/([A-Z])/g, "_$1").toUpperCase();
}
function capitalize(s) {
    return "".concat(s[0].toUpperCase()).concat(s.slice(1));
}
function eventsErrorHandler(methods, logger) {
    return Object.keys(methods).reduce(function(acc, name) {
        acc[name] = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee() {
            var method, _args = arguments;
            return _regenerator.default.wrap(function _callee$(_context) {
                while(1)switch(_context.prev = _context.next){
                    case 0:
                        _context.prev = 0;
                        method = methods[name];
                        _context.next = 4;
                        return method.apply(void 0, _args);
                    case 4:
                        return _context.abrupt("return", _context.sent);
                    case 7:
                        _context.prev = 7;
                        _context.t0 = _context["catch"](0);
                        logger.error("".concat(upperSnake(name), "_EVENT_ERROR"), _context.t0);
                    case 10:
                    case "end":
                        return _context.stop();
                }
            }, _callee, null, [
                [
                    0,
                    7
                ]
            ]);
        }));
        return acc;
    }, {});
}
function adapterErrorHandler(adapter, logger) {
    if (!adapter) return;
    return Object.keys(adapter).reduce(function(acc, name) {
        acc[name] = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee2() {
            var _len10, args, _key10, method, e, _args2 = arguments;
            return _regenerator.default.wrap(function _callee2$(_context2) {
                while(1)switch(_context2.prev = _context2.next){
                    case 0:
                        _context2.prev = 0;
                        for(_len10 = _args2.length, args = new Array(_len10), _key10 = 0; _key10 < _len10; _key10++){
                            args[_key10] = _args2[_key10];
                        }
                        logger.debug("adapter_".concat(name), {
                            args: args
                        });
                        method = adapter[name];
                        _context2.next = 6;
                        return method.apply(void 0, args);
                    case 6:
                        return _context2.abrupt("return", _context2.sent);
                    case 9:
                        _context2.prev = 9;
                        _context2.t0 = _context2["catch"](0);
                        logger.error("adapter_error_".concat(name), _context2.t0);
                        e = new UnknownError(_context2.t0);
                        e.name = "".concat(capitalize(name), "Error");
                        throw e;
                    case 15:
                    case "end":
                        return _context2.stop();
                }
            }, _callee2, null, [
                [
                    0,
                    9
                ]
            ]);
        }));
        return acc;
    }, {});
}
}),
"[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/utils/logger.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var _interopRequireDefault = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/interopRequireDefault.js [app-client] (ecmascript)");
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = void 0;
exports.proxyLogger = proxyLogger;
exports.setLogger = setLogger;
var _regenerator = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/regenerator/index.js [app-client] (ecmascript)"));
var _defineProperty2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/defineProperty.js [app-client] (ecmascript)"));
var _asyncToGenerator2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/asyncToGenerator.js [app-client] (ecmascript)"));
var _errors = __turbopack_context__.r("[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/core/errors.js [app-client] (ecmascript)");
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            (0, _defineProperty2.default)(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function formatError(o) {
    if (o instanceof Error && !(o instanceof _errors.UnknownError)) {
        return {
            message: o.message,
            stack: o.stack,
            name: o.name
        };
    }
    if (hasErrorProperty(o)) {
        var _o$message;
        o.error = formatError(o.error);
        o.message = (_o$message = o.message) !== null && _o$message !== void 0 ? _o$message : o.error.message;
    }
    return o;
}
function hasErrorProperty(x) {
    return !!(x !== null && x !== void 0 && x.error);
}
var _logger = {
    error: function error(code, metadata) {
        metadata = formatError(metadata);
        console.error("[next-auth][error][".concat(code, "]"), "\nhttps://next-auth.js.org/errors#".concat(code.toLowerCase()), metadata.message, metadata);
    },
    warn: function warn(code) {
        console.warn("[next-auth][warn][".concat(code, "]"), "\nhttps://next-auth.js.org/warnings#".concat(code.toLowerCase()));
    },
    debug: function debug(code, metadata) {
        console.log("[next-auth][debug][".concat(code, "]"), metadata);
    }
};
function setLogger() {
    var newLogger = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var debug = arguments.length > 1 ? arguments[1] : undefined;
    if (!debug) _logger.debug = function() {};
    if (newLogger.error) _logger.error = newLogger.error;
    if (newLogger.warn) _logger.warn = newLogger.warn;
    if (newLogger.debug) _logger.debug = newLogger.debug;
}
var _default = exports.default = _logger;
function proxyLogger() {
    var logger = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _logger;
    var basePath = arguments.length > 1 ? arguments[1] : undefined;
    try {
        if (typeof window === "undefined") {
            return logger;
        }
        var clientLogger = {};
        var _loop = function _loop(level) {
            clientLogger[level] = function() {
                var _ref = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee(code, metadata) {
                    var url, body;
                    return _regenerator.default.wrap(function _callee$(_context) {
                        while(1)switch(_context.prev = _context.next){
                            case 0:
                                _logger[level](code, metadata);
                                if (level === "error") {
                                    metadata = formatError(metadata);
                                }
                                ;
                                metadata.client = true;
                                url = "".concat(basePath, "/_log");
                                body = new URLSearchParams(_objectSpread({
                                    level: level,
                                    code: code
                                }, metadata));
                                if (!navigator.sendBeacon) {
                                    _context.next = 8;
                                    break;
                                }
                                return _context.abrupt("return", navigator.sendBeacon(url, body));
                            case 8:
                                _context.next = 10;
                                return fetch(url, {
                                    method: "POST",
                                    body: body,
                                    keepalive: true
                                });
                            case 10:
                                return _context.abrupt("return", _context.sent);
                            case 11:
                            case "end":
                                return _context.stop();
                        }
                    }, _callee);
                }));
                return function(_x, _x2) {
                    return _ref.apply(this, arguments);
                };
            }();
        };
        for(var level in logger){
            _loop(level);
        }
        return clientLogger;
    } catch (_unused) {
        return _logger;
    }
}
}),
"[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/utils/parse-url.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = parseUrl;
function parseUrl(url) {
    var _url2;
    const defaultUrl = new URL("http://localhost:3000/api/auth");
    if (url && !url.startsWith("http")) {
        url = "https://".concat(url);
    }
    const _url = new URL((_url2 = url) !== null && _url2 !== void 0 ? _url2 : defaultUrl);
    const path = (_url.pathname === "/" ? defaultUrl.pathname : _url.pathname).replace(/\/$/, "");
    const base = "".concat(_url.origin).concat(path);
    return {
        origin: _url.origin,
        host: _url.host,
        path,
        base,
        toString: ()=>base
    };
}
}),
"[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/client/_utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var _interopRequireDefault = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/interopRequireDefault.js [app-client] (ecmascript)");
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BroadcastChannel = BroadcastChannel;
exports.apiBaseUrl = apiBaseUrl;
exports.fetchData = fetchData;
exports.now = now;
var _regenerator = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/regenerator/index.js [app-client] (ecmascript)"));
var _defineProperty2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/defineProperty.js [app-client] (ecmascript)"));
var _asyncToGenerator2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/asyncToGenerator.js [app-client] (ecmascript)"));
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            (0, _defineProperty2.default)(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function fetchData(_x, _x2, _x3) {
    return _fetchData.apply(this, arguments);
}
function _fetchData() {
    _fetchData = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee(path, __NEXTAUTH, logger) {
        var _ref, ctx, _ref$req, req, url, _req$headers, options, res, data, _args = arguments;
        return _regenerator.default.wrap(function _callee$(_context) {
            while(1)switch(_context.prev = _context.next){
                case 0:
                    _ref = _args.length > 3 && _args[3] !== undefined ? _args[3] : {}, ctx = _ref.ctx, _ref$req = _ref.req, req = _ref$req === void 0 ? ctx === null || ctx === void 0 ? void 0 : ctx.req : _ref$req;
                    url = "".concat(apiBaseUrl(__NEXTAUTH), "/").concat(path);
                    _context.prev = 2;
                    options = {
                        headers: _objectSpread({
                            "Content-Type": "application/json"
                        }, req !== null && req !== void 0 && (_req$headers = req.headers) !== null && _req$headers !== void 0 && _req$headers.cookie ? {
                            cookie: req.headers.cookie
                        } : {})
                    };
                    if (req !== null && req !== void 0 && req.body) {
                        options.body = JSON.stringify(req.body);
                        options.method = "POST";
                    }
                    _context.next = 7;
                    return fetch(url, options);
                case 7:
                    res = _context.sent;
                    _context.next = 10;
                    return res.json();
                case 10:
                    data = _context.sent;
                    if (res.ok) {
                        _context.next = 13;
                        break;
                    }
                    throw data;
                case 13:
                    return _context.abrupt("return", Object.keys(data).length > 0 ? data : null);
                case 16:
                    _context.prev = 16;
                    _context.t0 = _context["catch"](2);
                    logger.error("CLIENT_FETCH_ERROR", {
                        error: _context.t0,
                        url: url
                    });
                    return _context.abrupt("return", null);
                case 20:
                case "end":
                    return _context.stop();
            }
        }, _callee, null, [
            [
                2,
                16
            ]
        ]);
    }));
    return _fetchData.apply(this, arguments);
}
function apiBaseUrl(__NEXTAUTH) {
    if (typeof window === "undefined") {
        return "".concat(__NEXTAUTH.baseUrlServer).concat(__NEXTAUTH.basePathServer);
    }
    return __NEXTAUTH.basePath;
}
function now() {
    return Math.floor(Date.now() / 1000);
}
function BroadcastChannel() {
    var name = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "nextauth.message";
    return {
        receive: function receive(onReceive) {
            var handler = function handler(event) {
                var _event$newValue;
                if (event.key !== name) return;
                var message = JSON.parse((_event$newValue = event.newValue) !== null && _event$newValue !== void 0 ? _event$newValue : "{}");
                if ((message === null || message === void 0 ? void 0 : message.event) !== "session" || !(message !== null && message !== void 0 && message.data)) return;
                onReceive(message);
            };
            window.addEventListener("storage", handler);
            return function() {
                return window.removeEventListener("storage", handler);
            };
        },
        post: function post(message) {
            if (typeof window === "undefined") return;
            try {
                localStorage.setItem(name, JSON.stringify(_objectSpread(_objectSpread({}, message), {}, {
                    timestamp: now()
                })));
            } catch (_unused) {}
        }
    };
}
}),
"[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/react/types.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
}),
"[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/react/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
var _interopRequireDefault = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/interopRequireDefault.js [app-client] (ecmascript)");
var _typeof = __turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/typeof.js [app-client] (ecmascript)");
Object.defineProperty(exports, "__esModule", {
    value: true
});
var _exportNames = {
    SessionContext: true,
    useSession: true,
    getSession: true,
    getCsrfToken: true,
    getProviders: true,
    signIn: true,
    signOut: true,
    SessionProvider: true
};
exports.SessionContext = void 0;
exports.SessionProvider = SessionProvider;
exports.getCsrfToken = getCsrfToken;
exports.getProviders = getProviders;
exports.getSession = getSession;
exports.signIn = signIn;
exports.signOut = signOut;
exports.useSession = useSession;
var _regenerator = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/regenerator/index.js [app-client] (ecmascript)"));
var _defineProperty2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/defineProperty.js [app-client] (ecmascript)"));
var _asyncToGenerator2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/asyncToGenerator.js [app-client] (ecmascript)"));
var _slicedToArray2 = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/@babel+runtime@7.28.4/node_modules/@babel/runtime/helpers/slicedToArray.js [app-client] (ecmascript)"));
var React = _interopRequireWildcard(__turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
var _logger2 = _interopRequireWildcard(__turbopack_context__.r("[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/utils/logger.js [app-client] (ecmascript)"));
var _parseUrl = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/utils/parse-url.js [app-client] (ecmascript)"));
var _utils = __turbopack_context__.r("[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/client/_utils.js [app-client] (ecmascript)");
var _jsxRuntime = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var _types = __turbopack_context__.r("[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.5.5_@playwright+test@1.56.1_react-dom@19.1.0_react@19.1.0__react@19_gv3xt2isy552xiex35hmekt2jy/node_modules/next-auth/react/types.js [app-client] (ecmascript)");
Object.keys(_types).forEach(function(key) {
    if (key === "default" || key === "__esModule") return;
    if (Object.prototype.hasOwnProperty.call(_exportNames, key)) return;
    if (key in exports && exports[key] === _types[key]) return;
    Object.defineProperty(exports, key, {
        enumerable: true,
        get: function get() {
            return _types[key];
        }
    });
});
var _process$env$NEXTAUTH, _ref, _process$env$NEXTAUTH2, _process$env$NEXTAUTH3, _React$createContext;
function _getRequireWildcardCache(e) {
    if ("function" != typeof WeakMap) return null;
    var r = new WeakMap(), t = new WeakMap();
    return (_getRequireWildcardCache = function _getRequireWildcardCache(e) {
        return e ? t : r;
    })(e);
}
function _interopRequireWildcard(e, r) {
    if (!r && e && e.__esModule) return e;
    if (null === e || "object" != _typeof(e) && "function" != typeof e) return {
        default: e
    };
    var t = _getRequireWildcardCache(r);
    if (t && t.has(e)) return t.get(e);
    var n = {
        __proto__: null
    }, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var u in e)if ("default" !== u && ({}).hasOwnProperty.call(e, u)) {
        var i = a ? Object.getOwnPropertyDescriptor(e, u) : null;
        i && (i.get || i.set) ? Object.defineProperty(n, u, i) : n[u] = e[u];
    }
    return n.default = e, t && t.set(e, n), n;
}
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            (0, _defineProperty2.default)(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
var __NEXTAUTH = {
    baseUrl: (0, _parseUrl.default)((_process$env$NEXTAUTH = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_URL) !== null && _process$env$NEXTAUTH !== void 0 ? _process$env$NEXTAUTH : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.VERCEL_URL).origin,
    basePath: (0, _parseUrl.default)(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_URL).path,
    baseUrlServer: (0, _parseUrl.default)((_ref = (_process$env$NEXTAUTH2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_URL_INTERNAL) !== null && _process$env$NEXTAUTH2 !== void 0 ? _process$env$NEXTAUTH2 : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_URL) !== null && _ref !== void 0 ? _ref : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.VERCEL_URL).origin,
    basePathServer: (0, _parseUrl.default)((_process$env$NEXTAUTH3 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_URL_INTERNAL) !== null && _process$env$NEXTAUTH3 !== void 0 ? _process$env$NEXTAUTH3 : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXTAUTH_URL).path,
    _lastSync: 0,
    _session: undefined,
    _getSession: function _getSession() {}
};
var broadcast = (0, _utils.BroadcastChannel)();
var logger = (0, _logger2.proxyLogger)(_logger2.default, __NEXTAUTH.basePath);
function useOnline() {
    var _React$useState = React.useState(typeof navigator !== "undefined" ? navigator.onLine : false), _React$useState2 = (0, _slicedToArray2.default)(_React$useState, 2), isOnline = _React$useState2[0], setIsOnline = _React$useState2[1];
    var setOnline = function setOnline() {
        return setIsOnline(true);
    };
    var setOffline = function setOffline() {
        return setIsOnline(false);
    };
    React.useEffect({
        "useOnline.useEffect": function() {
            window.addEventListener("online", setOnline);
            window.addEventListener("offline", setOffline);
            return ({
                "useOnline.useEffect": function() {
                    window.removeEventListener("online", setOnline);
                    window.removeEventListener("offline", setOffline);
                }
            })["useOnline.useEffect"];
        }
    }["useOnline.useEffect"], []);
    return isOnline;
}
var SessionContext = exports.SessionContext = (_React$createContext = React.createContext) === null || _React$createContext === void 0 ? void 0 : _React$createContext.call(React, undefined);
function useSession(options) {
    if (!SessionContext) {
        throw new Error("React Context is unavailable in Server Components");
    }
    var value = React.useContext(SessionContext);
    if (!value && ("TURBOPACK compile-time value", "development") !== "production") {
        throw new Error("[next-auth]: `useSession` must be wrapped in a <SessionProvider />");
    }
    var _ref2 = options !== null && options !== void 0 ? options : {}, required = _ref2.required, onUnauthenticated = _ref2.onUnauthenticated;
    var requiredAndNotLoading = required && value.status === "unauthenticated";
    React.useEffect({
        "useSession.useEffect": function() {
            if (requiredAndNotLoading) {
                var url = "/api/auth/signin?".concat(new URLSearchParams({
                    error: "SessionRequired",
                    callbackUrl: window.location.href
                }));
                if (onUnauthenticated) onUnauthenticated();
                else window.location.href = url;
            }
        }
    }["useSession.useEffect"], [
        requiredAndNotLoading,
        onUnauthenticated
    ]);
    if (requiredAndNotLoading) {
        return {
            data: value.data,
            update: value.update,
            status: "loading"
        };
    }
    return value;
}
function getSession(_x) {
    return _getSession2.apply(this, arguments);
}
function _getSession2() {
    _getSession2 = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee3(params) {
        var _params$broadcast;
        var session;
        return _regenerator.default.wrap(function _callee3$(_context3) {
            while(1)switch(_context3.prev = _context3.next){
                case 0:
                    _context3.next = 2;
                    return (0, _utils.fetchData)("session", __NEXTAUTH, logger, params);
                case 2:
                    session = _context3.sent;
                    if ((_params$broadcast = params === null || params === void 0 ? void 0 : params.broadcast) !== null && _params$broadcast !== void 0 ? _params$broadcast : true) {
                        broadcast.post({
                            event: "session",
                            data: {
                                trigger: "getSession"
                            }
                        });
                    }
                    return _context3.abrupt("return", session);
                case 5:
                case "end":
                    return _context3.stop();
            }
        }, _callee3);
    }));
    return _getSession2.apply(this, arguments);
}
function getCsrfToken(_x2) {
    return _getCsrfToken.apply(this, arguments);
}
function _getCsrfToken() {
    _getCsrfToken = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee4(params) {
        var response;
        return _regenerator.default.wrap(function _callee4$(_context4) {
            while(1)switch(_context4.prev = _context4.next){
                case 0:
                    _context4.next = 2;
                    return (0, _utils.fetchData)("csrf", __NEXTAUTH, logger, params);
                case 2:
                    response = _context4.sent;
                    return _context4.abrupt("return", response === null || response === void 0 ? void 0 : response.csrfToken);
                case 4:
                case "end":
                    return _context4.stop();
            }
        }, _callee4);
    }));
    return _getCsrfToken.apply(this, arguments);
}
function getProviders() {
    return _getProviders.apply(this, arguments);
}
function _getProviders() {
    _getProviders = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee5() {
        return _regenerator.default.wrap(function _callee5$(_context5) {
            while(1)switch(_context5.prev = _context5.next){
                case 0:
                    _context5.next = 2;
                    return (0, _utils.fetchData)("providers", __NEXTAUTH, logger);
                case 2:
                    return _context5.abrupt("return", _context5.sent);
                case 3:
                case "end":
                    return _context5.stop();
            }
        }, _callee5);
    }));
    return _getProviders.apply(this, arguments);
}
function signIn(_x3, _x4, _x5) {
    return _signIn.apply(this, arguments);
}
function _signIn() {
    _signIn = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee6(provider, options, authorizationParams) {
        var _ref5, _ref5$callbackUrl, callbackUrl, _ref5$redirect, redirect, baseUrl, providers, isCredentials, isEmail, isSupportingReturn, signInUrl, _signInUrl, res, data, _data$url, url, error;
        return _regenerator.default.wrap(function _callee6$(_context6) {
            while(1)switch(_context6.prev = _context6.next){
                case 0:
                    _ref5 = options !== null && options !== void 0 ? options : {}, _ref5$callbackUrl = _ref5.callbackUrl, callbackUrl = _ref5$callbackUrl === void 0 ? window.location.href : _ref5$callbackUrl, _ref5$redirect = _ref5.redirect, redirect = _ref5$redirect === void 0 ? true : _ref5$redirect;
                    baseUrl = (0, _utils.apiBaseUrl)(__NEXTAUTH);
                    _context6.next = 4;
                    return getProviders();
                case 4:
                    providers = _context6.sent;
                    if (providers) {
                        _context6.next = 8;
                        break;
                    }
                    window.location.href = "".concat(baseUrl, "/error");
                    return _context6.abrupt("return");
                case 8:
                    if (!(!provider || !(provider in providers))) {
                        _context6.next = 11;
                        break;
                    }
                    window.location.href = "".concat(baseUrl, "/signin?").concat(new URLSearchParams({
                        callbackUrl: callbackUrl
                    }));
                    return _context6.abrupt("return");
                case 11:
                    isCredentials = providers[provider].type === "credentials";
                    isEmail = providers[provider].type === "email";
                    isSupportingReturn = isCredentials || isEmail;
                    signInUrl = "".concat(baseUrl, "/").concat(isCredentials ? "callback" : "signin", "/").concat(provider);
                    _signInUrl = "".concat(signInUrl).concat(authorizationParams ? "?".concat(new URLSearchParams(authorizationParams)) : "");
                    _context6.t0 = fetch;
                    _context6.t1 = _signInUrl;
                    _context6.t2 = {
                        "Content-Type": "application/x-www-form-urlencoded"
                    };
                    _context6.t3 = URLSearchParams;
                    _context6.t4 = _objectSpread;
                    _context6.t5 = _objectSpread({}, options);
                    _context6.t6 = {};
                    _context6.next = 25;
                    return getCsrfToken();
                case 25:
                    _context6.t7 = _context6.sent;
                    _context6.t8 = callbackUrl;
                    _context6.t9 = {
                        csrfToken: _context6.t7,
                        callbackUrl: _context6.t8,
                        json: true
                    };
                    _context6.t10 = (0, _context6.t4)(_context6.t5, _context6.t6, _context6.t9);
                    _context6.t11 = new _context6.t3(_context6.t10);
                    _context6.t12 = {
                        method: "post",
                        headers: _context6.t2,
                        body: _context6.t11
                    };
                    _context6.next = 33;
                    return (0, _context6.t0)(_context6.t1, _context6.t12);
                case 33:
                    res = _context6.sent;
                    _context6.next = 36;
                    return res.json();
                case 36:
                    data = _context6.sent;
                    if (!(redirect || !isSupportingReturn)) {
                        _context6.next = 42;
                        break;
                    }
                    url = (_data$url = data.url) !== null && _data$url !== void 0 ? _data$url : callbackUrl;
                    window.location.href = url;
                    if (url.includes("#")) window.location.reload();
                    return _context6.abrupt("return");
                case 42:
                    error = new URL(data.url).searchParams.get("error");
                    if (!res.ok) {
                        _context6.next = 46;
                        break;
                    }
                    _context6.next = 46;
                    return __NEXTAUTH._getSession({
                        event: "storage"
                    });
                case 46:
                    return _context6.abrupt("return", {
                        error: error,
                        status: res.status,
                        ok: res.ok,
                        url: error ? null : data.url
                    });
                case 47:
                case "end":
                    return _context6.stop();
            }
        }, _callee6);
    }));
    return _signIn.apply(this, arguments);
}
function signOut(_x6) {
    return _signOut.apply(this, arguments);
}
function _signOut() {
    _signOut = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee7(options) {
        var _options$redirect;
        var _ref6, _ref6$callbackUrl, callbackUrl, baseUrl, fetchOptions, res, data, _data$url2, url;
        return _regenerator.default.wrap(function _callee7$(_context7) {
            while(1)switch(_context7.prev = _context7.next){
                case 0:
                    _ref6 = options !== null && options !== void 0 ? options : {}, _ref6$callbackUrl = _ref6.callbackUrl, callbackUrl = _ref6$callbackUrl === void 0 ? window.location.href : _ref6$callbackUrl;
                    baseUrl = (0, _utils.apiBaseUrl)(__NEXTAUTH);
                    _context7.t0 = {
                        "Content-Type": "application/x-www-form-urlencoded"
                    };
                    _context7.t1 = URLSearchParams;
                    _context7.next = 6;
                    return getCsrfToken();
                case 6:
                    _context7.t2 = _context7.sent;
                    _context7.t3 = callbackUrl;
                    _context7.t4 = {
                        csrfToken: _context7.t2,
                        callbackUrl: _context7.t3,
                        json: true
                    };
                    _context7.t5 = new _context7.t1(_context7.t4);
                    fetchOptions = {
                        method: "post",
                        headers: _context7.t0,
                        body: _context7.t5
                    };
                    _context7.next = 13;
                    return fetch("".concat(baseUrl, "/signout"), fetchOptions);
                case 13:
                    res = _context7.sent;
                    _context7.next = 16;
                    return res.json();
                case 16:
                    data = _context7.sent;
                    broadcast.post({
                        event: "session",
                        data: {
                            trigger: "signout"
                        }
                    });
                    if (!((_options$redirect = options === null || options === void 0 ? void 0 : options.redirect) !== null && _options$redirect !== void 0 ? _options$redirect : true)) {
                        _context7.next = 23;
                        break;
                    }
                    url = (_data$url2 = data.url) !== null && _data$url2 !== void 0 ? _data$url2 : callbackUrl;
                    window.location.href = url;
                    if (url.includes("#")) window.location.reload();
                    return _context7.abrupt("return");
                case 23:
                    _context7.next = 25;
                    return __NEXTAUTH._getSession({
                        event: "storage"
                    });
                case 25:
                    return _context7.abrupt("return", data);
                case 26:
                case "end":
                    return _context7.stop();
            }
        }, _callee7);
    }));
    return _signOut.apply(this, arguments);
}
function SessionProvider(props) {
    if (!SessionContext) {
        throw new Error("React Context is unavailable in Server Components");
    }
    var children = props.children, basePath = props.basePath, refetchInterval = props.refetchInterval, refetchWhenOffline = props.refetchWhenOffline;
    if (basePath) __NEXTAUTH.basePath = basePath;
    var hasInitialSession = props.session !== undefined;
    __NEXTAUTH._lastSync = hasInitialSession ? (0, _utils.now)() : 0;
    var _React$useState3 = React.useState({
        "SessionProvider.useState[_React$useState3]": function() {
            if (hasInitialSession) __NEXTAUTH._session = props.session;
            return props.session;
        }
    }["SessionProvider.useState[_React$useState3]"]), _React$useState4 = (0, _slicedToArray2.default)(_React$useState3, 2), session = _React$useState4[0], setSession = _React$useState4[1];
    var _React$useState5 = React.useState(!hasInitialSession), _React$useState6 = (0, _slicedToArray2.default)(_React$useState5, 2), loading = _React$useState6[0], setLoading = _React$useState6[1];
    React.useEffect({
        "SessionProvider.useEffect": function() {
            __NEXTAUTH._getSession = (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee() {
                var _ref4, event, storageEvent, _args = arguments;
                return _regenerator.default.wrap(function _callee$(_context) {
                    while(1)switch(_context.prev = _context.next){
                        case 0:
                            _ref4 = _args.length > 0 && _args[0] !== undefined ? _args[0] : {}, event = _ref4.event;
                            _context.prev = 1;
                            storageEvent = event === "storage";
                            if (!(storageEvent || __NEXTAUTH._session === undefined)) {
                                _context.next = 10;
                                break;
                            }
                            __NEXTAUTH._lastSync = (0, _utils.now)();
                            _context.next = 7;
                            return getSession({
                                broadcast: !storageEvent
                            });
                        case 7:
                            __NEXTAUTH._session = _context.sent;
                            setSession(__NEXTAUTH._session);
                            return _context.abrupt("return");
                        case 10:
                            if (!(!event || __NEXTAUTH._session === null || (0, _utils.now)() < __NEXTAUTH._lastSync)) {
                                _context.next = 12;
                                break;
                            }
                            return _context.abrupt("return");
                        case 12:
                            __NEXTAUTH._lastSync = (0, _utils.now)();
                            _context.next = 15;
                            return getSession();
                        case 15:
                            __NEXTAUTH._session = _context.sent;
                            setSession(__NEXTAUTH._session);
                            _context.next = 22;
                            break;
                        case 19:
                            _context.prev = 19;
                            _context.t0 = _context["catch"](1);
                            logger.error("CLIENT_SESSION_ERROR", _context.t0);
                        case 22:
                            _context.prev = 22;
                            setLoading(false);
                            return _context.finish(22);
                        case 25:
                        case "end":
                            return _context.stop();
                    }
                }, _callee, null, [
                    [
                        1,
                        19,
                        22,
                        25
                    ]
                ]);
            }));
            __NEXTAUTH._getSession();
            return ({
                "SessionProvider.useEffect": function() {
                    __NEXTAUTH._lastSync = 0;
                    __NEXTAUTH._session = undefined;
                    __NEXTAUTH._getSession = ({
                        "SessionProvider.useEffect": function() {}
                    })["SessionProvider.useEffect"];
                }
            })["SessionProvider.useEffect"];
        }
    }["SessionProvider.useEffect"], []);
    React.useEffect({
        "SessionProvider.useEffect": function() {
            var unsubscribe = broadcast.receive({
                "SessionProvider.useEffect.unsubscribe": function() {
                    return __NEXTAUTH._getSession({
                        event: "storage"
                    });
                }
            }["SessionProvider.useEffect.unsubscribe"]);
            return ({
                "SessionProvider.useEffect": function() {
                    return unsubscribe();
                }
            })["SessionProvider.useEffect"];
        }
    }["SessionProvider.useEffect"], []);
    React.useEffect({
        "SessionProvider.useEffect": function() {
            var _props$refetchOnWindo = props.refetchOnWindowFocus, refetchOnWindowFocus = _props$refetchOnWindo === void 0 ? true : _props$refetchOnWindo;
            var visibilityHandler = function visibilityHandler() {
                if (refetchOnWindowFocus && document.visibilityState === "visible") __NEXTAUTH._getSession({
                    event: "visibilitychange"
                });
            };
            document.addEventListener("visibilitychange", visibilityHandler, false);
            return ({
                "SessionProvider.useEffect": function() {
                    return document.removeEventListener("visibilitychange", visibilityHandler, false);
                }
            })["SessionProvider.useEffect"];
        }
    }["SessionProvider.useEffect"], [
        props.refetchOnWindowFocus
    ]);
    var isOnline = useOnline();
    var shouldRefetch = refetchWhenOffline !== false || isOnline;
    React.useEffect({
        "SessionProvider.useEffect": function() {
            if (refetchInterval && shouldRefetch) {
                var refetchIntervalTimer = setInterval({
                    "SessionProvider.useEffect.refetchIntervalTimer": function() {
                        if (__NEXTAUTH._session) {
                            __NEXTAUTH._getSession({
                                event: "poll"
                            });
                        }
                    }
                }["SessionProvider.useEffect.refetchIntervalTimer"], refetchInterval * 1000);
                return ({
                    "SessionProvider.useEffect": function() {
                        return clearInterval(refetchIntervalTimer);
                    }
                })["SessionProvider.useEffect"];
            }
        }
    }["SessionProvider.useEffect"], [
        refetchInterval,
        shouldRefetch
    ]);
    var value = React.useMemo({
        "SessionProvider.useMemo[value]": function() {
            return {
                data: session,
                status: loading ? "loading" : session ? "authenticated" : "unauthenticated",
                update: function update(data) {
                    return (0, _asyncToGenerator2.default)(_regenerator.default.mark(function _callee2() {
                        var newSession;
                        return _regenerator.default.wrap(function _callee2$(_context2) {
                            while(1)switch(_context2.prev = _context2.next){
                                case 0:
                                    if (!(loading || !session)) {
                                        _context2.next = 2;
                                        break;
                                    }
                                    return _context2.abrupt("return");
                                case 2:
                                    setLoading(true);
                                    _context2.t0 = _utils.fetchData;
                                    _context2.t1 = __NEXTAUTH;
                                    _context2.t2 = logger;
                                    _context2.next = 8;
                                    return getCsrfToken();
                                case 8:
                                    _context2.t3 = _context2.sent;
                                    _context2.t4 = data;
                                    _context2.t5 = {
                                        csrfToken: _context2.t3,
                                        data: _context2.t4
                                    };
                                    _context2.t6 = {
                                        body: _context2.t5
                                    };
                                    _context2.t7 = {
                                        req: _context2.t6
                                    };
                                    _context2.next = 15;
                                    return (0, _context2.t0)("session", _context2.t1, _context2.t2, _context2.t7);
                                case 15:
                                    newSession = _context2.sent;
                                    setLoading(false);
                                    if (newSession) {
                                        setSession(newSession);
                                        broadcast.post({
                                            event: "session",
                                            data: {
                                                trigger: "getSession"
                                            }
                                        });
                                    }
                                    return _context2.abrupt("return", newSession);
                                case 19:
                                case "end":
                                    return _context2.stop();
                            }
                        }, _callee2);
                    }))();
                }
            };
        }
    }["SessionProvider.useMemo[value]"], [
        session,
        loading
    ]);
    return (0, _jsxRuntime.jsx)(SessionContext.Provider, {
        value: value,
        children: children
    });
}
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_apply_descriptor_get
]);
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) return descriptor.get.call(receiver);
    return descriptor.value;
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_extract_field_descriptor
]);
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) throw new TypeError("attempted to " + action + " private field on non-instance");
    return privateMap.get(receiver);
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_field_get
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_apply_descriptor_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js [app-client] (ecmascript)");
;
;
function _class_private_field_get(receiver, privateMap) {
    var descriptor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, privateMap, "get");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, descriptor);
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_check_private_redeclaration.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_check_private_redeclaration
]);
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_field_init
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_check_private_redeclaration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_check_private_redeclaration.js [app-client] (ecmascript)");
;
function _class_private_field_init(obj, privateMap, value) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_check_private_redeclaration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(obj, privateMap);
    privateMap.set(obj, value);
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_apply_descriptor_set
]);
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) descriptor.set.call(receiver, value);
    else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_field_set
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_apply_descriptor_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js [app-client] (ecmascript)");
;
;
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, privateMap, "set");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, descriptor, value);
    return value;
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_apply_descriptor_update.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_apply_descriptor_update
]);
function _class_apply_descriptor_update(receiver, descriptor) {
    if (descriptor.set) {
        if (!descriptor.get) throw new TypeError("attempted to read set only private field");
        if (!("__destrWrapper" in descriptor)) {
            descriptor.__destrWrapper = {
                set value (v){
                    descriptor.set.call(receiver, v);
                },
                get value () {
                    return descriptor.get.call(receiver);
                }
            };
        }
        return descriptor.__destrWrapper;
    } else {
        if (!descriptor.writable) {
            // This should only throw in strict mode, but class bodies are
            // always strict and private fields can only be used inside
            // class bodies.
            throw new TypeError("attempted to set read only private field");
        }
        return descriptor;
    }
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_update.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_field_update
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_update$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_apply_descriptor_update.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_extract_field_descriptor.js [app-client] (ecmascript)");
;
;
function _class_private_field_update(receiver, privateMap) {
    var descriptor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_extract_field_descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, privateMap, "update");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_apply_descriptor_update$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(receiver, descriptor);
}
;
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/timeoutManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/timeoutManager.ts
__turbopack_context__.s([
    "TimeoutManager",
    ()=>TimeoutManager,
    "defaultTimeoutProvider",
    ()=>defaultTimeoutProvider,
    "systemSetTimeoutZero",
    ()=>systemSetTimeoutZero,
    "timeoutManager",
    ()=>timeoutManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
;
;
;
var // We cannot have TimeoutManager<T> as we must instantiate it with a concrete
// type at app boot; and if we leave that type, then any new timer provider
// would need to support ReturnType<typeof setTimeout>, which is infeasible.
//
// We settle for type safety for the TimeoutProvider type, and accept that
// this class is unsafe internally to allow for extension.
_provider, _providerCalled;
var defaultTimeoutProvider = {
    // We need the wrapper function syntax below instead of direct references to
    // global setTimeout etc.
    //
    // BAD: `setTimeout: setTimeout`
    // GOOD: `setTimeout: (cb, delay) => setTimeout(cb, delay)`
    //
    // If we use direct references here, then anything that wants to spy on or
    // replace the global setTimeout (like tests) won't work since we'll already
    // have a hard reference to the original implementation at the time when this
    // file was imported.
    setTimeout: (callback, delay)=>setTimeout(callback, delay),
    clearTimeout: (timeoutId)=>clearTimeout(timeoutId),
    setInterval: (callback, delay)=>setInterval(callback, delay),
    clearInterval: (intervalId)=>clearInterval(intervalId)
};
var TimeoutManager = (_provider = /*#__PURE__*/ new WeakMap(), _providerCalled = /*#__PURE__*/ new WeakMap(), class {
    setTimeoutProvider(provider) {
        if ("TURBOPACK compile-time truthy", 1) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _providerCalled) && provider !== (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _provider)) {
                console.error("[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.", {
                    previous: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _provider),
                    provider
                });
            }
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _provider, provider);
        if ("TURBOPACK compile-time truthy", 1) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _providerCalled, false);
        }
    }
    setTimeout(callback, delay) {
        if ("TURBOPACK compile-time truthy", 1) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _providerCalled, true);
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _provider).setTimeout(callback, delay);
    }
    clearTimeout(timeoutId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _provider).clearTimeout(timeoutId);
    }
    setInterval(callback, delay) {
        if ("TURBOPACK compile-time truthy", 1) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _providerCalled, true);
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _provider).setInterval(callback, delay);
    }
    clearInterval(intervalId) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _provider).clearInterval(intervalId);
    }
    constructor(){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _provider, {
            writable: true,
            value: defaultTimeoutProvider
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _providerCalled, {
            writable: true,
            value: false
        });
    }
});
var timeoutManager = new TimeoutManager();
function systemSetTimeoutZero(callback) {
    setTimeout(callback, 0);
}
;
 //# sourceMappingURL=timeoutManager.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/utils.ts
__turbopack_context__.s([
    "addToEnd",
    ()=>addToEnd,
    "addToStart",
    ()=>addToStart,
    "ensureQueryFn",
    ()=>ensureQueryFn,
    "functionalUpdate",
    ()=>functionalUpdate,
    "hashKey",
    ()=>hashKey,
    "hashQueryKeyByOptions",
    ()=>hashQueryKeyByOptions,
    "isPlainArray",
    ()=>isPlainArray,
    "isPlainObject",
    ()=>isPlainObject,
    "isServer",
    ()=>isServer,
    "isValidTimeout",
    ()=>isValidTimeout,
    "keepPreviousData",
    ()=>keepPreviousData,
    "matchMutation",
    ()=>matchMutation,
    "matchQuery",
    ()=>matchQuery,
    "noop",
    ()=>noop,
    "partialMatchKey",
    ()=>partialMatchKey,
    "replaceData",
    ()=>replaceData,
    "replaceEqualDeep",
    ()=>replaceEqualDeep,
    "resolveEnabled",
    ()=>resolveEnabled,
    "resolveStaleTime",
    ()=>resolveStaleTime,
    "shallowEqualObjects",
    ()=>shallowEqualObjects,
    "shouldThrowError",
    ()=>shouldThrowError,
    "skipToken",
    ()=>skipToken,
    "sleep",
    ()=>sleep,
    "timeUntilStale",
    ()=>timeUntilStale
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$timeoutManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/timeoutManager.js [app-client] (ecmascript)");
;
var isServer = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
function functionalUpdate(updater, input) {
    return typeof updater === "function" ? updater(input) : updater;
}
function isValidTimeout(value) {
    return typeof value === "number" && value >= 0 && value !== Infinity;
}
function timeUntilStale(updatedAt, staleTime) {
    return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function resolveStaleTime(staleTime, query) {
    return typeof staleTime === "function" ? staleTime(query) : staleTime;
}
function resolveEnabled(enabled, query) {
    return typeof enabled === "function" ? enabled(query) : enabled;
}
function matchQuery(filters, query) {
    const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
    if (queryKey) {
        if (exact) {
            if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) {
                return false;
            }
        } else if (!partialMatchKey(query.queryKey, queryKey)) {
            return false;
        }
    }
    if (type !== "all") {
        const isActive = query.isActive();
        if (type === "active" && !isActive) {
            return false;
        }
        if (type === "inactive" && isActive) {
            return false;
        }
    }
    if (typeof stale === "boolean" && query.isStale() !== stale) {
        return false;
    }
    if (fetchStatus && fetchStatus !== query.state.fetchStatus) {
        return false;
    }
    if (predicate && !predicate(query)) {
        return false;
    }
    return true;
}
function matchMutation(filters, mutation) {
    const { exact, status, predicate, mutationKey } = filters;
    if (mutationKey) {
        if (!mutation.options.mutationKey) {
            return false;
        }
        if (exact) {
            if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) {
                return false;
            }
        } else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) {
            return false;
        }
    }
    if (status && mutation.state.status !== status) {
        return false;
    }
    if (predicate && !predicate(mutation)) {
        return false;
    }
    return true;
}
function hashQueryKeyByOptions(queryKey, options) {
    const hashFn = (options === null || options === void 0 ? void 0 : options.queryKeyHashFn) || hashKey;
    return hashFn(queryKey);
}
function hashKey(queryKey) {
    return JSON.stringify(queryKey, (_, val)=>isPlainObject(val) ? Object.keys(val).sort().reduce((result, key)=>{
            result[key] = val[key];
            return result;
        }, {}) : val);
}
function partialMatchKey(a, b) {
    if (a === b) {
        return true;
    }
    if (typeof a !== typeof b) {
        return false;
    }
    if (a && b && typeof a === "object" && typeof b === "object") {
        return Object.keys(b).every((key)=>partialMatchKey(a[key], b[key]));
    }
    return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b) {
    if (a === b) {
        return a;
    }
    const array = isPlainArray(a) && isPlainArray(b);
    if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
    const aItems = array ? a : Object.keys(a);
    const aSize = aItems.length;
    const bItems = array ? b : Object.keys(b);
    const bSize = bItems.length;
    const copy = array ? new Array(bSize) : {};
    let equalItems = 0;
    for(let i = 0; i < bSize; i++){
        const key = array ? i : bItems[i];
        const aItem = a[key];
        const bItem = b[key];
        if (aItem === bItem) {
            copy[key] = aItem;
            if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
            continue;
        }
        if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
            copy[key] = bItem;
            continue;
        }
        const v = replaceEqualDeep(aItem, bItem);
        copy[key] = v;
        if (v === aItem) equalItems++;
    }
    return aSize === bSize && equalItems === aSize ? a : copy;
}
function shallowEqualObjects(a, b) {
    if (!b || Object.keys(a).length !== Object.keys(b).length) {
        return false;
    }
    for(const key in a){
        if (a[key] !== b[key]) {
            return false;
        }
    }
    return true;
}
function isPlainArray(value) {
    return Array.isArray(value) && value.length === Object.keys(value).length;
}
function isPlainObject(o) {
    if (!hasObjectPrototype(o)) {
        return false;
    }
    const ctor = o.constructor;
    if (ctor === void 0) {
        return true;
    }
    const prot = ctor.prototype;
    if (!hasObjectPrototype(prot)) {
        return false;
    }
    if (!prot.hasOwnProperty("isPrototypeOf")) {
        return false;
    }
    if (Object.getPrototypeOf(o) !== Object.prototype) {
        return false;
    }
    return true;
}
function hasObjectPrototype(o) {
    return Object.prototype.toString.call(o) === "[object Object]";
}
function sleep(timeout) {
    return new Promise((resolve)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$timeoutManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["timeoutManager"].setTimeout(resolve, timeout);
    });
}
function replaceData(prevData, data, options) {
    if (typeof options.structuralSharing === "function") {
        return options.structuralSharing(prevData, data);
    } else if (options.structuralSharing !== false) {
        if ("TURBOPACK compile-time truthy", 1) {
            try {
                return replaceEqualDeep(prevData, data);
            } catch (error) {
                console.error("Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [".concat(options.queryHash, "]: ").concat(error));
                throw error;
            }
        }
        return replaceEqualDeep(prevData, data);
    }
    return data;
}
function keepPreviousData(previousData) {
    return previousData;
}
function addToEnd(items, item) {
    let max = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0;
    const newItems = [
        ...items,
        item
    ];
    return max && newItems.length > max ? newItems.slice(1) : newItems;
}
function addToStart(items, item) {
    let max = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0;
    const newItems = [
        item,
        ...items
    ];
    return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
}
var skipToken = Symbol();
function ensureQueryFn(options, fetchOptions) {
    if ("TURBOPACK compile-time truthy", 1) {
        if (options.queryFn === skipToken) {
            console.error("Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '".concat(options.queryHash, "'"));
        }
    }
    if (!options.queryFn && (fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.initialPromise)) {
        return ()=>fetchOptions.initialPromise;
    }
    if (!options.queryFn || options.queryFn === skipToken) {
        return ()=>Promise.reject(new Error("Missing queryFn: '".concat(options.queryHash, "'")));
    }
    return options.queryFn;
}
function shouldThrowError(throwOnError, params) {
    if (typeof throwOnError === "function") {
        return throwOnError(...params);
    }
    return !!throwOnError;
}
;
 //# sourceMappingURL=utils.js.map
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_method_get.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_method_get
]);
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) throw new TypeError("attempted to get private field on non-instance");
    return fn;
}
;
}),
"[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_method_init.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_class_private_method_init
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_check_private_redeclaration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_check_private_redeclaration.js [app-client] (ecmascript)");
;
function _class_private_method_init(obj, privateSet) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_check_private_redeclaration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(obj, privateSet);
    privateSet.add(obj);
}
;
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/notifyManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/notifyManager.ts
__turbopack_context__.s([
    "createNotifyManager",
    ()=>createNotifyManager,
    "defaultScheduler",
    ()=>defaultScheduler,
    "notifyManager",
    ()=>notifyManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$timeoutManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/timeoutManager.js [app-client] (ecmascript)");
;
var defaultScheduler = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$timeoutManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["systemSetTimeoutZero"];
function createNotifyManager() {
    let queue = [];
    let transactions = 0;
    let notifyFn = (callback)=>{
        callback();
    };
    let batchNotifyFn = (callback)=>{
        callback();
    };
    let scheduleFn = defaultScheduler;
    const schedule = (callback)=>{
        if (transactions) {
            queue.push(callback);
        } else {
            scheduleFn(()=>{
                notifyFn(callback);
            });
        }
    };
    const flush = ()=>{
        const originalQueue = queue;
        queue = [];
        if (originalQueue.length) {
            scheduleFn(()=>{
                batchNotifyFn(()=>{
                    originalQueue.forEach((callback)=>{
                        notifyFn(callback);
                    });
                });
            });
        }
    };
    return {
        batch: (callback)=>{
            let result;
            transactions++;
            try {
                result = callback();
            } finally{
                transactions--;
                if (!transactions) {
                    flush();
                }
            }
            return result;
        },
        /**
     * All calls to the wrapped function will be batched.
     */ batchCalls: (callback)=>{
            return function() {
                for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                    args[_key] = arguments[_key];
                }
                schedule(()=>{
                    callback(...args);
                });
            };
        },
        schedule,
        /**
     * Use this method to set a custom notify function.
     * This can be used to for example wrap notifications with `React.act` while running tests.
     */ setNotifyFunction: (fn)=>{
            notifyFn = fn;
        },
        /**
     * Use this method to set a custom function to batch notifications together into a single tick.
     * By default React Query will use the batch function provided by ReactDOM or React Native.
     */ setBatchNotifyFunction: (fn)=>{
            batchNotifyFn = fn;
        },
        setScheduler: (fn)=>{
            scheduleFn = fn;
        }
    };
}
var notifyManager = createNotifyManager();
;
 //# sourceMappingURL=notifyManager.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/subscribable.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/subscribable.ts
__turbopack_context__.s([
    "Subscribable",
    ()=>Subscribable
]);
var Subscribable = class {
    subscribe(listener) {
        this.listeners.add(listener);
        this.onSubscribe();
        return ()=>{
            this.listeners.delete(listener);
            this.onUnsubscribe();
        };
    }
    hasListeners() {
        return this.listeners.size > 0;
    }
    onSubscribe() {}
    onUnsubscribe() {}
    constructor(){
        this.listeners = /* @__PURE__ */ new Set();
        this.subscribe = this.subscribe.bind(this);
    }
};
;
 //# sourceMappingURL=subscribable.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/focusManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/focusManager.ts
__turbopack_context__.s([
    "FocusManager",
    ()=>FocusManager,
    "focusManager",
    ()=>focusManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$subscribable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/subscribable.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
;
;
;
var _focused, _cleanup, _setup;
;
;
var FocusManager = (_focused = /*#__PURE__*/ new WeakMap(), _cleanup = /*#__PURE__*/ new WeakMap(), _setup = /*#__PURE__*/ new WeakMap(), class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$subscribable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Subscribable"] {
    onSubscribe() {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cleanup)) {
            this.setEventListener((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _setup));
        }
    }
    onUnsubscribe() {
        var _this, _this1, _ref;
        if (!this.hasListeners()) {
            (_this = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(_ref = _this1 = this, _cleanup)) === null || _this === void 0 ? void 0 : _this.call(_this1);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cleanup, void 0);
        }
    }
    setEventListener(setup) {
        var _this, _this1, _ref;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _setup, setup);
        (_this = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(_ref = _this1 = this, _cleanup)) === null || _this === void 0 ? void 0 : _this.call(_this1);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cleanup, setup((focused)=>{
            if (typeof focused === "boolean") {
                this.setFocused(focused);
            } else {
                this.onFocus();
            }
        }));
    }
    setFocused(focused) {
        const changed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _focused) !== focused;
        if (changed) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _focused, focused);
            this.onFocus();
        }
    }
    onFocus() {
        const isFocused = this.isFocused();
        this.listeners.forEach((listener)=>{
            listener(isFocused);
        });
    }
    isFocused() {
        var _globalThis_document;
        if (typeof (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _focused) === "boolean") {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _focused);
        }
        return ((_globalThis_document = globalThis.document) === null || _globalThis_document === void 0 ? void 0 : _globalThis_document.visibilityState) !== "hidden";
    }
    constructor(){
        super(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _focused, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cleanup, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _setup, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _setup, (onFocus)=>{
            if (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isServer"] && window.addEventListener) {
                const listener = ()=>onFocus();
                window.addEventListener("visibilitychange", listener, false);
                return ()=>{
                    window.removeEventListener("visibilitychange", listener);
                };
            }
            return;
        });
    }
});
var focusManager = new FocusManager();
;
 //# sourceMappingURL=focusManager.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/onlineManager.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/onlineManager.ts
__turbopack_context__.s([
    "OnlineManager",
    ()=>OnlineManager,
    "onlineManager",
    ()=>onlineManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$subscribable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/subscribable.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
;
;
;
var _online, _cleanup, _setup;
;
;
var OnlineManager = (_online = /*#__PURE__*/ new WeakMap(), _cleanup = /*#__PURE__*/ new WeakMap(), _setup = /*#__PURE__*/ new WeakMap(), class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$subscribable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Subscribable"] {
    onSubscribe() {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cleanup)) {
            this.setEventListener((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _setup));
        }
    }
    onUnsubscribe() {
        var _this, _this1, _ref;
        if (!this.hasListeners()) {
            (_this = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(_ref = _this1 = this, _cleanup)) === null || _this === void 0 ? void 0 : _this.call(_this1);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cleanup, void 0);
        }
    }
    setEventListener(setup) {
        var _this, _this1, _ref;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _setup, setup);
        (_this = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(_ref = _this1 = this, _cleanup)) === null || _this === void 0 ? void 0 : _this.call(_this1);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cleanup, setup(this.setOnline.bind(this)));
    }
    setOnline(online) {
        const changed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _online) !== online;
        if (changed) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _online, online);
            this.listeners.forEach((listener)=>{
                listener(online);
            });
        }
    }
    isOnline() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _online);
    }
    constructor(){
        super(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _online, {
            writable: true,
            value: true
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cleanup, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _setup, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _setup, (onOnline)=>{
            if (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isServer"] && window.addEventListener) {
                const onlineListener = ()=>onOnline(true);
                const offlineListener = ()=>onOnline(false);
                window.addEventListener("online", onlineListener, false);
                window.addEventListener("offline", offlineListener, false);
                return ()=>{
                    window.removeEventListener("online", onlineListener);
                    window.removeEventListener("offline", offlineListener);
                };
            }
            return;
        });
    }
});
var onlineManager = new OnlineManager();
;
 //# sourceMappingURL=onlineManager.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/thenable.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/thenable.ts
__turbopack_context__.s([
    "pendingThenable",
    ()=>pendingThenable,
    "tryResolveSync",
    ()=>tryResolveSync
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
;
function pendingThenable() {
    let resolve;
    let reject;
    const thenable = new Promise((_resolve, _reject)=>{
        resolve = _resolve;
        reject = _reject;
    });
    thenable.status = "pending";
    thenable.catch(()=>{});
    function finalize(data) {
        Object.assign(thenable, data);
        delete thenable.resolve;
        delete thenable.reject;
    }
    thenable.resolve = (value)=>{
        finalize({
            status: "fulfilled",
            value
        });
        resolve(value);
    };
    thenable.reject = (reason)=>{
        finalize({
            status: "rejected",
            reason
        });
        reject(reason);
    };
    return thenable;
}
function tryResolveSync(promise) {
    var _promise_then;
    let data;
    (_promise_then = promise.then((result)=>{
        data = result;
        return result;
    }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"])) === null || _promise_then === void 0 ? void 0 : _promise_then.catch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]);
    if (data !== void 0) {
        return {
            data
        };
    }
    return void 0;
}
;
 //# sourceMappingURL=thenable.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/retryer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/retryer.ts
__turbopack_context__.s([
    "CancelledError",
    ()=>CancelledError,
    "canFetch",
    ()=>canFetch,
    "createRetryer",
    ()=>createRetryer,
    "isCancelledError",
    ()=>isCancelledError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$focusManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/focusManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$onlineManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/onlineManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$thenable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/thenable.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
;
;
;
;
function defaultRetryDelay(failureCount) {
    return Math.min(1e3 * 2 ** failureCount, 3e4);
}
function canFetch(networkMode) {
    return (networkMode !== null && networkMode !== void 0 ? networkMode : "online") === "online" ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$onlineManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onlineManager"].isOnline() : true;
}
var CancelledError = class extends Error {
    constructor(options){
        super("CancelledError");
        this.revert = options === null || options === void 0 ? void 0 : options.revert;
        this.silent = options === null || options === void 0 ? void 0 : options.silent;
    }
};
function isCancelledError(value) {
    return value instanceof CancelledError;
}
function createRetryer(config) {
    let isRetryCancelled = false;
    let failureCount = 0;
    let continueFn;
    const thenable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$thenable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pendingThenable"])();
    const isResolved = ()=>thenable.status !== "pending";
    const cancel = (cancelOptions)=>{
        if (!isResolved()) {
            var _config_onCancel;
            const error = new CancelledError(cancelOptions);
            reject(error);
            (_config_onCancel = config.onCancel) === null || _config_onCancel === void 0 ? void 0 : _config_onCancel.call(config, error);
        }
    };
    const cancelRetry = ()=>{
        isRetryCancelled = true;
    };
    const continueRetry = ()=>{
        isRetryCancelled = false;
    };
    const canContinue = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$focusManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusManager"].isFocused() && (config.networkMode === "always" || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$onlineManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onlineManager"].isOnline()) && config.canRun();
    const canStart = ()=>canFetch(config.networkMode) && config.canRun();
    const resolve = (value)=>{
        if (!isResolved()) {
            continueFn === null || continueFn === void 0 ? void 0 : continueFn();
            thenable.resolve(value);
        }
    };
    const reject = (value)=>{
        if (!isResolved()) {
            continueFn === null || continueFn === void 0 ? void 0 : continueFn();
            thenable.reject(value);
        }
    };
    const pause = ()=>{
        return new Promise((continueResolve)=>{
            var _config_onPause;
            continueFn = (value)=>{
                if (isResolved() || canContinue()) {
                    continueResolve(value);
                }
            };
            (_config_onPause = config.onPause) === null || _config_onPause === void 0 ? void 0 : _config_onPause.call(config);
        }).then(()=>{
            continueFn = void 0;
            if (!isResolved()) {
                var _config_onContinue;
                (_config_onContinue = config.onContinue) === null || _config_onContinue === void 0 ? void 0 : _config_onContinue.call(config);
            }
        });
    };
    const run = ()=>{
        if (isResolved()) {
            return;
        }
        let promiseOrValue;
        const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
        try {
            promiseOrValue = initialPromise !== null && initialPromise !== void 0 ? initialPromise : config.fn();
        } catch (error) {
            promiseOrValue = Promise.reject(error);
        }
        Promise.resolve(promiseOrValue).then(resolve).catch((error)=>{
            var _config_onFail;
            if (isResolved()) {
                return;
            }
            var _config_retry;
            const retry = (_config_retry = config.retry) !== null && _config_retry !== void 0 ? _config_retry : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isServer"] ? 0 : 3;
            var _config_retryDelay;
            const retryDelay = (_config_retryDelay = config.retryDelay) !== null && _config_retryDelay !== void 0 ? _config_retryDelay : defaultRetryDelay;
            const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
            const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
            if (isRetryCancelled || !shouldRetry) {
                reject(error);
                return;
            }
            failureCount++;
            (_config_onFail = config.onFail) === null || _config_onFail === void 0 ? void 0 : _config_onFail.call(config, failureCount, error);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sleep"])(delay).then(()=>{
                return canContinue() ? void 0 : pause();
            }).then(()=>{
                if (isRetryCancelled) {
                    reject(error);
                } else {
                    run();
                }
            });
        });
    };
    return {
        promise: thenable,
        status: ()=>thenable.status,
        cancel,
        continue: ()=>{
            continueFn === null || continueFn === void 0 ? void 0 : continueFn();
            return thenable;
        },
        cancelRetry,
        continueRetry,
        canStart,
        start: ()=>{
            if (canStart()) {
                run();
            } else {
                pause().then(run);
            }
            return thenable;
        }
    };
}
;
 //# sourceMappingURL=retryer.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/removable.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/removable.ts
__turbopack_context__.s([
    "Removable",
    ()=>Removable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$timeoutManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/timeoutManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
;
;
;
var _gcTimeout;
;
;
var Removable = (_gcTimeout = /*#__PURE__*/ new WeakMap(), class {
    destroy() {
        this.clearGcTimeout();
    }
    scheduleGc() {
        this.clearGcTimeout();
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidTimeout"])(this.gcTime)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _gcTimeout, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$timeoutManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["timeoutManager"].setTimeout(()=>{
                this.optionalRemove();
            }, this.gcTime));
        }
    }
    updateGcTime(newGcTime) {
        this.gcTime = Math.max(this.gcTime || 0, newGcTime !== null && newGcTime !== void 0 ? newGcTime : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isServer"] ? Infinity : 5 * 60 * 1e3);
    }
    clearGcTimeout() {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _gcTimeout)) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$timeoutManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["timeoutManager"].clearTimeout((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _gcTimeout));
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _gcTimeout, void 0);
        }
    }
    constructor(){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _gcTimeout, {
            writable: true,
            value: void 0
        });
    }
});
;
 //# sourceMappingURL=removable.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/query.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/query.ts
__turbopack_context__.s([
    "Query",
    ()=>Query,
    "fetchState",
    ()=>fetchState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_method_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_method_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/notifyManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$retryer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/retryer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$removable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/removable.js [app-client] (ecmascript)");
;
;
;
;
;
var _initialState, _revertState, _cache, _client, _retryer, _defaultOptions, _abortSignalConsumed, _dispatch, _class;
;
;
;
;
var Query = (_initialState = /*#__PURE__*/ new WeakMap(), _revertState = /*#__PURE__*/ new WeakMap(), _cache = /*#__PURE__*/ new WeakMap(), _client = /*#__PURE__*/ new WeakMap(), _retryer = /*#__PURE__*/ new WeakMap(), _defaultOptions = /*#__PURE__*/ new WeakMap(), _abortSignalConsumed = /*#__PURE__*/ new WeakMap(), _dispatch = /*#__PURE__*/ new WeakSet(), _class = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$removable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Removable"] {
    get meta() {
        return this.options.meta;
    }
    get promise() {
        var _class_private_field_get;
        return (_class_private_field_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) === null || _class_private_field_get === void 0 ? void 0 : _class_private_field_get.promise;
    }
    setOptions(options) {
        this.options = {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions),
            ...options
        };
        this.updateGcTime(this.options.gcTime);
        if (this.state && this.state.data === void 0) {
            const defaultState = getDefaultState(this.options);
            if (defaultState.data !== void 0) {
                this.setData(defaultState.data, {
                    updatedAt: defaultState.dataUpdatedAt,
                    manual: true
                });
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _initialState, defaultState);
            }
        }
    }
    optionalRemove() {
        if (!this.observers.length && this.state.fetchStatus === "idle") {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache).remove(this);
        }
    }
    setData(newData, options) {
        const data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceData"])(this.state.data, newData, this.options);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
            data,
            type: "success",
            dataUpdatedAt: options === null || options === void 0 ? void 0 : options.updatedAt,
            manual: options === null || options === void 0 ? void 0 : options.manual
        });
        return data;
    }
    setState(state, setStateOptions) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
            type: "setState",
            state,
            setStateOptions
        });
    }
    cancel(options) {
        var _class_private_field_get, _class_private_field_get1;
        const promise = (_class_private_field_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) === null || _class_private_field_get === void 0 ? void 0 : _class_private_field_get.promise;
        (_class_private_field_get1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) === null || _class_private_field_get1 === void 0 ? void 0 : _class_private_field_get1.cancel(options);
        return promise ? promise.then(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]).catch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]) : Promise.resolve();
    }
    destroy() {
        super.destroy();
        this.cancel({
            silent: true
        });
    }
    reset() {
        this.destroy();
        this.setState((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _initialState));
    }
    isActive() {
        return this.observers.some((observer)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveEnabled"])(observer.options.enabled, this) !== false);
    }
    isDisabled() {
        if (this.getObserversCount() > 0) {
            return !this.isActive();
        }
        return this.options.queryFn === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["skipToken"] || this.state.dataUpdateCount + this.state.errorUpdateCount === 0;
    }
    isStatic() {
        if (this.getObserversCount() > 0) {
            return this.observers.some((observer)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveStaleTime"])(observer.options.staleTime, this) === "static");
        }
        return false;
    }
    isStale() {
        if (this.getObserversCount() > 0) {
            return this.observers.some((observer)=>observer.getCurrentResult().isStale);
        }
        return this.state.data === void 0 || this.state.isInvalidated;
    }
    isStaleByTime() {
        let staleTime = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
        if (this.state.data === void 0) {
            return true;
        }
        if (staleTime === "static") {
            return false;
        }
        if (this.state.isInvalidated) {
            return true;
        }
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["timeUntilStale"])(this.state.dataUpdatedAt, staleTime);
    }
    onFocus() {
        var _class_private_field_get;
        const observer = this.observers.find((x)=>x.shouldFetchOnWindowFocus());
        observer === null || observer === void 0 ? void 0 : observer.refetch({
            cancelRefetch: false
        });
        (_class_private_field_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) === null || _class_private_field_get === void 0 ? void 0 : _class_private_field_get.continue();
    }
    onOnline() {
        var _class_private_field_get;
        const observer = this.observers.find((x)=>x.shouldFetchOnReconnect());
        observer === null || observer === void 0 ? void 0 : observer.refetch({
            cancelRefetch: false
        });
        (_class_private_field_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) === null || _class_private_field_get === void 0 ? void 0 : _class_private_field_get.continue();
    }
    addObserver(observer) {
        if (!this.observers.includes(observer)) {
            this.observers.push(observer);
            this.clearGcTimeout();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache).notify({
                type: "observerAdded",
                query: this,
                observer
            });
        }
    }
    removeObserver(observer) {
        if (this.observers.includes(observer)) {
            this.observers = this.observers.filter((x)=>x !== observer);
            if (!this.observers.length) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) {
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _abortSignalConsumed)) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer).cancel({
                            revert: true
                        });
                    } else {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer).cancelRetry();
                    }
                }
                this.scheduleGc();
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache).notify({
                type: "observerRemoved",
                query: this,
                observer
            });
        }
    }
    getObserversCount() {
        return this.observers.length;
    }
    invalidate() {
        if (!this.state.isInvalidated) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                type: "invalidate"
            });
        }
    }
    async fetch(options, fetchOptions) {
        var _class_private_field_get, _this_options_behavior, _context_fetchOptions;
        if (this.state.fetchStatus !== "idle" && // If the promise in the retyer is already rejected, we have to definitely
        // re-start the fetch; there is a chance that the query is still in a
        // pending state when that happens
        ((_class_private_field_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) === null || _class_private_field_get === void 0 ? void 0 : _class_private_field_get.status()) !== "rejected") {
            if (this.state.data !== void 0 && (fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.cancelRefetch)) {
                this.cancel({
                    silent: true
                });
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer).continueRetry();
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer).promise;
            }
        }
        if (options) {
            this.setOptions(options);
        }
        if (!this.options.queryFn) {
            const observer = this.observers.find((x)=>x.options.queryFn);
            if (observer) {
                this.setOptions(observer.options);
            }
        }
        if ("TURBOPACK compile-time truthy", 1) {
            if (!Array.isArray(this.options.queryKey)) {
                console.error("As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']");
            }
        }
        const abortController = new AbortController();
        const addSignalProperty = (object)=>{
            Object.defineProperty(object, "signal", {
                enumerable: true,
                get: ()=>{
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _abortSignalConsumed, true);
                    return abortController.signal;
                }
            });
        };
        const fetchFn = ()=>{
            const queryFn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureQueryFn"])(this.options, fetchOptions);
            const createQueryFnContext = ()=>{
                const queryFnContext2 = {
                    client: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _client),
                    queryKey: this.queryKey,
                    meta: this.meta
                };
                addSignalProperty(queryFnContext2);
                return queryFnContext2;
            };
            const queryFnContext = createQueryFnContext();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _abortSignalConsumed, false);
            if (this.options.persister) {
                return this.options.persister(queryFn, queryFnContext, this);
            }
            return queryFn(queryFnContext);
        };
        const createFetchContext = ()=>{
            const context2 = {
                fetchOptions,
                options: this.options,
                queryKey: this.queryKey,
                client: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _client),
                state: this.state,
                fetchFn
            };
            addSignalProperty(context2);
            return context2;
        };
        const context = createFetchContext();
        (_this_options_behavior = this.options.behavior) === null || _this_options_behavior === void 0 ? void 0 : _this_options_behavior.onFetch(context, this);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _revertState, this.state);
        if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== ((_context_fetchOptions = context.fetchOptions) === null || _context_fetchOptions === void 0 ? void 0 : _context_fetchOptions.meta)) {
            var _context_fetchOptions1;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                type: "fetch",
                meta: (_context_fetchOptions1 = context.fetchOptions) === null || _context_fetchOptions1 === void 0 ? void 0 : _context_fetchOptions1.meta
            });
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$retryer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRetryer"])({
            initialPromise: fetchOptions === null || fetchOptions === void 0 ? void 0 : fetchOptions.initialPromise,
            fn: context.fetchFn,
            onCancel: (error)=>{
                if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$retryer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CancelledError"] && error.revert) {
                    this.setState({
                        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _revertState),
                        fetchStatus: "idle"
                    });
                }
                abortController.abort();
            },
            onFail: (failureCount, error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                    type: "failed",
                    failureCount,
                    error
                });
            },
            onPause: ()=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                    type: "pause"
                });
            },
            onContinue: ()=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                    type: "continue"
                });
            },
            retry: context.options.retry,
            retryDelay: context.options.retryDelay,
            networkMode: context.options.networkMode,
            canRun: ()=>true
        }));
        try {
            var _class_private_field_get_config_onSuccess, _class_private_field_get_config, _class_private_field_get_config_onSettled, _class_private_field_get_config1;
            const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer).start();
            if (data === void 0) {
                if ("TURBOPACK compile-time truthy", 1) {
                    console.error("Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ".concat(this.queryHash));
                }
                throw new Error("".concat(this.queryHash, " data is undefined"));
            }
            this.setData(data);
            (_class_private_field_get_config_onSuccess = (_class_private_field_get_config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache).config).onSuccess) === null || _class_private_field_get_config_onSuccess === void 0 ? void 0 : _class_private_field_get_config_onSuccess.call(_class_private_field_get_config, data, this);
            (_class_private_field_get_config_onSettled = (_class_private_field_get_config1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache).config).onSettled) === null || _class_private_field_get_config_onSettled === void 0 ? void 0 : _class_private_field_get_config_onSettled.call(_class_private_field_get_config1, data, this.state.error, this);
            return data;
        } catch (error) {
            var _class_private_field_get_config_onError, _class_private_field_get_config2, _class_private_field_get_config_onSettled1, _class_private_field_get_config3;
            if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$retryer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CancelledError"]) {
                if (error.silent) {
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer).promise;
                } else if (error.revert) {
                    if (this.state.data === void 0) {
                        throw error;
                    }
                    return this.state.data;
                }
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                type: "error",
                error
            });
            (_class_private_field_get_config_onError = (_class_private_field_get_config2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache).config).onError) === null || _class_private_field_get_config_onError === void 0 ? void 0 : _class_private_field_get_config_onError.call(_class_private_field_get_config2, error, this);
            (_class_private_field_get_config_onSettled1 = (_class_private_field_get_config3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache).config).onSettled) === null || _class_private_field_get_config_onSettled1 === void 0 ? void 0 : _class_private_field_get_config_onSettled1.call(_class_private_field_get_config3, this.state.data, error, this);
            throw error;
        } finally{
            this.scheduleGc();
        }
    }
    constructor(config){
        super(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _initialState, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _revertState, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _client, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _abortSignalConsumed, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _abortSignalConsumed, false);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions, config.defaultOptions);
        this.setOptions(config.options);
        this.observers = [];
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _client, config.client);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _client).getQueryCache());
        this.queryKey = config.queryKey;
        this.queryHash = config.queryHash;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _initialState, getDefaultState(this.options));
        var _config_state;
        this.state = (_config_state = config.state) !== null && _config_state !== void 0 ? _config_state : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _initialState);
        this.scheduleGc();
    }
}, _class);
function fetchState(data, options) {
    return {
        fetchFailureCount: 0,
        fetchFailureReason: null,
        fetchStatus: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$retryer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canFetch"])(options.networkMode) ? "fetching" : "paused",
        ...data === void 0 && {
            error: null,
            status: "pending"
        }
    };
}
function getDefaultState(options) {
    const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
    const hasData = data !== void 0;
    const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
    return {
        data,
        dataUpdateCount: 0,
        dataUpdatedAt: hasData ? initialDataUpdatedAt !== null && initialDataUpdatedAt !== void 0 ? initialDataUpdatedAt : Date.now() : 0,
        error: null,
        errorUpdateCount: 0,
        errorUpdatedAt: 0,
        fetchFailureCount: 0,
        fetchFailureReason: null,
        fetchMeta: null,
        isInvalidated: false,
        status: hasData ? "success" : "pending",
        fetchStatus: "idle"
    };
}
;
function dispatch(action) {
    const reducer = (state)=>{
        switch(action.type){
            case "failed":
                return {
                    ...state,
                    fetchFailureCount: action.failureCount,
                    fetchFailureReason: action.error
                };
            case "pause":
                return {
                    ...state,
                    fetchStatus: "paused"
                };
            case "continue":
                return {
                    ...state,
                    fetchStatus: "fetching"
                };
            case "fetch":
                var _action_meta;
                return {
                    ...state,
                    ...fetchState(state.data, this.options),
                    fetchMeta: (_action_meta = action.meta) !== null && _action_meta !== void 0 ? _action_meta : null
                };
            case "success":
                var _action_dataUpdatedAt;
                const newState = {
                    ...state,
                    data: action.data,
                    dataUpdateCount: state.dataUpdateCount + 1,
                    dataUpdatedAt: (_action_dataUpdatedAt = action.dataUpdatedAt) !== null && _action_dataUpdatedAt !== void 0 ? _action_dataUpdatedAt : Date.now(),
                    error: null,
                    isInvalidated: false,
                    status: "success",
                    ...!action.manual && {
                        fetchStatus: "idle",
                        fetchFailureCount: 0,
                        fetchFailureReason: null
                    }
                };
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _revertState, action.manual ? newState : void 0);
                return newState;
            case "error":
                const error = action.error;
                return {
                    ...state,
                    error,
                    errorUpdateCount: state.errorUpdateCount + 1,
                    errorUpdatedAt: Date.now(),
                    fetchFailureCount: state.fetchFailureCount + 1,
                    fetchFailureReason: error,
                    fetchStatus: "idle",
                    status: "error"
                };
            case "invalidate":
                return {
                    ...state,
                    isInvalidated: true
                };
            case "setState":
                return {
                    ...state,
                    ...action.state
                };
        }
    };
    this.state = reducer(this.state);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
        this.observers.forEach((observer)=>{
            observer.onQueryUpdate();
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _cache).notify({
            query: this,
            type: "updated",
            action
        });
    });
}
 //# sourceMappingURL=query.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/queryCache.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/queryCache.ts
__turbopack_context__.s([
    "QueryCache",
    ()=>QueryCache
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/query.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/notifyManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$subscribable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/subscribable.js [app-client] (ecmascript)");
;
;
;
var _queries;
;
;
;
;
var QueryCache = (_queries = /*#__PURE__*/ new WeakMap(), class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$subscribable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Subscribable"] {
    build(client, options, state) {
        const queryKey = options.queryKey;
        var _options_queryHash;
        const queryHash = (_options_queryHash = options.queryHash) !== null && _options_queryHash !== void 0 ? _options_queryHash : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hashQueryKeyByOptions"])(queryKey, options);
        let query = this.get(queryHash);
        if (!query) {
            query = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Query"]({
                client,
                queryKey,
                queryHash,
                options: client.defaultQueryOptions(options),
                state,
                defaultOptions: client.getQueryDefaults(queryKey)
            });
            this.add(query);
        }
        return query;
    }
    add(query) {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queries).has(query.queryHash)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queries).set(query.queryHash, query);
            this.notify({
                type: "added",
                query
            });
        }
    }
    remove(query) {
        const queryInMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queries).get(query.queryHash);
        if (queryInMap) {
            query.destroy();
            if (queryInMap === query) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queries).delete(query.queryHash);
            }
            this.notify({
                type: "removed",
                query
            });
        }
    }
    clear() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            this.getAll().forEach((query)=>{
                this.remove(query);
            });
        });
    }
    get(queryHash) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queries).get(queryHash);
    }
    getAll() {
        return [
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queries).values()
        ];
    }
    find(filters) {
        const defaultedFilters = {
            exact: true,
            ...filters
        };
        return this.getAll().find((query)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchQuery"])(defaultedFilters, query));
    }
    findAll() {
        let filters = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        const queries = this.getAll();
        return Object.keys(filters).length > 0 ? queries.filter((query)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchQuery"])(filters, query)) : queries;
    }
    notify(event) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            this.listeners.forEach((listener)=>{
                listener(event);
            });
        });
    }
    onFocus() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            this.getAll().forEach((query)=>{
                query.onFocus();
            });
        });
    }
    onOnline() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            this.getAll().forEach((query)=>{
                query.onOnline();
            });
        });
    }
    constructor(config = {}){
        super(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queries, {
            writable: true,
            value: void 0
        });
        this.config = config;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queries, /* @__PURE__ */ new Map());
    }
});
;
 //# sourceMappingURL=queryCache.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/mutation.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/mutation.ts
__turbopack_context__.s([
    "Mutation",
    ()=>Mutation,
    "getDefaultState",
    ()=>getDefaultState
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_method_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_method_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/notifyManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$removable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/removable.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$retryer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/retryer.js [app-client] (ecmascript)");
;
;
;
;
;
var _client, _observers, _mutationCache, _retryer, _dispatch, _class;
;
;
;
var Mutation = (_client = /*#__PURE__*/ new WeakMap(), _observers = /*#__PURE__*/ new WeakMap(), _mutationCache = /*#__PURE__*/ new WeakMap(), _retryer = /*#__PURE__*/ new WeakMap(), _dispatch = /*#__PURE__*/ new WeakSet(), _class = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$removable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Removable"] {
    setOptions(options) {
        this.options = options;
        this.updateGcTime(this.options.gcTime);
    }
    get meta() {
        return this.options.meta;
    }
    addObserver(observer) {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _observers).includes(observer)) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _observers).push(observer);
            this.clearGcTimeout();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).notify({
                type: "observerAdded",
                mutation: this,
                observer
            });
        }
    }
    removeObserver(observer) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _observers, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _observers).filter((x)=>x !== observer));
        this.scheduleGc();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).notify({
            type: "observerRemoved",
            mutation: this,
            observer
        });
    }
    optionalRemove() {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _observers).length) {
            if (this.state.status === "pending") {
                this.scheduleGc();
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).remove(this);
            }
        }
    }
    continue() {
        var _class_private_field_get;
        var _class_private_field_get_continue;
        return (_class_private_field_get_continue = (_class_private_field_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer)) === null || _class_private_field_get === void 0 ? void 0 : _class_private_field_get.continue()) !== null && _class_private_field_get_continue !== void 0 ? _class_private_field_get_continue : // continuing a mutation assumes that variables are set, mutation must have been dehydrated before
        this.execute(this.state.variables);
    }
    async execute(variables) {
        const onContinue = ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                type: "continue"
            });
        };
        const mutationFnContext = {
            client: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _client),
            meta: this.options.meta,
            mutationKey: this.options.mutationKey
        };
        var _this_options_retry;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$retryer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRetryer"])({
            fn: ()=>{
                if (!this.options.mutationFn) {
                    return Promise.reject(new Error("No mutationFn found"));
                }
                return this.options.mutationFn(variables, mutationFnContext);
            },
            onFail: (failureCount, error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                    type: "failed",
                    failureCount,
                    error
                });
            },
            onPause: ()=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                    type: "pause"
                });
            },
            onContinue,
            retry: (_this_options_retry = this.options.retry) !== null && _this_options_retry !== void 0 ? _this_options_retry : 0,
            retryDelay: this.options.retryDelay,
            networkMode: this.options.networkMode,
            canRun: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).canRun(this)
        }));
        const restored = this.state.status === "pending";
        const isPaused = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer).canStart();
        try {
            var _class_private_field_get_config_onSuccess, _class_private_field_get_config, _this_options_onSuccess, _this_options, _class_private_field_get_config_onSettled, _class_private_field_get_config1, _this_options_onSettled, _this_options1;
            if (restored) {
                onContinue();
            } else {
                var _class_private_field_get_config_onMutate, _class_private_field_get_config2, _this_options_onMutate, _this_options2;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                    type: "pending",
                    variables,
                    isPaused
                });
                await ((_class_private_field_get_config_onMutate = (_class_private_field_get_config2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).config).onMutate) === null || _class_private_field_get_config_onMutate === void 0 ? void 0 : _class_private_field_get_config_onMutate.call(_class_private_field_get_config2, variables, this, mutationFnContext));
                const context = await ((_this_options_onMutate = (_this_options2 = this.options).onMutate) === null || _this_options_onMutate === void 0 ? void 0 : _this_options_onMutate.call(_this_options2, variables, mutationFnContext));
                if (context !== this.state.context) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                        type: "pending",
                        context,
                        variables,
                        isPaused
                    });
                }
            }
            const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer).start();
            await ((_class_private_field_get_config_onSuccess = (_class_private_field_get_config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).config).onSuccess) === null || _class_private_field_get_config_onSuccess === void 0 ? void 0 : _class_private_field_get_config_onSuccess.call(_class_private_field_get_config, data, variables, this.state.context, this, mutationFnContext));
            await ((_this_options_onSuccess = (_this_options = this.options).onSuccess) === null || _this_options_onSuccess === void 0 ? void 0 : _this_options_onSuccess.call(_this_options, data, variables, this.state.context, mutationFnContext));
            await ((_class_private_field_get_config_onSettled = (_class_private_field_get_config1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).config).onSettled) === null || _class_private_field_get_config_onSettled === void 0 ? void 0 : _class_private_field_get_config_onSettled.call(_class_private_field_get_config1, data, null, this.state.variables, this.state.context, this, mutationFnContext));
            await ((_this_options_onSettled = (_this_options1 = this.options).onSettled) === null || _this_options_onSettled === void 0 ? void 0 : _this_options_onSettled.call(_this_options1, data, null, variables, this.state.context, mutationFnContext));
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                type: "success",
                data
            });
            return data;
        } catch (error) {
            try {
                var _class_private_field_get_config_onError, _class_private_field_get_config3, _this_options_onError, _this_options3, _class_private_field_get_config_onSettled1, _class_private_field_get_config4, _this_options_onSettled1, _this_options4;
                await ((_class_private_field_get_config_onError = (_class_private_field_get_config3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).config).onError) === null || _class_private_field_get_config_onError === void 0 ? void 0 : _class_private_field_get_config_onError.call(_class_private_field_get_config3, error, variables, this.state.context, this, mutationFnContext));
                await ((_this_options_onError = (_this_options3 = this.options).onError) === null || _this_options_onError === void 0 ? void 0 : _this_options_onError.call(_this_options3, error, variables, this.state.context, mutationFnContext));
                await ((_class_private_field_get_config_onSettled1 = (_class_private_field_get_config4 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).config).onSettled) === null || _class_private_field_get_config_onSettled1 === void 0 ? void 0 : _class_private_field_get_config_onSettled1.call(_class_private_field_get_config4, void 0, error, this.state.variables, this.state.context, this, mutationFnContext));
                await ((_this_options_onSettled1 = (_this_options4 = this.options).onSettled) === null || _this_options_onSettled1 === void 0 ? void 0 : _this_options_onSettled1.call(_this_options4, void 0, error, variables, this.state.context, mutationFnContext));
                throw error;
            } finally{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch, dispatch).call(this, {
                    type: "error",
                    error
                });
            }
        } finally{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).runNext(this);
        }
    }
    constructor(config){
        super(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_method_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _dispatch), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _client, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _observers, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _retryer, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _client, config.client);
        this.mutationId = config.mutationId;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache, config.mutationCache);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _observers, []);
        this.state = config.state || getDefaultState();
        this.setOptions(config.options);
        this.scheduleGc();
    }
}, _class);
function getDefaultState() {
    return {
        context: void 0,
        data: void 0,
        error: null,
        failureCount: 0,
        failureReason: null,
        isPaused: false,
        status: "idle",
        variables: void 0,
        submittedAt: 0
    };
}
;
function dispatch(action) {
    const reducer = (state)=>{
        switch(action.type){
            case "failed":
                return {
                    ...state,
                    failureCount: action.failureCount,
                    failureReason: action.error
                };
            case "pause":
                return {
                    ...state,
                    isPaused: true
                };
            case "continue":
                return {
                    ...state,
                    isPaused: false
                };
            case "pending":
                return {
                    ...state,
                    context: action.context,
                    data: void 0,
                    failureCount: 0,
                    failureReason: null,
                    error: null,
                    isPaused: action.isPaused,
                    status: "pending",
                    variables: action.variables,
                    submittedAt: Date.now()
                };
            case "success":
                return {
                    ...state,
                    data: action.data,
                    failureCount: 0,
                    failureReason: null,
                    error: null,
                    status: "success",
                    isPaused: false
                };
            case "error":
                return {
                    ...state,
                    data: void 0,
                    error: action.error,
                    failureCount: state.failureCount + 1,
                    failureReason: action.error,
                    isPaused: false,
                    status: "error"
                };
        }
    };
    this.state = reducer(this.state);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _observers).forEach((observer)=>{
            observer.onMutationUpdate(action);
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).notify({
            mutation: this,
            type: "updated",
            action
        });
    });
}
 //# sourceMappingURL=mutation.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/mutationCache.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/mutationCache.ts
__turbopack_context__.s([
    "MutationCache",
    ()=>MutationCache
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_update$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_update.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/notifyManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$mutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/mutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$subscribable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/subscribable.js [app-client] (ecmascript)");
;
;
;
;
var _mutations, _scopes, _mutationId;
;
;
;
;
var MutationCache = (_mutations = /*#__PURE__*/ new WeakMap(), _scopes = /*#__PURE__*/ new WeakMap(), _mutationId = /*#__PURE__*/ new WeakMap(), class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$subscribable$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Subscribable"] {
    build(client, options, state) {
        const mutation = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$mutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Mutation"]({
            client,
            mutationCache: this,
            mutationId: ++(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_update$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationId).value,
            options: client.defaultMutationOptions(options),
            state
        });
        this.add(mutation);
        return mutation;
    }
    add(mutation) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutations).add(mutation);
        const scope = scopeFor(mutation);
        if (typeof scope === "string") {
            const scopedMutations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes).get(scope);
            if (scopedMutations) {
                scopedMutations.push(mutation);
            } else {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes).set(scope, [
                    mutation
                ]);
            }
        }
        this.notify({
            type: "added",
            mutation
        });
    }
    remove(mutation) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutations).delete(mutation)) {
            const scope = scopeFor(mutation);
            if (typeof scope === "string") {
                const scopedMutations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes).get(scope);
                if (scopedMutations) {
                    if (scopedMutations.length > 1) {
                        const index = scopedMutations.indexOf(mutation);
                        if (index !== -1) {
                            scopedMutations.splice(index, 1);
                        }
                    } else if (scopedMutations[0] === mutation) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes).delete(scope);
                    }
                }
            }
        }
        this.notify({
            type: "removed",
            mutation
        });
    }
    canRun(mutation) {
        const scope = scopeFor(mutation);
        if (typeof scope === "string") {
            const mutationsWithSameScope = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes).get(scope);
            const firstPendingMutation = mutationsWithSameScope === null || mutationsWithSameScope === void 0 ? void 0 : mutationsWithSameScope.find((m)=>m.state.status === "pending");
            return !firstPendingMutation || firstPendingMutation === mutation;
        } else {
            return true;
        }
    }
    runNext(mutation) {
        const scope = scopeFor(mutation);
        if (typeof scope === "string") {
            var _class_private_field_get_get;
            const foundMutation = (_class_private_field_get_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes).get(scope)) === null || _class_private_field_get_get === void 0 ? void 0 : _class_private_field_get_get.find((m)=>m !== mutation && m.state.isPaused);
            var _foundMutation_continue;
            return (_foundMutation_continue = foundMutation === null || foundMutation === void 0 ? void 0 : foundMutation.continue()) !== null && _foundMutation_continue !== void 0 ? _foundMutation_continue : Promise.resolve();
        } else {
            return Promise.resolve();
        }
    }
    clear() {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutations).forEach((mutation)=>{
                this.notify({
                    type: "removed",
                    mutation
                });
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutations).clear();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes).clear();
        });
    }
    getAll() {
        return Array.from((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutations));
    }
    find(filters) {
        const defaultedFilters = {
            exact: true,
            ...filters
        };
        return this.getAll().find((mutation)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchMutation"])(defaultedFilters, mutation));
    }
    findAll() {
        let filters = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return this.getAll().filter((mutation)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchMutation"])(filters, mutation));
    }
    notify(event) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            this.listeners.forEach((listener)=>{
                listener(event);
            });
        });
    }
    resumePausedMutations() {
        const pausedMutations = this.getAll().filter((x)=>x.state.isPaused);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>Promise.all(pausedMutations.map((mutation)=>mutation.continue().catch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]))));
    }
    constructor(config = {}){
        super(), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutations, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes, {
            writable: true,
            value: void 0
        }), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationId, {
            writable: true,
            value: void 0
        });
        this.config = config;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutations, /* @__PURE__ */ new Set());
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _scopes, /* @__PURE__ */ new Map());
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationId, 0);
    }
});
function scopeFor(mutation) {
    var _mutation_options_scope;
    return (_mutation_options_scope = mutation.options.scope) === null || _mutation_options_scope === void 0 ? void 0 : _mutation_options_scope.id;
}
;
 //# sourceMappingURL=mutationCache.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/infiniteQueryBehavior.ts
__turbopack_context__.s([
    "hasNextPage",
    ()=>hasNextPage,
    "hasPreviousPage",
    ()=>hasPreviousPage,
    "infiniteQueryBehavior",
    ()=>infiniteQueryBehavior
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
;
function infiniteQueryBehavior(pages) {
    return {
        onFetch: (context, query)=>{
            var _context_fetchOptions_meta_fetchMore, _context_fetchOptions_meta, _context_fetchOptions, _context_state_data, _context_state_data1;
            const options = context.options;
            const direction = (_context_fetchOptions = context.fetchOptions) === null || _context_fetchOptions === void 0 ? void 0 : (_context_fetchOptions_meta = _context_fetchOptions.meta) === null || _context_fetchOptions_meta === void 0 ? void 0 : (_context_fetchOptions_meta_fetchMore = _context_fetchOptions_meta.fetchMore) === null || _context_fetchOptions_meta_fetchMore === void 0 ? void 0 : _context_fetchOptions_meta_fetchMore.direction;
            const oldPages = ((_context_state_data = context.state.data) === null || _context_state_data === void 0 ? void 0 : _context_state_data.pages) || [];
            const oldPageParams = ((_context_state_data1 = context.state.data) === null || _context_state_data1 === void 0 ? void 0 : _context_state_data1.pageParams) || [];
            let result = {
                pages: [],
                pageParams: []
            };
            let currentPage = 0;
            const fetchFn = async ()=>{
                let cancelled = false;
                const addSignalProperty = (object)=>{
                    Object.defineProperty(object, "signal", {
                        enumerable: true,
                        get: ()=>{
                            if (context.signal.aborted) {
                                cancelled = true;
                            } else {
                                context.signal.addEventListener("abort", ()=>{
                                    cancelled = true;
                                });
                            }
                            return context.signal;
                        }
                    });
                };
                const queryFn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureQueryFn"])(context.options, context.fetchOptions);
                const fetchPage = async (data, param, previous)=>{
                    if (cancelled) {
                        return Promise.reject();
                    }
                    if (param == null && data.pages.length) {
                        return Promise.resolve(data);
                    }
                    const createQueryFnContext = ()=>{
                        const queryFnContext2 = {
                            client: context.client,
                            queryKey: context.queryKey,
                            pageParam: param,
                            direction: previous ? "backward" : "forward",
                            meta: context.options.meta
                        };
                        addSignalProperty(queryFnContext2);
                        return queryFnContext2;
                    };
                    const queryFnContext = createQueryFnContext();
                    const page = await queryFn(queryFnContext);
                    const { maxPages } = context.options;
                    const addTo = previous ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addToStart"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addToEnd"];
                    return {
                        pages: addTo(data.pages, page, maxPages),
                        pageParams: addTo(data.pageParams, param, maxPages)
                    };
                };
                if (direction && oldPages.length) {
                    const previous = direction === "backward";
                    const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
                    const oldData = {
                        pages: oldPages,
                        pageParams: oldPageParams
                    };
                    const param = pageParamFn(options, oldData);
                    result = await fetchPage(oldData, param, previous);
                } else {
                    const remainingPages = pages !== null && pages !== void 0 ? pages : oldPages.length;
                    do {
                        var _oldPageParams_;
                        const param = currentPage === 0 ? (_oldPageParams_ = oldPageParams[0]) !== null && _oldPageParams_ !== void 0 ? _oldPageParams_ : options.initialPageParam : getNextPageParam(options, result);
                        if (currentPage > 0 && param == null) {
                            break;
                        }
                        result = await fetchPage(result, param);
                        currentPage++;
                    }while (currentPage < remainingPages)
                }
                return result;
            };
            if (context.options.persister) {
                context.fetchFn = ()=>{
                    var _context_options_persister, _context_options;
                    return (_context_options_persister = (_context_options = context.options).persister) === null || _context_options_persister === void 0 ? void 0 : _context_options_persister.call(_context_options, fetchFn, {
                        client: context.client,
                        queryKey: context.queryKey,
                        meta: context.options.meta,
                        signal: context.signal
                    }, query);
                };
            } else {
                context.fetchFn = fetchFn;
            }
        }
    };
}
function getNextPageParam(options, param) {
    let { pages, pageParams } = param;
    const lastIndex = pages.length - 1;
    return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
function getPreviousPageParam(options, param) {
    let { pages, pageParams } = param;
    var _options_getPreviousPageParam;
    return pages.length > 0 ? (_options_getPreviousPageParam = options.getPreviousPageParam) === null || _options_getPreviousPageParam === void 0 ? void 0 : _options_getPreviousPageParam.call(options, pages[0], pages, pageParams[0], pageParams) : void 0;
}
function hasNextPage(options, data) {
    if (!data) return false;
    return getNextPageParam(options, data) != null;
}
function hasPreviousPage(options, data) {
    if (!data || !options.getPreviousPageParam) return false;
    return getPreviousPageParam(options, data) != null;
}
;
 //# sourceMappingURL=infiniteQueryBehavior.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/queryClient.ts
__turbopack_context__.s([
    "QueryClient",
    ()=>QueryClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_get.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_init.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_set.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_update$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@swc+helpers@0.5.15/node_modules/@swc/helpers/esm/_class_private_field_update.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/queryCache.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$mutationCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/mutationCache.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$focusManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/focusManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$onlineManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/onlineManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/notifyManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$infiniteQueryBehavior$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.90.2/node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js [app-client] (ecmascript)");
;
;
;
;
var _queryCache, _mutationCache, _defaultOptions, _queryDefaults, _mutationDefaults, _mountCount, _unsubscribeFocus, _unsubscribeOnline;
;
;
;
;
;
;
;
var QueryClient = (_queryCache = /*#__PURE__*/ new WeakMap(), _mutationCache = /*#__PURE__*/ new WeakMap(), _defaultOptions = /*#__PURE__*/ new WeakMap(), _queryDefaults = /*#__PURE__*/ new WeakMap(), _mutationDefaults = /*#__PURE__*/ new WeakMap(), _mountCount = /*#__PURE__*/ new WeakMap(), _unsubscribeFocus = /*#__PURE__*/ new WeakMap(), _unsubscribeOnline = /*#__PURE__*/ new WeakMap(), class {
    mount() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_update$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mountCount).value++;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mountCount) !== 1) return;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _unsubscribeFocus, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$focusManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusManager"].subscribe(async (focused)=>{
            if (focused) {
                await this.resumePausedMutations();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).onFocus();
            }
        }));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _unsubscribeOnline, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$onlineManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onlineManager"].subscribe(async (online)=>{
            if (online) {
                await this.resumePausedMutations();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).onOnline();
            }
        }));
    }
    unmount() {
        var _this, _this1, _ref, _this2, _this3, _ref1;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_update$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mountCount).value--;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mountCount) !== 0) return;
        (_this = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(_ref = _this1 = this, _unsubscribeFocus)) === null || _this === void 0 ? void 0 : _this.call(_this1);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _unsubscribeFocus, void 0);
        (_this2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(_ref1 = _this3 = this, _unsubscribeOnline)) === null || _this2 === void 0 ? void 0 : _this2.call(_this3);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _unsubscribeOnline, void 0);
    }
    isFetching(filters) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).findAll({
            ...filters,
            fetchStatus: "fetching"
        }).length;
    }
    isMutating(filters) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).findAll({
            ...filters,
            status: "pending"
        }).length;
    }
    /**
   * Imperative (non-reactive) way to retrieve data for a QueryKey.
   * Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
   *
   * Hint: Do not use this function inside a component, because it won't receive updates.
   * Use `useQuery` to create a `QueryObserver` that subscribes to changes.
   */ getQueryData(queryKey) {
        var _class_private_field_get_get;
        const options = this.defaultQueryOptions({
            queryKey
        });
        return (_class_private_field_get_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).get(options.queryHash)) === null || _class_private_field_get_get === void 0 ? void 0 : _class_private_field_get_get.state.data;
    }
    ensureQueryData(options) {
        const defaultedOptions = this.defaultQueryOptions(options);
        const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).build(this, defaultedOptions);
        const cachedData = query.state.data;
        if (cachedData === void 0) {
            return this.fetchQuery(options);
        }
        if (options.revalidateIfStale && query.isStaleByTime((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveStaleTime"])(defaultedOptions.staleTime, query))) {
            void this.prefetchQuery(defaultedOptions);
        }
        return Promise.resolve(cachedData);
    }
    getQueriesData(filters) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).findAll(filters).map((param)=>{
            let { queryKey, state } = param;
            const data = state.data;
            return [
                queryKey,
                data
            ];
        });
    }
    setQueryData(queryKey, updater, options) {
        const defaultedOptions = this.defaultQueryOptions({
            queryKey
        });
        const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).get(defaultedOptions.queryHash);
        const prevData = query === null || query === void 0 ? void 0 : query.state.data;
        const data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["functionalUpdate"])(updater, prevData);
        if (data === void 0) {
            return void 0;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).build(this, defaultedOptions).setData(data, {
            ...options,
            manual: true
        });
    }
    setQueriesData(filters, updater, options) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).findAll(filters).map((param)=>{
                let { queryKey } = param;
                return [
                    queryKey,
                    this.setQueryData(queryKey, updater, options)
                ];
            }));
    }
    getQueryState(queryKey) {
        var _class_private_field_get_get;
        const options = this.defaultQueryOptions({
            queryKey
        });
        return (_class_private_field_get_get = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).get(options.queryHash)) === null || _class_private_field_get_get === void 0 ? void 0 : _class_private_field_get_get.state;
    }
    removeQueries(filters) {
        const queryCache = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            queryCache.findAll(filters).forEach((query)=>{
                queryCache.remove(query);
            });
        });
    }
    resetQueries(filters, options) {
        const queryCache = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            queryCache.findAll(filters).forEach((query)=>{
                query.reset();
            });
            return this.refetchQueries({
                type: "active",
                ...filters
            }, options);
        });
    }
    cancelQueries(filters) {
        let cancelOptions = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        const defaultedCancelOptions = {
            revert: true,
            ...cancelOptions
        };
        const promises = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).findAll(filters).map((query)=>query.cancel(defaultedCancelOptions)));
        return Promise.all(promises).then(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]).catch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]);
    }
    invalidateQueries(filters) {
        let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).findAll(filters).forEach((query)=>{
                query.invalidate();
            });
            if ((filters === null || filters === void 0 ? void 0 : filters.refetchType) === "none") {
                return Promise.resolve();
            }
            var _filters_refetchType, _ref;
            return this.refetchQueries({
                ...filters,
                type: (_ref = (_filters_refetchType = filters === null || filters === void 0 ? void 0 : filters.refetchType) !== null && _filters_refetchType !== void 0 ? _filters_refetchType : filters === null || filters === void 0 ? void 0 : filters.type) !== null && _ref !== void 0 ? _ref : "active"
            }, options);
        });
    }
    refetchQueries(filters) {
        let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        var _options_cancelRefetch;
        const fetchOptions = {
            ...options,
            cancelRefetch: (_options_cancelRefetch = options.cancelRefetch) !== null && _options_cancelRefetch !== void 0 ? _options_cancelRefetch : true
        };
        const promises = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$notifyManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).findAll(filters).filter((query)=>!query.isDisabled() && !query.isStatic()).map((query)=>{
                let promise = query.fetch(void 0, fetchOptions);
                if (!fetchOptions.throwOnError) {
                    promise = promise.catch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]);
                }
                return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
            }));
        return Promise.all(promises).then(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]);
    }
    fetchQuery(options) {
        const defaultedOptions = this.defaultQueryOptions(options);
        if (defaultedOptions.retry === void 0) {
            defaultedOptions.retry = false;
        }
        const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).build(this, defaultedOptions);
        return query.isStaleByTime((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveStaleTime"])(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
    }
    prefetchQuery(options) {
        return this.fetchQuery(options).then(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]).catch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]);
    }
    fetchInfiniteQuery(options) {
        options.behavior = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$infiniteQueryBehavior$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["infiniteQueryBehavior"])(options.pages);
        return this.fetchQuery(options);
    }
    prefetchInfiniteQuery(options) {
        return this.fetchInfiniteQuery(options).then(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]).catch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]);
    }
    ensureInfiniteQueryData(options) {
        options.behavior = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$infiniteQueryBehavior$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["infiniteQueryBehavior"])(options.pages);
        return this.ensureQueryData(options);
    }
    resumePausedMutations() {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$onlineManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onlineManager"].isOnline()) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).resumePausedMutations();
        }
        return Promise.resolve();
    }
    getQueryCache() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache);
    }
    getMutationCache() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache);
    }
    getDefaultOptions() {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions);
    }
    setDefaultOptions(options) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions, options);
    }
    setQueryDefaults(queryKey, options) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryDefaults).set((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hashKey"])(queryKey), {
            queryKey,
            defaultOptions: options
        });
    }
    getQueryDefaults(queryKey) {
        const defaults = [
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryDefaults).values()
        ];
        const result = {};
        defaults.forEach((queryDefault)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["partialMatchKey"])(queryKey, queryDefault.queryKey)) {
                Object.assign(result, queryDefault.defaultOptions);
            }
        });
        return result;
    }
    setMutationDefaults(mutationKey, options) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationDefaults).set((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hashKey"])(mutationKey), {
            mutationKey,
            defaultOptions: options
        });
    }
    getMutationDefaults(mutationKey) {
        const defaults = [
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationDefaults).values()
        ];
        const result = {};
        defaults.forEach((queryDefault)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["partialMatchKey"])(mutationKey, queryDefault.mutationKey)) {
                Object.assign(result, queryDefault.defaultOptions);
            }
        });
        return result;
    }
    defaultQueryOptions(options) {
        if (options._defaulted) {
            return options;
        }
        const defaultedOptions = {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions).queries,
            ...this.getQueryDefaults(options.queryKey),
            ...options,
            _defaulted: true
        };
        if (!defaultedOptions.queryHash) {
            defaultedOptions.queryHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hashQueryKeyByOptions"])(defaultedOptions.queryKey, defaultedOptions);
        }
        if (defaultedOptions.refetchOnReconnect === void 0) {
            defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
        }
        if (defaultedOptions.throwOnError === void 0) {
            defaultedOptions.throwOnError = !!defaultedOptions.suspense;
        }
        if (!defaultedOptions.networkMode && defaultedOptions.persister) {
            defaultedOptions.networkMode = "offlineFirst";
        }
        if (defaultedOptions.queryFn === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["skipToken"]) {
            defaultedOptions.enabled = false;
        }
        return defaultedOptions;
    }
    defaultMutationOptions(options) {
        if (options === null || options === void 0 ? void 0 : options._defaulted) {
            return options;
        }
        return {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions).mutations,
            ...(options === null || options === void 0 ? void 0 : options.mutationKey) && this.getMutationDefaults(options.mutationKey),
            ...options,
            _defaulted: true
        };
    }
    clear() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache).clear();
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_get$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache).clear();
    }
    constructor(config = {}){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryDefaults, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationDefaults, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mountCount, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _unsubscribeFocus, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_init$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _unsubscribeOnline, {
            writable: true,
            value: void 0
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryCache, config.queryCache || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCache"]());
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationCache, config.mutationCache || new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$90$2e$2$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$mutationCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MutationCache"]());
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _defaultOptions, config.defaultOptions || {});
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _queryDefaults, /* @__PURE__ */ new Map());
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mutationDefaults, /* @__PURE__ */ new Map());
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$swc$2b$helpers$40$0$2e$5$2e$15$2f$node_modules$2f40$swc$2f$helpers$2f$esm$2f$_class_private_field_set$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])(this, _mountCount, 0);
    }
});
;
 //# sourceMappingURL=queryClient.js.map
}),
"[project]/node_modules/.pnpm/@tanstack+react-query@5.90.2_react@19.1.0/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QueryClientContext",
    ()=>QueryClientContext,
    "QueryClientProvider",
    ()=>QueryClientProvider,
    "useQueryClient",
    ()=>useQueryClient
]);
// src/QueryClientProvider.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.5.5_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
"use client";
;
;
var QueryClientContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](void 0);
var useQueryClient = (queryClient)=>{
    const client = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](QueryClientContext);
    if (queryClient) {
        return queryClient;
    }
    if (!client) {
        throw new Error("No QueryClient set, use QueryClientProvider to set one");
    }
    return client;
};
var QueryClientProvider = (param)=>{
    let { client, children } = param;
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "QueryClientProvider.useEffect": ()=>{
            client.mount();
            return ({
                "QueryClientProvider.useEffect": ()=>{
                    client.unmount();
                }
            })["QueryClientProvider.useEffect"];
        }
    }["QueryClientProvider.useEffect"], [
        client
    ]);
    return /* @__PURE__ */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$5$2e$5_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(QueryClientContext.Provider, {
        value: client,
        children
    });
};
;
 //# sourceMappingURL=QueryClientProvider.js.map
}),
"[project]/node_modules/.pnpm/posthog-js@1.275.1/node_modules/posthog-js/dist/module.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "COPY_AUTOCAPTURE_EVENT",
    ()=>te,
    "Compression",
    ()=>ie,
    "DisplaySurveyType",
    ()=>Mn,
    "PostHog",
    ()=>Io,
    "SurveyEventName",
    ()=>On,
    "SurveyEventProperties",
    ()=>Fn,
    "SurveyPosition",
    ()=>Pn,
    "SurveyQuestionBranchingType",
    ()=>Rn,
    "SurveyQuestionType",
    ()=>In,
    "SurveySchedule",
    ()=>Cn,
    "SurveyType",
    ()=>Tn,
    "SurveyWidgetType",
    ()=>kn,
    "default",
    ()=>Co,
    "posthog",
    ()=>Co,
    "severityLevels",
    ()=>ee
]);
var t = "undefined" != typeof window ? window : void 0, i = "undefined" != typeof globalThis ? globalThis : t, e = Array.prototype, r = e.forEach, s = e.indexOf, n = null == i ? void 0 : i.navigator, o = null == i ? void 0 : i.document, a = null == i ? void 0 : i.location, l = null == i ? void 0 : i.fetch, u = null != i && i.XMLHttpRequest && "withCredentials" in new i.XMLHttpRequest ? i.XMLHttpRequest : void 0, h = null == i ? void 0 : i.AbortController, d = null == n ? void 0 : n.userAgent, v = null != t ? t : {}, c = {
    DEBUG: !1,
    LIB_VERSION: "1.275.1"
};
function f(t, i, e, r, s, n, o) {
    try {
        var a = t[n](o), l = a.value;
    } catch (t) {
        return void e(t);
    }
    a.done ? i(l) : Promise.resolve(l).then(r, s);
}
function p(t) {
    return function() {
        var i = this, e = arguments;
        return new Promise(function(r, s) {
            var n = t.apply(i, e);
            function o(t) {
                f(n, r, s, o, a, "next", t);
            }
            function a(t) {
                f(n, r, s, o, a, "throw", t);
            }
            o(void 0);
        });
    };
}
function g() {
    return g = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : "TURBOPACK unreachable", g.apply(null, arguments);
}
function _(t, i) {
    if (null == t) return {};
    var e = {};
    for(var r in t)if (({}).hasOwnProperty.call(t, r)) {
        if (-1 !== i.indexOf(r)) continue;
        e[r] = t[r];
    }
    return e;
}
var m = [
    "$snapshot",
    "$pageview",
    "$pageleave",
    "$set",
    "survey dismissed",
    "survey sent",
    "survey shown",
    "$identify",
    "$groupidentify",
    "$create_alias",
    "$$client_ingestion_warning",
    "$web_experiment_applied",
    "$feature_enrollment_update",
    "$feature_flag_called"
];
function y(t, i) {
    return -1 !== t.indexOf(i);
}
var b = function(t) {
    return t.trim();
}, w = function(t) {
    return t.replace(/^\$/, "");
};
var S = Array.isArray, x = Object.prototype, E = x.hasOwnProperty, k = x.toString, P = S || function(t) {
    return "[object Array]" === k.call(t);
}, T = (t)=>"function" == typeof t, I = (t)=>t === Object(t) && !P(t), R = (t)=>{
    if (I(t)) {
        for(var i in t)if (E.call(t, i)) return !1;
        return !0;
    }
    return !1;
}, C = (t)=>void 0 === t, O = (t)=>"[object String]" == k.call(t), F = (t)=>O(t) && 0 === t.trim().length, M = (t)=>null === t, A = (t)=>C(t) || M(t), j = (t)=>"[object Number]" == k.call(t), D = (t)=>"[object Boolean]" === k.call(t), L = (t)=>t instanceof FormData, N = (t)=>y(m, t);
function U(t) {
    return null === t || "object" != typeof t;
}
function z(t, i) {
    return Object.prototype.toString.call(t) === "[object " + i + "]";
}
function H(t) {
    return !C(Event) && function(t, i) {
        try {
            return t instanceof i;
        } catch (t) {
            return !1;
        }
    }(t, Event);
}
var B = [
    !0,
    "true",
    1,
    "1",
    "yes"
], q = (t)=>y(B, t), W = [
    !1,
    "false",
    0,
    "0",
    "no"
];
function G(t, i, e, r, s) {
    return i > e && (r.warn("min cannot be greater than max."), i = e), j(t) ? t > e ? (r.warn(" cannot be  greater than max: " + e + ". Using max value instead."), e) : t < i ? (r.warn(" cannot be less than min: " + i + ". Using min value instead."), i) : t : (r.warn(" must be a number. using max or fallback. max: " + e + ", fallback: " + s), G(s || e, i, e, r));
}
class V {
    stop() {
        this.I && (clearInterval(this.I), this.I = void 0);
    }
    constructor(t){
        this.t = t, this.i = {}, this.o = ()=>{
            Object.keys(this.i).forEach((t)=>{
                var i = this.h(t) + this.m;
                i >= this.S ? delete this.i[t] : this.$(t, i);
            });
        }, this.h = (t)=>this.i[String(t)], this.$ = (t, i)=>{
            this.i[String(t)] = i;
        }, this.consumeRateLimit = (t)=>{
            var i, e, r = null !== (i = this.h(t)) && void 0 !== i ? i : this.S;
            if (0 === (r = Math.max(r - 1, 0))) return !0;
            this.$(t, r);
            var s = 0 === r;
            return s && (null == (e = this.k) || e.call(this, t)), s;
        }, this.k = this.t.k, this.S = G(this.t.bucketSize, 0, 100, this.t.P), this.m = G(this.t.refillRate, 0, this.S, this.t.P), this.T = G(this.t.refillInterval, 0, 864e5, this.t.P), this.I = setInterval(()=>{
            this.o();
        }, this.T);
    }
}
var J, K, Y, X = (t)=>t instanceof Error;
function Q(t) {
    var i = globalThis._posthogChunkIds;
    if (i) {
        var e = Object.keys(i);
        return Y && e.length === K || (K = e.length, Y = e.reduce((e, r)=>{
            J || (J = {});
            var s = J[r];
            if (s) e[s[0]] = s[1];
            else for(var n = t(r), o = n.length - 1; o >= 0; o--){
                var a = n[o], l = null == a ? void 0 : a.filename, u = i[r];
                if (l && u) {
                    e[l] = u, J[r] = [
                        l,
                        u
                    ];
                    break;
                }
            }
            return e;
        }, {})), Y;
    }
}
var Z = "?";
function tt(t, i, e, r) {
    var s = {
        platform: "web:javascript",
        filename: t,
        function: "<anonymous>" === i ? Z : i,
        in_app: !0
    };
    return C(e) || (s.lineno = e), C(r) || (s.colno = r), s;
}
var it = (t, i)=>{
    var e = -1 !== t.indexOf("safari-extension"), r = -1 !== t.indexOf("safari-web-extension");
    return e || r ? [
        -1 !== t.indexOf("@") ? t.split("@")[0] : Z,
        e ? "safari-extension:" + i : "safari-web-extension:" + i
    ] : [
        t,
        i
    ];
}, et = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i, rt = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, st = /\((\S*)(?::(\d+))(?::(\d+))\)/, nt = (t)=>{
    var i = et.exec(t);
    if (i) {
        var [, e, r, s] = i;
        return tt(e, Z, +r, +s);
    }
    var n = rt.exec(t);
    if (n) {
        if (n[2] && 0 === n[2].indexOf("eval")) {
            var o = st.exec(n[2]);
            o && (n[2] = o[1], n[3] = o[2], n[4] = o[3]);
        }
        var [a, l] = it(n[1] || Z, n[2]);
        return tt(l, a, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0);
    }
}, ot = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i, at = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, lt = (t)=>{
    var i = ot.exec(t);
    if (i) {
        if (i[3] && i[3].indexOf(" > eval") > -1) {
            var e = at.exec(i[3]);
            e && (i[1] = i[1] || "eval", i[3] = e[1], i[4] = e[2], i[5] = "");
        }
        var r = i[3], s = i[1] || Z;
        return [s, r] = it(s, r), tt(r, s, i[4] ? +i[4] : void 0, i[5] ? +i[5] : void 0);
    }
}, ut = /\(error: (.*)\)/, ht = 50;
function dt() {
    for(var t = arguments.length, i = new Array(t), e = 0; e < t; e++)i[e] = arguments[e];
    return function(t, e) {
        void 0 === e && (e = 0);
        for(var r = [], s = t.split("\n"), n = e; n < s.length; n++){
            var o = s[n];
            if (!(o.length > 1024)) {
                var a = ut.test(o) ? o.replace(ut, "$1") : o;
                if (!a.match(/\S*Error: /)) {
                    for (var l of i){
                        var u = l(a);
                        if (u) {
                            r.push(u);
                            break;
                        }
                    }
                    if (r.length >= ht) break;
                }
            }
        }
        return function(t) {
            if (!t.length) return [];
            var i = Array.from(t);
            return i.reverse(), i.slice(0, ht).map((t)=>{
                return g({}, t, {
                    filename: t.filename || (e = i, e[e.length - 1] || {}).filename,
                    function: t.function || Z
                });
                //TURBOPACK unreachable
                ;
                var e;
            });
        }(r);
    };
}
class vt {
    buildFromUnknown(t, i) {
        void 0 === i && (i = {});
        var e = i && i.mechanism || {
            handled: !0,
            type: "generic"
        }, r = this.buildCoercingContext(e, i, 0).apply(t), s = this.buildParsingContext(), n = this.parseStacktrace(r, s);
        return {
            $exception_list: this.convertToExceptionList(n, e),
            $exception_level: "error"
        };
    }
    modifyFrames(t) {
        var i = this;
        return p(function*() {
            for (var e of t)e.stacktrace && e.stacktrace.frames && P(e.stacktrace.frames) && (e.stacktrace.frames = yield i.applyModifiers(e.stacktrace.frames));
            return t;
        })();
    }
    coerceFallback(t) {
        var i;
        return {
            type: "Error",
            value: "Unknown error",
            stack: null == (i = t.syntheticException) ? void 0 : i.stack,
            synthetic: !0
        };
    }
    parseStacktrace(t, i) {
        var e, r;
        return null != t.cause && (e = this.parseStacktrace(t.cause, i)), "" != t.stack && null != t.stack && (r = this.applyChunkIds(this.stackParser(t.stack, t.synthetic ? 1 : 0), i.chunkIdMap)), g({}, t, {
            cause: e,
            stack: r
        });
    }
    applyChunkIds(t, i) {
        return t.map((t)=>(t.filename && i && (t.chunk_id = i[t.filename]), t));
    }
    applyCoercers(t, i) {
        for (var e of this.coercers)if (e.match(t)) return e.coerce(t, i);
        return this.coerceFallback(i);
    }
    applyModifiers(t) {
        var i = this;
        return p(function*() {
            var e = t;
            for (var r of i.modifiers)e = yield r(e);
            return e;
        })();
    }
    convertToExceptionList(t, i) {
        var e, r, s, n = {
            type: t.type,
            value: t.value,
            mechanism: {
                type: null !== (e = i.type) && void 0 !== e ? e : "generic",
                handled: null === (r = i.handled) || void 0 === r || r,
                synthetic: null !== (s = t.synthetic) && void 0 !== s && s
            }
        };
        t.stack && (n.stacktrace = {
            type: "raw",
            frames: t.stack
        });
        var o = [
            n
        ];
        return null != t.cause && o.push(...this.convertToExceptionList(t.cause, g({}, i, {
            handled: !0
        }))), o;
    }
    buildParsingContext() {
        return {
            chunkIdMap: Q(this.stackParser)
        };
    }
    buildCoercingContext(t, i, e) {
        void 0 === e && (e = 0);
        var r = (e, r)=>{
            if (r <= 4) {
                var s = this.buildCoercingContext(t, i, r);
                return this.applyCoercers(e, s);
            }
        };
        return g({}, i, {
            syntheticException: 0 == e ? i.syntheticException : void 0,
            mechanism: t,
            apply: (t)=>r(t, e),
            next: (t)=>r(t, e + 1)
        });
    }
    constructor(t, i, e){
        void 0 === t && (t = []), void 0 === i && (i = []), void 0 === e && (e = []), this.coercers = t, this.modifiers = e, this.stackParser = dt(...i);
    }
}
class ct {
    match(t) {
        return this.isDOMException(t) || this.isDOMError(t);
    }
    coerce(t, i) {
        var e = O(t.stack);
        return {
            type: this.getType(t),
            value: this.getValue(t),
            stack: e ? t.stack : void 0,
            cause: t.cause ? i.next(t.cause) : void 0,
            synthetic: !1
        };
    }
    getType(t) {
        return this.isDOMError(t) ? "DOMError" : "DOMException";
    }
    getValue(t) {
        var i = t.name || (this.isDOMError(t) ? "DOMError" : "DOMException");
        return t.message ? i + ": " + t.message : i;
    }
    isDOMException(t) {
        return z(t, "DOMException");
    }
    isDOMError(t) {
        return z(t, "DOMError");
    }
}
class ft {
    match(t) {
        return ((t)=>t instanceof Error)(t);
    }
    coerce(t, i) {
        return {
            type: this.getType(t),
            value: this.getMessage(t, i),
            stack: this.getStack(t),
            cause: t.cause ? i.next(t.cause) : void 0,
            synthetic: !1
        };
    }
    getType(t) {
        return t.name || t.constructor.name;
    }
    getMessage(t, i) {
        var e = t.message;
        return e.error && "string" == typeof e.error.message ? String(e.error.message) : String(e);
    }
    getStack(t) {
        return t.stacktrace || t.stack || void 0;
    }
}
class pt {
    match(t) {
        return z(t, "ErrorEvent") && null != t.error;
    }
    coerce(t, i) {
        var e, r = i.apply(t.error);
        return r || {
            type: "ErrorEvent",
            value: t.message,
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        };
    }
    constructor(){}
}
var gt = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i;
class _t {
    match(t) {
        return "string" == typeof t;
    }
    coerce(t, i) {
        var e, [r, s] = this.getInfos(t);
        return {
            type: null != r ? r : "Error",
            value: null != s ? s : t,
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        };
    }
    getInfos(t) {
        var i = "Error", e = t, r = t.match(gt);
        return r && (i = r[1], e = r[2]), [
            i,
            e
        ];
    }
}
var mt = [
    "fatal",
    "error",
    "warning",
    "log",
    "info",
    "debug"
];
function yt(t, i) {
    void 0 === i && (i = 40);
    var e = Object.keys(t);
    if (e.sort(), !e.length) return "[object has no keys]";
    for(var r = e.length; r > 0; r--){
        var s = e.slice(0, r).join(", ");
        if (!(s.length > i)) return r === e.length || s.length <= i ? s : s.slice(0, i) + "...";
    }
    return "";
}
class bt {
    match(t) {
        return "object" == typeof t && null !== t;
    }
    coerce(t, i) {
        var e, r = this.getErrorPropertyFromObject(t);
        return r ? i.apply(r) : {
            type: this.getType(t),
            value: this.getValue(t),
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            level: this.isSeverityLevel(t.level) ? t.level : "error",
            synthetic: !0
        };
    }
    getType(t) {
        return H(t) ? t.constructor.name : "Error";
    }
    getValue(t) {
        if ("name" in t && "string" == typeof t.name) {
            var i = "'" + t.name + "' captured as exception";
            return "message" in t && "string" == typeof t.message && (i += " with message: '" + t.message + "'"), i;
        }
        if ("message" in t && "string" == typeof t.message) return t.message;
        var e = this.getObjectClassName(t);
        return (e && "Object" !== e ? "'" + e + "'" : "Object") + " captured as exception with keys: " + yt(t);
    }
    isSeverityLevel(t) {
        return O(t) && !F(t) && mt.indexOf(t) >= 0;
    }
    getErrorPropertyFromObject(t) {
        for(var i in t)if (Object.prototype.hasOwnProperty.call(t, i)) {
            var e = t[i];
            if (X(e)) return e;
        }
    }
    getObjectClassName(t) {
        try {
            var i = Object.getPrototypeOf(t);
            return i ? i.constructor.name : void 0;
        } catch (t) {
            return;
        }
    }
}
class wt {
    match(t) {
        return H(t);
    }
    coerce(t, i) {
        var e, r = t.constructor.name;
        return {
            type: r,
            value: r + " captured as exception with keys: " + yt(t),
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        };
    }
}
class St {
    match(t) {
        return U(t);
    }
    coerce(t, i) {
        var e;
        return {
            type: "Error",
            value: "Primitive value captured as exception: " + String(t),
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        };
    }
}
class xt {
    match(t) {
        return z(t, "PromiseRejectionEvent");
    }
    coerce(t, i) {
        var e, r = this.getUnhandledRejectionReason(t);
        return U(r) ? {
            type: "UnhandledRejection",
            value: "Non-Error promise rejection captured with value: " + String(r),
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        } : i.apply(r);
    }
    getUnhandledRejectionReason(t) {
        if (U(t)) return t;
        try {
            if ("reason" in t) return t.reason;
            if ("detail" in t && "reason" in t.detail) return t.detail.reason;
        } catch (t) {}
        return t;
    }
}
var Et = (i)=>{
    var e = {
        R: function(e) {
            if (t && (c.DEBUG || v.POSTHOG_DEBUG) && !C(t.console) && t.console) {
                for(var r = ("__rrweb_original__" in t.console[e]) ? t.console[e].__rrweb_original__ : t.console[e], s = arguments.length, n = new Array(s > 1 ? s - 1 : 0), o = 1; o < s; o++)n[o - 1] = arguments[o];
                r(i, ...n);
            }
        },
        info: function() {
            for(var t = arguments.length, i = new Array(t), r = 0; r < t; r++)i[r] = arguments[r];
            e.R("log", ...i);
        },
        warn: function() {
            for(var t = arguments.length, i = new Array(t), r = 0; r < t; r++)i[r] = arguments[r];
            e.R("warn", ...i);
        },
        error: function() {
            for(var t = arguments.length, i = new Array(t), r = 0; r < t; r++)i[r] = arguments[r];
            e.R("error", ...i);
        },
        critical: function() {
            for(var t = arguments.length, e = new Array(t), r = 0; r < t; r++)e[r] = arguments[r];
            console.error(i, ...e);
        },
        uninitializedWarning: (t)=>{
            e.error("You must initialize PostHog before calling " + t);
        },
        createLogger: (t)=>Et(i + " " + t)
    };
    return e;
}, $t = Et("[PostHog.js]"), kt = $t.createLogger, Pt = kt("[ExternalScriptsLoader]"), Tt = (t, i, e)=>{
    if (t.config.disable_external_dependency_loading) return Pt.warn(i + " was requested but loading of external scripts is disabled."), e("Loading of external scripts is disabled");
    var r = null == o ? void 0 : o.querySelectorAll("script");
    if (r) {
        for(var s, n = function() {
            if (r[a].src === i) {
                var t = r[a];
                return t.__posthog_loading_callback_fired ? {
                    v: e()
                } : (t.addEventListener("load", (i)=>{
                    t.__posthog_loading_callback_fired = !0, e(void 0, i);
                }), t.onerror = (t)=>e(t), {
                    v: void 0
                });
            }
        }, a = 0; a < r.length; a++)if (s = n()) return s.v;
    }
    var l = ()=>{
        if (!o) return e("document not found");
        var r = o.createElement("script");
        if (r.type = "text/javascript", r.crossOrigin = "anonymous", r.src = i, r.onload = (t)=>{
            r.__posthog_loading_callback_fired = !0, e(void 0, t);
        }, r.onerror = (t)=>e(t), t.config.prepare_external_dependency_script && (r = t.config.prepare_external_dependency_script(r)), !r) return e("prepare_external_dependency_script returned null");
        var s, n = o.querySelectorAll("body > script");
        n.length > 0 ? null == (s = n[0].parentNode) || s.insertBefore(r, n[0]) : o.body.appendChild(r);
    };
    null != o && o.body ? l() : null == o || o.addEventListener("DOMContentLoaded", l);
};
v.__PosthogExtensions__ = v.__PosthogExtensions__ || {}, v.__PosthogExtensions__.loadExternalDependency = (t, i, e)=>{
    var r = "/static/" + i + ".js?v=" + t.version;
    if ("remote-config" === i && (r = "/array/" + t.config.token + "/config.js"), "toolbar" === i) {
        var s = 3e5;
        r = r + "&t=" + Math.floor(Date.now() / s) * s;
    }
    var n = t.requestRouter.endpointFor("assets", r);
    Tt(t, n, e);
}, v.__PosthogExtensions__.loadSiteApp = (t, i, e)=>{
    var r = t.requestRouter.endpointFor("api", i);
    Tt(t, r, e);
};
var It = {};
function Rt(t, i, e) {
    if (P(t)) {
        if (r && t.forEach === r) t.forEach(i, e);
        else if ("length" in t && t.length === +t.length) {
            for(var s = 0, n = t.length; s < n; s++)if (s in t && i.call(e, t[s], s) === It) return;
        }
    }
}
function Ct(t, i, e) {
    if (!A(t)) {
        if (P(t)) return Rt(t, i, e);
        if (L(t)) {
            for (var r of t.entries())if (i.call(e, r[1], r[0]) === It) return;
        } else for(var s in t)if (E.call(t, s) && i.call(e, t[s], s) === It) return;
    }
}
var Ot = function(t) {
    for(var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++)e[r - 1] = arguments[r];
    return Rt(e, function(i) {
        for(var e in i)void 0 !== i[e] && (t[e] = i[e]);
    }), t;
}, Ft = function(t) {
    for(var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++)e[r - 1] = arguments[r];
    return Rt(e, function(i) {
        Rt(i, function(i) {
            t.push(i);
        });
    }), t;
};
function Mt(t) {
    for(var i = Object.keys(t), e = i.length, r = new Array(e); e--;)r[e] = [
        i[e],
        t[i[e]]
    ];
    return r;
}
var At = function(t) {
    try {
        return t();
    } catch (t) {
        return;
    }
}, jt = function(t) {
    return function() {
        try {
            for(var i = arguments.length, e = new Array(i), r = 0; r < i; r++)e[r] = arguments[r];
            return t.apply(this, e);
        } catch (t) {
            $t.critical("Implementation error. Please turn on debug mode and open a ticket on https://app.posthog.com/home#panel=support%3Asupport%3A."), $t.critical(t);
        }
    };
}, Dt = function(t) {
    var i = {};
    return Ct(t, function(t, e) {
        (O(t) && t.length > 0 || j(t)) && (i[e] = t);
    }), i;
};
function Lt(t, i) {
    return e = t, r = (t)=>O(t) && !M(i) ? t.slice(0, i) : t, s = new Set, function t(i, e) {
        return i !== Object(i) ? r ? r(i, e) : i : s.has(i) ? void 0 : (s.add(i), P(i) ? (n = [], Rt(i, (i)=>{
            n.push(t(i));
        })) : (n = {}, Ct(i, (i, e)=>{
            s.has(i) || (n[e] = t(i, e));
        })), n);
        //TURBOPACK unreachable
        ;
        var n;
    }(e);
    //TURBOPACK unreachable
    ;
    var e, r, s;
}
var Nt = [
    "herokuapp.com",
    "vercel.app",
    "netlify.app"
];
function Ut(t) {
    var i = null == t ? void 0 : t.hostname;
    if (!O(i)) return !1;
    var e = i.split(".").slice(-2).join(".");
    for (var r of Nt)if (e === r) return !1;
    return !0;
}
function zt(t, i) {
    for(var e = 0; e < t.length; e++)if (i(t[e])) return t[e];
}
function Ht(t, i, e, r) {
    var { capture: s = !1, passive: n = !0 } = null != r ? r : {};
    null == t || t.addEventListener(i, e, {
        capture: s,
        passive: n
    });
}
var Bt = "$people_distinct_id", qt = "__alias", Wt = "__timers", Gt = "$autocapture_disabled_server_side", Vt = "$heatmaps_enabled_server_side", Jt = "$exception_capture_enabled_server_side", Kt = "$error_tracking_suppression_rules", Yt = "$error_tracking_capture_extension_exceptions", Xt = "$web_vitals_enabled_server_side", Qt = "$dead_clicks_enabled_server_side", Zt = "$web_vitals_allowed_metrics", ti = "$session_recording_remote_config", ii = "$sesid", ei = "$session_is_sampled", ri = "$enabled_feature_flags", si = "$early_access_features", ni = "$feature_flag_details", oi = "$stored_person_properties", ai = "$stored_group_properties", li = "$surveys", ui = "$surveys_activated", hi = "$flag_call_reported", di = "$user_state", vi = "$client_session_props", ci = "$capture_rate_limit", fi = "$initial_campaign_params", pi = "$initial_referrer_info", gi = "$initial_person_info", _i = "$epp", mi = "__POSTHOG_TOOLBAR__", yi = "$posthog_cookieless", bi = [
    Bt,
    qt,
    "__cmpns",
    Wt,
    "$session_recording_enabled_server_side",
    Vt,
    ii,
    ri,
    Kt,
    di,
    si,
    ni,
    ai,
    oi,
    li,
    hi,
    vi,
    ci,
    fi,
    pi,
    _i,
    gi
];
function wi(t) {
    return t instanceof Element && (t.id === mi || !(null == t.closest || !t.closest(".toolbar-global-fade-container")));
}
function Si(t) {
    return !!t && 1 === t.nodeType;
}
function xi(t, i) {
    return !!t && !!t.tagName && t.tagName.toLowerCase() === i.toLowerCase();
}
function Ei(t) {
    return !!t && 3 === t.nodeType;
}
function $i(t) {
    return !!t && 11 === t.nodeType;
}
function ki(t) {
    return t ? b(t).split(/\s+/) : [];
}
function Pi(i) {
    var e = null == t ? void 0 : t.location.href;
    return !!(e && i && i.some((t)=>e.match(t)));
}
function Ti(t) {
    var i = "";
    switch(typeof t.className){
        case "string":
            i = t.className;
            break;
        case "object":
            i = (t.className && "baseVal" in t.className ? t.className.baseVal : null) || t.getAttribute("class") || "";
            break;
        default:
            i = "";
    }
    return ki(i);
}
function Ii(t) {
    return A(t) ? null : b(t).split(/(\s+)/).filter((t)=>Vi(t)).join("").replace(/[\r\n]/g, " ").replace(/[ ]+/g, " ").substring(0, 255);
}
function Ri(t) {
    var i = "";
    return Ni(t) && !Ui(t) && t.childNodes && t.childNodes.length && Ct(t.childNodes, function(t) {
        var e;
        Ei(t) && t.textContent && (i += null !== (e = Ii(t.textContent)) && void 0 !== e ? e : "");
    }), b(i);
}
function Ci(t) {
    return C(t.target) ? t.srcElement || null : null != (i = t.target) && i.shadowRoot ? t.composedPath()[0] || null : t.target || null;
    //TURBOPACK unreachable
    ;
    var i;
}
var Oi = [
    "a",
    "button",
    "form",
    "input",
    "select",
    "textarea",
    "label"
];
function Fi(t, i) {
    if (C(i)) return !0;
    var e, r = function(t) {
        if (i.some((i)=>t.matches(i))) return {
            v: !0
        };
    };
    for (var s of t)if (e = r(s)) return e.v;
    return !1;
}
function Mi(t) {
    var i = t.parentNode;
    return !(!i || !Si(i)) && i;
}
var Ai = [
    ".ph-no-rageclick",
    ".ph-no-capture"
];
var ji = (t)=>!t || xi(t, "html") || !Si(t), Di = (i, e)=>{
    if (!t || ji(i)) return {
        parentIsUsefulElement: !1,
        targetElementList: []
    };
    for(var r = !1, s = [
        i
    ], n = i; n.parentNode && !xi(n, "body");)if ($i(n.parentNode)) s.push(n.parentNode.host), n = n.parentNode.host;
    else {
        var o = Mi(n);
        if (!o) break;
        if (e || Oi.indexOf(o.tagName.toLowerCase()) > -1) r = !0;
        else {
            var a = t.getComputedStyle(o);
            a && "pointer" === a.getPropertyValue("cursor") && (r = !0);
        }
        s.push(o), n = o;
    }
    return {
        parentIsUsefulElement: r,
        targetElementList: s
    };
};
function Li(i, e, r, s, n) {
    var o, a, l, u;
    if (void 0 === r && (r = void 0), !t || ji(i)) return !1;
    if (null != (o = r) && o.url_allowlist && !Pi(r.url_allowlist)) return !1;
    if (null != (a = r) && a.url_ignorelist && Pi(r.url_ignorelist)) return !1;
    if (null != (l = r) && l.dom_event_allowlist) {
        var h = r.dom_event_allowlist;
        if (h && !h.some((t)=>e.type === t)) return !1;
    }
    var { parentIsUsefulElement: d, targetElementList: v } = Di(i, s);
    if (!function(t, i) {
        var e = null == i ? void 0 : i.element_allowlist;
        if (C(e)) return !0;
        var r, s = function(t) {
            if (e.some((i)=>t.tagName.toLowerCase() === i)) return {
                v: !0
            };
        };
        for (var n of t)if (r = s(n)) return r.v;
        return !1;
    }(v, r)) return !1;
    if (!Fi(v, null == (u = r) ? void 0 : u.css_selector_allowlist)) return !1;
    var c = t.getComputedStyle(i);
    if (c && "pointer" === c.getPropertyValue("cursor") && "click" === e.type) return !0;
    var f = i.tagName.toLowerCase();
    switch(f){
        case "html":
            return !1;
        case "form":
            return (n || [
                "submit"
            ]).indexOf(e.type) >= 0;
        case "input":
        case "select":
        case "textarea":
            return (n || [
                "change",
                "click"
            ]).indexOf(e.type) >= 0;
        default:
            return d ? (n || [
                "click"
            ]).indexOf(e.type) >= 0 : (n || [
                "click"
            ]).indexOf(e.type) >= 0 && (Oi.indexOf(f) > -1 || "true" === i.getAttribute("contenteditable"));
    }
}
function Ni(t) {
    for(var i = t; i.parentNode && !xi(i, "body"); i = i.parentNode){
        var e = Ti(i);
        if (y(e, "ph-sensitive") || y(e, "ph-no-capture")) return !1;
    }
    if (y(Ti(t), "ph-include")) return !0;
    var r = t.type || "";
    if (O(r)) switch(r.toLowerCase()){
        case "hidden":
        case "password":
            return !1;
    }
    var s = t.name || t.id || "";
    if (O(s)) {
        if (/^cc|cardnum|ccnum|creditcard|csc|cvc|cvv|exp|pass|pwd|routing|seccode|securitycode|securitynum|socialsec|socsec|ssn/i.test(s.replace(/[^a-zA-Z0-9]/g, ""))) return !1;
    }
    return !0;
}
function Ui(t) {
    return !!(xi(t, "input") && ![
        "button",
        "checkbox",
        "submit",
        "reset"
    ].includes(t.type) || xi(t, "select") || xi(t, "textarea") || "true" === t.getAttribute("contenteditable"));
}
var zi = "(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11})", Hi = new RegExp("^(?:" + zi + ")$"), Bi = new RegExp(zi), qi = "\\d{3}-?\\d{2}-?\\d{4}", Wi = new RegExp("^(" + qi + ")$"), Gi = new RegExp("(" + qi + ")");
function Vi(t, i) {
    if (void 0 === i && (i = !0), A(t)) return !1;
    if (O(t)) {
        if (t = b(t), (i ? Hi : Bi).test((t || "").replace(/[- ]/g, ""))) return !1;
        if ((i ? Wi : Gi).test(t)) return !1;
    }
    return !0;
}
function Ji(t) {
    var i = Ri(t);
    return Vi(i = (i + " " + Ki(t)).trim()) ? i : "";
}
function Ki(t) {
    var i = "";
    return t && t.childNodes && t.childNodes.length && Ct(t.childNodes, function(t) {
        var e;
        if (t && "span" === (null == (e = t.tagName) ? void 0 : e.toLowerCase())) try {
            var r = Ri(t);
            i = (i + " " + r).trim(), t.childNodes && t.childNodes.length && (i = (i + " " + Ki(t)).trim());
        } catch (t) {
            $t.error("[AutoCapture]", t);
        }
    }), i;
}
function Yi(t) {
    return function(t) {
        var i = t.map((t)=>{
            var i, e, r = "";
            if (t.tag_name && (r += t.tag_name), t.attr_class) for (var s of (t.attr_class.sort(), t.attr_class))r += "." + s.replace(/"/g, "");
            var n = g({}, t.text ? {
                text: t.text
            } : {}, {
                "nth-child": null !== (i = t.nth_child) && void 0 !== i ? i : 0,
                "nth-of-type": null !== (e = t.nth_of_type) && void 0 !== e ? e : 0
            }, t.href ? {
                href: t.href
            } : {}, t.attr_id ? {
                attr_id: t.attr_id
            } : {}, t.attributes), o = {};
            return Mt(n).sort((t, i)=>{
                var [e] = t, [r] = i;
                return e.localeCompare(r);
            }).forEach((t)=>{
                var [i, e] = t;
                return o[Xi(i.toString())] = Xi(e.toString());
            }), r += ":", r += Mt(o).map((t)=>{
                var [i, e] = t;
                return i + '="' + e + '"';
            }).join("");
        });
        return i.join(";");
    }(function(t) {
        return t.map((t)=>{
            var i, e, r = {
                text: null == (i = t.$el_text) ? void 0 : i.slice(0, 400),
                tag_name: t.tag_name,
                href: null == (e = t.attr__href) ? void 0 : e.slice(0, 2048),
                attr_class: Qi(t),
                attr_id: t.attr__id,
                nth_child: t.nth_child,
                nth_of_type: t.nth_of_type,
                attributes: {}
            };
            return Mt(t).filter((t)=>{
                var [i] = t;
                return 0 === i.indexOf("attr__");
            }).forEach((t)=>{
                var [i, e] = t;
                return r.attributes[i] = e;
            }), r;
        });
    }(t));
}
function Xi(t) {
    return t.replace(/"|\\"/g, '\\"');
}
function Qi(t) {
    var i = t.attr__class;
    return i ? P(i) ? i : ki(i) : void 0;
}
class Zi {
    isRageClick(t, i, e) {
        var r = this.clicks[this.clicks.length - 1];
        if (r && Math.abs(t - r.x) + Math.abs(i - r.y) < 30 && e - r.timestamp < 1e3) {
            if (this.clicks.push({
                x: t,
                y: i,
                timestamp: e
            }), 3 === this.clicks.length) return !0;
        } else this.clicks = [
            {
                x: t,
                y: i,
                timestamp: e
            }
        ];
        return !1;
    }
    constructor(){
        this.clicks = [];
    }
}
var te = "$copy_autocapture", ie = function(t) {
    return t.GZipJS = "gzip-js", t.Base64 = "base64", t;
}({}), ee = [
    "fatal",
    "error",
    "warning",
    "log",
    "info",
    "debug"
], re = (t)=>{
    var i = null == o ? void 0 : o.createElement("a");
    return C(i) ? null : (i.href = t, i);
}, se = function(t, i) {
    var e, r;
    void 0 === i && (i = "&");
    var s = [];
    return Ct(t, function(t, i) {
        C(t) || C(i) || "undefined" === i || (e = encodeURIComponent(((t)=>t instanceof File)(t) ? t.name : t.toString()), r = encodeURIComponent(i), s[s.length] = r + "=" + e);
    }), s.join(i);
}, ne = function(t, i) {
    for(var e, r = ((t.split("#")[0] || "").split(/\?(.*)/)[1] || "").replace(/^\?+/g, "").split("&"), s = 0; s < r.length; s++){
        var n = r[s].split("=");
        if (n[0] === i) {
            e = n;
            break;
        }
    }
    if (!P(e) || e.length < 2) return "";
    var o = e[1];
    try {
        o = decodeURIComponent(o);
    } catch (t) {
        $t.error("Skipping decoding for malformed query param: " + o);
    }
    return o.replace(/\+/g, " ");
}, oe = function(t, i, e) {
    if (!t || !i || !i.length) return t;
    for(var r = t.split("#"), s = r[0] || "", n = r[1], o = s.split("?"), a = o[1], l = o[0], u = (a || "").split("&"), h = [], d = 0; d < u.length; d++){
        var v = u[d].split("=");
        P(v) && (i.includes(v[0]) ? h.push(v[0] + "=" + e) : h.push(u[d]));
    }
    var c = l;
    return null != a && (c += "?" + h.join("&")), null != n && (c += "#" + n), c;
}, ae = function(t, i) {
    var e = t.match(new RegExp(i + "=([^&]*)"));
    return e ? e[1] : null;
}, le = kt("[AutoCapture]");
function ue(t, i) {
    return i.length > t ? i.slice(0, t) + "..." : i;
}
function he(t) {
    if (t.previousElementSibling) return t.previousElementSibling;
    var i = t;
    do {
        i = i.previousSibling;
    }while (i && !Si(i))
    return i;
}
function de(t, i, e, r) {
    var s = t.tagName.toLowerCase(), n = {
        tag_name: s
    };
    Oi.indexOf(s) > -1 && !e && ("a" === s.toLowerCase() || "button" === s.toLowerCase() ? n.$el_text = ue(1024, Ji(t)) : n.$el_text = ue(1024, Ri(t)));
    var o = Ti(t);
    o.length > 0 && (n.classes = o.filter(function(t) {
        return "" !== t;
    })), Ct(t.attributes, function(e) {
        var s;
        if ((!Ui(t) || -1 !== [
            "name",
            "id",
            "class",
            "aria-label"
        ].indexOf(e.name)) && (null == r || !r.includes(e.name)) && !i && Vi(e.value) && (s = e.name, !O(s) || "_ngcontent" !== s.substring(0, 10) && "_nghost" !== s.substring(0, 7))) {
            var o = e.value;
            "class" === e.name && (o = ki(o).join(" ")), n["attr__" + e.name] = ue(1024, o);
        }
    });
    for(var a = 1, l = 1, u = t; u = he(u);)a++, u.tagName === t.tagName && l++;
    return n.nth_child = a, n.nth_of_type = l, n;
}
function ve(i, e) {
    for(var r, s, { e: n, maskAllElementAttributes: o, maskAllText: a, elementAttributeIgnoreList: l, elementsChainAsString: u } = e, h = [
        i
    ], d = i; d.parentNode && !xi(d, "body");)$i(d.parentNode) ? (h.push(d.parentNode.host), d = d.parentNode.host) : (h.push(d.parentNode), d = d.parentNode);
    var v, c = [], f = {}, p = !1, g = !1;
    if (Ct(h, (t)=>{
        var i = Ni(t);
        "a" === t.tagName.toLowerCase() && (p = t.getAttribute("href"), p = i && p && Vi(p) && p), y(Ti(t), "ph-no-capture") && (g = !0), c.push(de(t, o, a, l));
        var e = function(t) {
            if (!Ni(t)) return {};
            var i = {};
            return Ct(t.attributes, function(t) {
                if (t.name && 0 === t.name.indexOf("data-ph-capture-attribute")) {
                    var e = t.name.replace("data-ph-capture-attribute-", ""), r = t.value;
                    e && r && Vi(r) && (i[e] = r);
                }
            }), i;
        }(t);
        Ot(f, e);
    }), g) return {
        props: {},
        explicitNoCapture: g
    };
    if (a || ("a" === i.tagName.toLowerCase() || "button" === i.tagName.toLowerCase() ? c[0].$el_text = Ji(i) : c[0].$el_text = Ri(i)), p) {
        var _, m;
        c[0].attr__href = p;
        var b = null == (_ = re(p)) ? void 0 : _.host, w = null == t || null == (m = t.location) ? void 0 : m.host;
        b && w && b !== w && (v = p);
    }
    return {
        props: Ot({
            $event_type: n.type,
            $ce_version: 1
        }, u ? {} : {
            $elements: c
        }, {
            $elements_chain: Yi(c)
        }, null != (r = c[0]) && r.$el_text ? {
            $el_text: null == (s = c[0]) ? void 0 : s.$el_text
        } : {}, v && "click" === n.type ? {
            $external_click_url: v
        } : {}, f)
    };
}
class ce {
    get A() {
        var t, i, e = I(this.instance.config.autocapture) ? this.instance.config.autocapture : {};
        return e.url_allowlist = null == (t = e.url_allowlist) ? void 0 : t.map((t)=>new RegExp(t)), e.url_ignorelist = null == (i = e.url_ignorelist) ? void 0 : i.map((t)=>new RegExp(t)), e;
    }
    j() {
        if (this.isBrowserSupported()) {
            if (t && o) {
                var i = (i)=>{
                    i = i || (null == t ? void 0 : t.event);
                    try {
                        this.D(i);
                    } catch (t) {
                        le.error("Failed to capture event", t);
                    }
                };
                if (Ht(o, "submit", i, {
                    capture: !0
                }), Ht(o, "change", i, {
                    capture: !0
                }), Ht(o, "click", i, {
                    capture: !0
                }), this.A.capture_copied_text) {
                    var e = (i)=>{
                        i = i || (null == t ? void 0 : t.event), this.D(i, te);
                    };
                    Ht(o, "copy", e, {
                        capture: !0
                    }), Ht(o, "cut", e, {
                        capture: !0
                    });
                }
            }
        } else le.info("Disabling Automatic Event Collection because this browser is not supported");
    }
    startIfEnabled() {
        this.isEnabled && !this.C && (this.j(), this.C = !0);
    }
    onRemoteConfig(t) {
        t.elementsChainAsString && (this.F = t.elementsChainAsString), this.instance.persistence && this.instance.persistence.register({
            [Gt]: !!t.autocapture_opt_out
        }), this.O = !!t.autocapture_opt_out, this.startIfEnabled();
    }
    setElementSelectors(t) {
        this.M = t;
    }
    getElementSelectors(t) {
        var i, e = [];
        return null == (i = this.M) || i.forEach((i)=>{
            var r = null == o ? void 0 : o.querySelectorAll(i);
            null == r || r.forEach((r)=>{
                t === r && e.push(i);
            });
        }), e;
    }
    get isEnabled() {
        var t, i, e = null == (t = this.instance.persistence) ? void 0 : t.props[Gt], r = this.O;
        if (M(r) && !D(e) && !this.instance.L()) return !1;
        var s = null !== (i = this.O) && void 0 !== i ? i : !!e;
        return !!this.instance.config.autocapture && !s;
    }
    D(i, e) {
        if (void 0 === e && (e = "$autocapture"), this.isEnabled) {
            var r, s = Ci(i);
            if (Ei(s) && (s = s.parentNode || null), "$autocapture" === e && "click" === i.type && i instanceof MouseEvent) this.instance.config.rageclick && null != (r = this.rageclicks) && r.isRageClick(i.clientX, i.clientY, (new Date).getTime()) && function(i, e) {
                if (!t || ji(i)) return !1;
                var r, s;
                if (!1 === (r = D(e) ? !!e && Ai : null !== (s = null == e ? void 0 : e.css_selector_ignorelist) && void 0 !== s ? s : Ai)) return !1;
                var { targetElementList: n } = Di(i, !1);
                return !Fi(n, r);
            }(s, this.instance.config.rageclick) && this.D(i, "$rageclick");
            var n = e === te;
            if (s && Li(s, i, this.A, n, n ? [
                "copy",
                "cut"
            ] : void 0)) {
                var { props: o, explicitNoCapture: a } = ve(s, {
                    e: i,
                    maskAllElementAttributes: this.instance.config.mask_all_element_attributes,
                    maskAllText: this.instance.config.mask_all_text,
                    elementAttributeIgnoreList: this.A.element_attribute_ignorelist,
                    elementsChainAsString: this.F
                });
                if (a) return !1;
                var l = this.getElementSelectors(s);
                if (l && l.length > 0 && (o.$element_selectors = l), e === te) {
                    var u, h = Ii(null == t || null == (u = t.getSelection()) ? void 0 : u.toString()), d = i.type || "clipboard";
                    if (!h) return !1;
                    o.$selected_content = h, o.$copy_type = d;
                }
                return this.instance.capture(e, o), !0;
            }
        }
    }
    isBrowserSupported() {
        return T(null == o ? void 0 : o.querySelectorAll);
    }
    constructor(t){
        this.C = !1, this.O = null, this.rageclicks = new Zi, this.F = !1, this.instance = t, this.M = null;
    }
}
Math.trunc || (Math.trunc = function(t) {
    return t < 0 ? Math.ceil(t) : Math.floor(t);
}), Number.isInteger || (Number.isInteger = function(t) {
    return j(t) && isFinite(t) && Math.floor(t) === t;
});
var fe = "0123456789abcdef";
class pe {
    static fromFieldsV7(t, i, e, r) {
        if (!Number.isInteger(t) || !Number.isInteger(i) || !Number.isInteger(e) || !Number.isInteger(r) || t < 0 || i < 0 || e < 0 || r < 0 || t > 0xffffffffffff || i > 4095 || e > 1073741823 || r > 4294967295) throw new RangeError("invalid field value");
        var s = new Uint8Array(16);
        return s[0] = t / Math.pow(2, 40), s[1] = t / Math.pow(2, 32), s[2] = t / Math.pow(2, 24), s[3] = t / Math.pow(2, 16), s[4] = t / Math.pow(2, 8), s[5] = t, s[6] = 112 | i >>> 8, s[7] = i, s[8] = 128 | e >>> 24, s[9] = e >>> 16, s[10] = e >>> 8, s[11] = e, s[12] = r >>> 24, s[13] = r >>> 16, s[14] = r >>> 8, s[15] = r, new pe(s);
    }
    toString() {
        for(var t = "", i = 0; i < this.bytes.length; i++)t = t + fe.charAt(this.bytes[i] >>> 4) + fe.charAt(15 & this.bytes[i]), 3 !== i && 5 !== i && 7 !== i && 9 !== i || (t += "-");
        if (36 !== t.length) throw new Error("Invalid UUIDv7 was generated");
        return t;
    }
    clone() {
        return new pe(this.bytes.slice(0));
    }
    equals(t) {
        return 0 === this.compareTo(t);
    }
    compareTo(t) {
        for(var i = 0; i < 16; i++){
            var e = this.bytes[i] - t.bytes[i];
            if (0 !== e) return Math.sign(e);
        }
        return 0;
    }
    constructor(t){
        if (this.bytes = t, 16 !== t.length) throw new TypeError("not 128-bit length");
    }
}
class ge {
    generate() {
        var t = this.generateOrAbort();
        if (C(t)) {
            this.N = 0;
            var i = this.generateOrAbort();
            if (C(i)) throw new Error("Could not generate UUID after timestamp reset");
            return i;
        }
        return t;
    }
    generateOrAbort() {
        var t = Date.now();
        if (t > this.N) this.N = t, this.B();
        else {
            if (!(t + 1e4 > this.N)) return;
            this.U++, this.U > 4398046511103 && (this.N++, this.B());
        }
        return pe.fromFieldsV7(this.N, Math.trunc(this.U / Math.pow(2, 30)), this.U & Math.pow(2, 30) - 1, this.H.nextUint32());
    }
    B() {
        this.U = 1024 * this.H.nextUint32() + (1023 & this.H.nextUint32());
    }
    constructor(){
        this.N = 0, this.U = 0, this.H = new ye;
    }
}
var _e, me = (t)=>{
    if ("undefined" != typeof UUIDV7_DENY_WEAK_RNG && UUIDV7_DENY_WEAK_RNG) throw new Error("no cryptographically strong RNG available");
    for(var i = 0; i < t.length; i++)t[i] = 65536 * Math.trunc(65536 * Math.random()) + Math.trunc(65536 * Math.random());
    return t;
};
t && !C(t.crypto) && crypto.getRandomValues && (me = (t)=>crypto.getRandomValues(t));
class ye {
    nextUint32() {
        return this.W >= this.q.length && (me(this.q), this.W = 0), this.q[this.W++];
    }
    constructor(){
        this.q = new Uint32Array(8), this.W = 1 / 0;
    }
}
var be = ()=>we().toString(), we = ()=>(_e || (_e = new ge)).generate(), Se = "";
var xe = /[a-z0-9][a-z0-9-]+\.[a-z]{2,}$/i;
function Ee(t, i) {
    if (i) {
        var e = function(t, i) {
            if (void 0 === i && (i = o), Se) return Se;
            if (!i) return "";
            if ([
                "localhost",
                "127.0.0.1"
            ].includes(t)) return "";
            for(var e = t.split("."), r = Math.min(e.length, 8), s = "dmn_chk_" + be(); !Se && r--;){
                var n = e.slice(r).join("."), a = s + "=1;domain=." + n + ";path=/";
                i.cookie = a + ";max-age=3", i.cookie.includes(s) && (i.cookie = a + ";max-age=0", Se = n);
            }
            return Se;
        }(t);
        if (!e) {
            var r = ((t)=>{
                var i = t.match(xe);
                return i ? i[0] : "";
            })(t);
            r !== e && $t.info("Warning: cookie subdomain discovery mismatch", r, e), e = r;
        }
        return e ? "; domain=." + e : "";
    }
    return "";
}
var $e = {
    G: ()=>!!o,
    V: function(t) {
        $t.error("cookieStore error: " + t);
    },
    J: function(t) {
        if (o) {
            try {
                for(var i = t + "=", e = o.cookie.split(";").filter((t)=>t.length), r = 0; r < e.length; r++){
                    for(var s = e[r]; " " == s.charAt(0);)s = s.substring(1, s.length);
                    if (0 === s.indexOf(i)) return decodeURIComponent(s.substring(i.length, s.length));
                }
            } catch (t) {}
            return null;
        }
    },
    K: function(t) {
        var i;
        try {
            i = JSON.parse($e.J(t)) || {};
        } catch (t) {}
        return i;
    },
    Y: function(t, i, e, r, s) {
        if (o) try {
            var n = "", a = "", l = Ee(o.location.hostname, r);
            if (e) {
                var u = new Date;
                u.setTime(u.getTime() + 24 * e * 60 * 60 * 1e3), n = "; expires=" + u.toUTCString();
            }
            s && (a = "; secure");
            var h = t + "=" + encodeURIComponent(JSON.stringify(i)) + n + "; SameSite=Lax; path=/" + l + a;
            return h.length > 3686.4 && $t.warn("cookieStore warning: large cookie, len=" + h.length), o.cookie = h, h;
        } catch (t) {
            return;
        }
    },
    X: function(t, i) {
        if (null != o && o.cookie) try {
            $e.Y(t, "", -1, i);
        } catch (t) {
            return;
        }
    }
}, ke = null, Pe = {
    G: function() {
        if (!M(ke)) return ke;
        var i = !0;
        if (C(t)) i = !1;
        else try {
            var e = "__mplssupport__";
            Pe.Y(e, "xyz"), '"xyz"' !== Pe.J(e) && (i = !1), Pe.X(e);
        } catch (t) {
            i = !1;
        }
        return i || $t.error("localStorage unsupported; falling back to cookie store"), ke = i, i;
    },
    V: function(t) {
        $t.error("localStorage error: " + t);
    },
    J: function(i) {
        try {
            return null == t ? void 0 : t.localStorage.getItem(i);
        } catch (t) {
            Pe.V(t);
        }
        return null;
    },
    K: function(t) {
        try {
            return JSON.parse(Pe.J(t)) || {};
        } catch (t) {}
        return null;
    },
    Y: function(i, e) {
        try {
            null == t || t.localStorage.setItem(i, JSON.stringify(e));
        } catch (t) {
            Pe.V(t);
        }
    },
    X: function(i) {
        try {
            null == t || t.localStorage.removeItem(i);
        } catch (t) {
            Pe.V(t);
        }
    }
}, Te = [
    "distinct_id",
    ii,
    ei,
    _i,
    gi
], Ie = g({}, Pe, {
    K: function(t) {
        try {
            var i = {};
            try {
                i = $e.K(t) || {};
            } catch (t) {}
            var e = Ot(i, JSON.parse(Pe.J(t) || "{}"));
            return Pe.Y(t, e), e;
        } catch (t) {}
        return null;
    },
    Y: function(t, i, e, r, s, n) {
        try {
            Pe.Y(t, i, void 0, void 0, n);
            var o = {};
            Te.forEach((t)=>{
                i[t] && (o[t] = i[t]);
            }), Object.keys(o).length && $e.Y(t, o, e, r, s, n);
        } catch (t) {
            Pe.V(t);
        }
    },
    X: function(i, e) {
        try {
            null == t || t.localStorage.removeItem(i), $e.X(i, e);
        } catch (t) {
            Pe.V(t);
        }
    }
}), Re = {}, Ce = {
    G: function() {
        return !0;
    },
    V: function(t) {
        $t.error("memoryStorage error: " + t);
    },
    J: function(t) {
        return Re[t] || null;
    },
    K: function(t) {
        return Re[t] || null;
    },
    Y: function(t, i) {
        Re[t] = i;
    },
    X: function(t) {
        delete Re[t];
    }
}, Oe = null, Fe = {
    G: function() {
        if (!M(Oe)) return Oe;
        if (Oe = !0, C(t)) Oe = !1;
        else try {
            var i = "__support__";
            Fe.Y(i, "xyz"), '"xyz"' !== Fe.J(i) && (Oe = !1), Fe.X(i);
        } catch (t) {
            Oe = !1;
        }
        return Oe;
    },
    V: function(t) {
        $t.error("sessionStorage error: ", t);
    },
    J: function(i) {
        try {
            return null == t ? void 0 : t.sessionStorage.getItem(i);
        } catch (t) {
            Fe.V(t);
        }
        return null;
    },
    K: function(t) {
        try {
            return JSON.parse(Fe.J(t)) || null;
        } catch (t) {}
        return null;
    },
    Y: function(i, e) {
        try {
            null == t || t.sessionStorage.setItem(i, JSON.stringify(e));
        } catch (t) {
            Fe.V(t);
        }
    },
    X: function(i) {
        try {
            null == t || t.sessionStorage.removeItem(i);
        } catch (t) {
            Fe.V(t);
        }
    }
}, Me = function(t) {
    return t[t.PENDING = -1] = "PENDING", t[t.DENIED = 0] = "DENIED", t[t.GRANTED = 1] = "GRANTED", t;
}({});
class Ae {
    get A() {
        return this._instance.config;
    }
    get consent() {
        return this.Z() ? Me.DENIED : this.tt;
    }
    isOptedOut() {
        return "always" === this.A.cookieless_mode || this.consent === Me.DENIED || this.consent === Me.PENDING && (this.A.opt_out_capturing_by_default || "on_reject" === this.A.cookieless_mode);
    }
    isOptedIn() {
        return !this.isOptedOut();
    }
    isExplicitlyOptedOut() {
        return this.consent === Me.DENIED;
    }
    optInOut(t) {
        this.it.Y(this.et, t ? 1 : 0, this.A.cookie_expiration, this.A.cross_subdomain_cookie, this.A.secure_cookie);
    }
    reset() {
        this.it.X(this.et, this.A.cross_subdomain_cookie);
    }
    get et() {
        var { token: t, opt_out_capturing_cookie_prefix: i, consent_persistence_name: e } = this._instance.config;
        return e || (i ? i + t : "__ph_opt_in_out_" + t);
    }
    get tt() {
        var t = this.it.J(this.et);
        return q(t) ? Me.GRANTED : y(W, t) ? Me.DENIED : Me.PENDING;
    }
    get it() {
        if (!this.rt) {
            var t = this.A.opt_out_capturing_persistence_type;
            this.rt = "localStorage" === t ? Pe : $e;
            var i = "localStorage" === t ? $e : Pe;
            i.J(this.et) && (this.rt.J(this.et) || this.optInOut(q(i.J(this.et))), i.X(this.et, this.A.cross_subdomain_cookie));
        }
        return this.rt;
    }
    Z() {
        return !!this.A.respect_dnt && !!zt([
            null == n ? void 0 : n.doNotTrack,
            null == n ? void 0 : n.msDoNotTrack,
            v.doNotTrack
        ], (t)=>q(t));
    }
    constructor(t){
        this._instance = t;
    }
}
var je = kt("[Dead Clicks]"), De = ()=>!0, Le = (t)=>{
    var i, e = !(null == (i = t.instance.persistence) || !i.get_property(Qt)), r = t.instance.config.capture_dead_clicks;
    return D(r) ? r : e;
};
class Ne {
    get lazyLoadedDeadClicksAutocapture() {
        return this.st;
    }
    onRemoteConfig(t) {
        this.instance.persistence && this.instance.persistence.register({
            [Qt]: null == t ? void 0 : t.captureDeadClicks
        }), this.startIfEnabled();
    }
    startIfEnabled() {
        this.isEnabled(this) && this.nt(()=>{
            this.ot();
        });
    }
    nt(t) {
        var i, e;
        null != (i = v.__PosthogExtensions__) && i.initDeadClicksAutocapture && t(), null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this.instance, "dead-clicks-autocapture", (i)=>{
            i ? je.error("failed to load script", i) : t();
        });
    }
    ot() {
        var t;
        if (o) {
            if (!this.st && null != (t = v.__PosthogExtensions__) && t.initDeadClicksAutocapture) {
                var i = I(this.instance.config.capture_dead_clicks) ? this.instance.config.capture_dead_clicks : {};
                i.__onCapture = this.onCapture, this.st = v.__PosthogExtensions__.initDeadClicksAutocapture(this.instance, i), this.st.start(o), je.info("starting...");
            }
        } else je.error("`document` not found. Cannot start.");
    }
    stop() {
        this.st && (this.st.stop(), this.st = void 0, je.info("stopping..."));
    }
    constructor(t, i, e){
        this.instance = t, this.isEnabled = i, this.onCapture = e, this.startIfEnabled();
    }
}
var Ue = kt("[ExceptionAutocapture]");
class ze {
    ft() {
        var t = this._instance.config.capture_exceptions, i = {
            capture_unhandled_errors: !1,
            capture_unhandled_rejections: !1,
            capture_console_errors: !1
        };
        return I(t) ? i = g({}, i, t) : (C(t) ? this.ct : t) && (i = g({}, i, {
            capture_unhandled_errors: !0,
            capture_unhandled_rejections: !0
        })), i;
    }
    get isEnabled() {
        return this.A.capture_console_errors || this.A.capture_unhandled_errors || this.A.capture_unhandled_rejections;
    }
    startIfEnabled() {
        this.isEnabled && (Ue.info("enabled"), this.nt(this.lt));
    }
    nt(t) {
        var i, e;
        null != (i = v.__PosthogExtensions__) && i.errorWrappingFunctions && t(), null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, "exception-autocapture", (i)=>{
            if (i) return Ue.error("failed to load script", i);
            t();
        });
    }
    vt() {
        var t, i, e;
        null == (t = this.ut) || t.call(this), this.ut = void 0, null == (i = this.ht) || i.call(this), this.ht = void 0, null == (e = this.dt) || e.call(this), this.dt = void 0;
    }
    onRemoteConfig(t) {
        var i = t.autocaptureExceptions;
        this.ct = !!i || !1, this.A = this.ft(), this._instance.persistence && this._instance.persistence.register({
            [Jt]: this.ct
        }), this.startIfEnabled();
    }
    captureException(t) {
        var i, e, r = null !== (i = null == t || null == (e = t.$exception_list) || null == (e = e[0]) ? void 0 : e.type) && void 0 !== i ? i : "Exception";
        this.gt.consumeRateLimit(r) ? Ue.info("Skipping exception capture because of client rate limiting.", {
            exception: r
        }) : this._instance.exceptions.sendExceptionEvent(t);
    }
    constructor(i){
        var e, r, s;
        this.lt = ()=>{
            var i;
            if (t && this.isEnabled && null != (i = v.__PosthogExtensions__) && i.errorWrappingFunctions) {
                var e = v.__PosthogExtensions__.errorWrappingFunctions.wrapOnError, r = v.__PosthogExtensions__.errorWrappingFunctions.wrapUnhandledRejection, s = v.__PosthogExtensions__.errorWrappingFunctions.wrapConsoleError;
                try {
                    !this.ut && this.A.capture_unhandled_errors && (this.ut = e(this.captureException.bind(this))), !this.ht && this.A.capture_unhandled_rejections && (this.ht = r(this.captureException.bind(this))), !this.dt && this.A.capture_console_errors && (this.dt = s(this.captureException.bind(this)));
                } catch (t) {
                    Ue.error("failed to start", t), this.vt();
                }
            }
        }, this._instance = i, this.ct = !(null == (e = this._instance.persistence) || !e.props[Jt]), this.A = this.ft(), this.gt = new V({
            refillRate: null !== (r = this._instance.config.error_tracking.__exceptionRateLimiterRefillRate) && void 0 !== r ? r : 1,
            bucketSize: null !== (s = this._instance.config.error_tracking.__exceptionRateLimiterBucketSize) && void 0 !== s ? s : 10,
            refillInterval: 1e4,
            P: Ue
        }), this.startIfEnabled();
    }
}
function He(t, i, e) {
    try {
        if (!(i in t)) return ()=>{};
        var r = t[i], s = e(r);
        return T(s) && (s.prototype = s.prototype || {}, Object.defineProperties(s, {
            __posthog_wrapped__: {
                enumerable: !1,
                value: !0
            }
        })), t[i] = s, ()=>{
            t[i] = r;
        };
    } catch (t) {
        return ()=>{};
    }
}
class Be {
    get isEnabled() {
        return "history_change" === this._instance.config.capture_pageview;
    }
    startIfEnabled() {
        this.isEnabled && ($t.info("History API monitoring enabled, starting..."), this.monitorHistoryChanges());
    }
    stop() {
        this.yt && this.yt(), this.yt = void 0, $t.info("History API monitoring stopped");
    }
    monitorHistoryChanges() {
        var i, e;
        if (t && t.history) {
            var r = this;
            null != (i = t.history.pushState) && i.__posthog_wrapped__ || He(t.history, "pushState", (t)=>function(i, e, s) {
                    t.call(this, i, e, s), r.bt("pushState");
                }), null != (e = t.history.replaceState) && e.__posthog_wrapped__ || He(t.history, "replaceState", (t)=>function(i, e, s) {
                    t.call(this, i, e, s), r.bt("replaceState");
                }), this.wt();
        }
    }
    bt(i) {
        try {
            var e, r = null == t || null == (e = t.location) ? void 0 : e.pathname;
            if (!r) return;
            r !== this._t && this.isEnabled && this._instance.capture("$pageview", {
                navigation_type: i
            }), this._t = r;
        } catch (t) {
            $t.error("Error capturing " + i + " pageview", t);
        }
    }
    wt() {
        if (!this.yt) {
            var i = ()=>{
                this.bt("popstate");
            };
            Ht(t, "popstate", i), this.yt = ()=>{
                t && t.removeEventListener("popstate", i);
            };
        }
    }
    constructor(i){
        var e;
        this._instance = i, this._t = (null == t || null == (e = t.location) ? void 0 : e.pathname) || "";
    }
}
var qe = kt("[SegmentIntegration]");
function We(t, i) {
    var e = t.config.segment;
    if (!e) return i();
    !function(t, i) {
        var e = t.config.segment;
        if (!e) return i();
        var r = (e)=>{
            var r = ()=>e.anonymousId() || be();
            t.config.get_device_id = r, e.id() && (t.register({
                distinct_id: e.id(),
                $device_id: r()
            }), t.persistence.set_property(di, "identified")), i();
        }, s = e.user();
        "then" in s && T(s.then) ? s.then((t)=>r(t)) : r(s);
    }(t, ()=>{
        e.register(((t)=>{
            Promise && Promise.resolve || qe.warn("This browser does not have Promise support, and can not use the segment integration");
            var i = (i, e)=>{
                if (!e) return i;
                i.event.userId || i.event.anonymousId === t.get_distinct_id() || (qe.info("No userId set, resetting PostHog"), t.reset()), i.event.userId && i.event.userId !== t.get_distinct_id() && (qe.info("UserId set, identifying with PostHog"), t.identify(i.event.userId));
                var r = t.calculateEventProperties(e, i.event.properties);
                return i.event.properties = Object.assign({}, r, i.event.properties), i;
            };
            return {
                name: "PostHog JS",
                type: "enrichment",
                version: "1.0.0",
                isLoaded: ()=>!0,
                load: ()=>Promise.resolve(),
                track: (t)=>i(t, t.event.event),
                page: (t)=>i(t, "$pageview"),
                identify: (t)=>i(t, "$identify"),
                screen: (t)=>i(t, "$screen")
            };
        })(t)).then(()=>{
            i();
        });
    });
}
var Ge = "posthog-js";
function Ve(t, i) {
    var { organization: e, projectId: r, prefix: s, severityAllowList: n = [
        "error"
    ], sendExceptionsToPostHog: o = !0 } = void 0 === i ? {} : i;
    return (i)=>{
        var a, l, u, h, d;
        if (!("*" === n || n.includes(i.level)) || !t.__loaded) return i;
        i.tags || (i.tags = {});
        var v = t.requestRouter.endpointFor("ui", "/project/" + t.config.token + "/person/" + t.get_distinct_id());
        i.tags["PostHog Person URL"] = v, t.sessionRecordingStarted() && (i.tags["PostHog Recording URL"] = t.get_session_replay_url({
            withTimestamp: !0
        }));
        var c = (null == (a = i.exception) ? void 0 : a.values) || [], f = c.map((t)=>g({}, t, {
                stacktrace: t.stacktrace ? g({}, t.stacktrace, {
                    type: "raw",
                    frames: (t.stacktrace.frames || []).map((t)=>g({}, t, {
                            platform: "web:javascript"
                        }))
                }) : void 0
            })), p = {
            $exception_message: (null == (l = c[0]) ? void 0 : l.value) || i.message,
            $exception_type: null == (u = c[0]) ? void 0 : u.type,
            $exception_personURL: v,
            $exception_level: i.level,
            $exception_list: f,
            $sentry_event_id: i.event_id,
            $sentry_exception: i.exception,
            $sentry_exception_message: (null == (h = c[0]) ? void 0 : h.value) || i.message,
            $sentry_exception_type: null == (d = c[0]) ? void 0 : d.type,
            $sentry_tags: i.tags
        };
        return e && r && (p.$sentry_url = (s || "https://sentry.io/organizations/") + e + "/issues/?project=" + r + "&query=" + i.event_id), o && t.exceptions.sendExceptionEvent(p), i;
    };
}
class Je {
    constructor(t, i, e, r, s, n){
        this.name = Ge, this.setupOnce = function(o) {
            o(Ve(t, {
                organization: i,
                projectId: e,
                prefix: r,
                severityAllowList: s,
                sendExceptionsToPostHog: null == n || n
            }));
        };
    }
}
var Ke = null != t && t.location ? ae(t.location.hash, "__posthog") || ae(location.hash, "state") : null, Ye = "_postHogToolbarParams", Xe = kt("[Toolbar]"), Qe = function(t) {
    return t[t.UNINITIALIZED = 0] = "UNINITIALIZED", t[t.LOADING = 1] = "LOADING", t[t.LOADED = 2] = "LOADED", t;
}(Qe || {});
class Ze {
    St(t) {
        v.ph_toolbar_state = t;
    }
    xt() {
        var t;
        return null !== (t = v.ph_toolbar_state) && void 0 !== t ? t : Qe.UNINITIALIZED;
    }
    maybeLoadToolbar(i, e, r) {
        if (void 0 === i && (i = void 0), void 0 === e && (e = void 0), void 0 === r && (r = void 0), !t || !o) return !1;
        i = null != i ? i : t.location, r = null != r ? r : t.history;
        try {
            if (!e) {
                try {
                    t.localStorage.setItem("test", "test"), t.localStorage.removeItem("test");
                } catch (t) {
                    return !1;
                }
                e = null == t ? void 0 : t.localStorage;
            }
            var s, n = Ke || ae(i.hash, "__posthog") || ae(i.hash, "state"), a = n ? At(()=>JSON.parse(atob(decodeURIComponent(n)))) || At(()=>JSON.parse(decodeURIComponent(n))) : null;
            return a && "ph_authorize" === a.action ? ((s = a).source = "url", s && Object.keys(s).length > 0 && (a.desiredHash ? i.hash = a.desiredHash : r ? r.replaceState(r.state, "", i.pathname + i.search) : i.hash = "")) : ((s = JSON.parse(e.getItem(Ye) || "{}")).source = "localstorage", delete s.userIntent), !(!s.token || this.instance.config.token !== s.token) && (this.loadToolbar(s), !0);
        } catch (t) {
            return !1;
        }
    }
    Et(t) {
        var i = v.ph_load_toolbar || v.ph_load_editor;
        !A(i) && T(i) ? i(t, this.instance) : Xe.warn("No toolbar load function found");
    }
    loadToolbar(i) {
        var e = !(null == o || !o.getElementById(mi));
        if (!t || e) return !1;
        var r = "custom" === this.instance.requestRouter.region && this.instance.config.advanced_disable_toolbar_metrics, s = g({
            token: this.instance.config.token
        }, i, {
            apiURL: this.instance.requestRouter.endpointFor("ui")
        }, r ? {
            instrument: !1
        } : {});
        if (t.localStorage.setItem(Ye, JSON.stringify(g({}, s, {
            source: void 0
        }))), this.xt() === Qe.LOADED) this.Et(s);
        else if (this.xt() === Qe.UNINITIALIZED) {
            var n;
            this.St(Qe.LOADING), null == (n = v.__PosthogExtensions__) || null == n.loadExternalDependency || n.loadExternalDependency(this.instance, "toolbar", (t)=>{
                if (t) return Xe.error("[Toolbar] Failed to load", t), void this.St(Qe.UNINITIALIZED);
                this.St(Qe.LOADED), this.Et(s);
            }), Ht(t, "turbolinks:load", ()=>{
                this.St(Qe.UNINITIALIZED), this.loadToolbar(s);
            });
        }
        return !0;
    }
    $t(t) {
        return this.loadToolbar(t);
    }
    maybeLoadEditor(t, i, e) {
        return void 0 === t && (t = void 0), void 0 === i && (i = void 0), void 0 === e && (e = void 0), this.maybeLoadToolbar(t, i, e);
    }
    constructor(t){
        this.instance = t;
    }
}
var tr = kt("[TracingHeaders]");
class ir {
    nt(t) {
        var i, e;
        null != (i = v.__PosthogExtensions__) && i.tracingHeadersPatchFns && t(), null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, "tracing-headers", (i)=>{
            if (i) return tr.error("failed to load script", i);
            t();
        });
    }
    startIfEnabledOrStop() {
        var t, i;
        this._instance.config.__add_tracing_headers ? this.nt(this.lt) : (null == (t = this.kt) || t.call(this), null == (i = this.Pt) || i.call(this), this.kt = void 0, this.Pt = void 0);
    }
    constructor(t){
        this.kt = void 0, this.Pt = void 0, this.lt = ()=>{
            var t, i;
            C(this.kt) && (null == (t = v.__PosthogExtensions__) || null == (t = t.tracingHeadersPatchFns) || t._patchXHR(this._instance.config.__add_tracing_headers || [], this._instance.get_distinct_id(), this._instance.sessionManager));
            C(this.Pt) && (null == (i = v.__PosthogExtensions__) || null == (i = i.tracingHeadersPatchFns) || i._patchFetch(this._instance.config.__add_tracing_headers || [], this._instance.get_distinct_id(), this._instance.sessionManager));
        }, this._instance = t;
    }
}
var er = "Mobile", rr = "iOS", sr = "Android", nr = "Tablet", or = sr + " " + nr, ar = "iPad", lr = "Apple", ur = lr + " Watch", hr = "Safari", dr = "BlackBerry", vr = "Samsung", cr = vr + "Browser", fr = vr + " Internet", pr = "Chrome", gr = pr + " OS", _r = pr + " " + rr, mr = "Internet Explorer", yr = mr + " " + er, br = "Opera", wr = br + " Mini", Sr = "Edge", xr = "Microsoft " + Sr, Er = "Firefox", $r = Er + " " + rr, kr = "Nintendo", Pr = "PlayStation", Tr = "Xbox", Ir = sr + " " + er, Rr = er + " " + hr, Cr = "Windows", Or = Cr + " Phone", Fr = "Nokia", Mr = "Ouya", Ar = "Generic", jr = Ar + " " + er.toLowerCase(), Dr = Ar + " " + nr.toLowerCase(), Lr = "Konqueror", Nr = "(\\d+(\\.\\d+)?)", Ur = new RegExp("Version/" + Nr), zr = new RegExp(Tr, "i"), Hr = new RegExp(Pr + " \\w+", "i"), Br = new RegExp(kr + " \\w+", "i"), qr = new RegExp(dr + "|PlayBook|BB10", "i"), Wr = {
    "NT3.51": "NT 3.11",
    "NT4.0": "NT 4.0",
    "5.0": "2000",
    5.1: "XP",
    5.2: "XP",
    "6.0": "Vista",
    6.1: "7",
    6.2: "8",
    6.3: "8.1",
    6.4: "10",
    "10.0": "10"
};
var Gr = (t, i)=>i && y(i, lr) || function(t) {
        return y(t, hr) && !y(t, pr) && !y(t, sr);
    }(t), Vr = function(t, i) {
    return i = i || "", y(t, " OPR/") && y(t, "Mini") ? wr : y(t, " OPR/") ? br : qr.test(t) ? dr : y(t, "IE" + er) || y(t, "WPDesktop") ? yr : y(t, cr) ? fr : y(t, Sr) || y(t, "Edg/") ? xr : y(t, "FBIOS") ? "Facebook " + er : y(t, "UCWEB") || y(t, "UCBrowser") ? "UC Browser" : y(t, "CriOS") ? _r : y(t, "CrMo") || y(t, pr) ? pr : y(t, sr) && y(t, hr) ? Ir : y(t, "FxiOS") ? $r : y(t.toLowerCase(), Lr.toLowerCase()) ? Lr : Gr(t, i) ? y(t, er) ? Rr : hr : y(t, Er) ? Er : y(t, "MSIE") || y(t, "Trident/") ? mr : y(t, "Gecko") ? Er : "";
}, Jr = {
    [yr]: [
        new RegExp("rv:" + Nr)
    ],
    [xr]: [
        new RegExp(Sr + "?\\/" + Nr)
    ],
    [pr]: [
        new RegExp("(" + pr + "|CrMo)\\/" + Nr)
    ],
    [_r]: [
        new RegExp("CriOS\\/" + Nr)
    ],
    "UC Browser": [
        new RegExp("(UCBrowser|UCWEB)\\/" + Nr)
    ],
    [hr]: [
        Ur
    ],
    [Rr]: [
        Ur
    ],
    [br]: [
        new RegExp("(Opera|OPR)\\/" + Nr)
    ],
    [Er]: [
        new RegExp(Er + "\\/" + Nr)
    ],
    [$r]: [
        new RegExp("FxiOS\\/" + Nr)
    ],
    [Lr]: [
        new RegExp("Konqueror[:/]?" + Nr, "i")
    ],
    [dr]: [
        new RegExp(dr + " " + Nr),
        Ur
    ],
    [Ir]: [
        new RegExp("android\\s" + Nr, "i")
    ],
    [fr]: [
        new RegExp(cr + "\\/" + Nr)
    ],
    [mr]: [
        new RegExp("(rv:|MSIE )" + Nr)
    ],
    Mozilla: [
        new RegExp("rv:" + Nr)
    ]
}, Kr = function(t, i) {
    var e = Vr(t, i), r = Jr[e];
    if (C(r)) return null;
    for(var s = 0; s < r.length; s++){
        var n = r[s], o = t.match(n);
        if (o) return parseFloat(o[o.length - 2]);
    }
    return null;
}, Yr = [
    [
        new RegExp(Tr + "; " + Tr + " (.*?)[);]", "i"),
        (t)=>[
                Tr,
                t && t[1] || ""
            ]
    ],
    [
        new RegExp(kr, "i"),
        [
            kr,
            ""
        ]
    ],
    [
        new RegExp(Pr, "i"),
        [
            Pr,
            ""
        ]
    ],
    [
        qr,
        [
            dr,
            ""
        ]
    ],
    [
        new RegExp(Cr, "i"),
        (t, i)=>{
            if (/Phone/.test(i) || /WPDesktop/.test(i)) return [
                Or,
                ""
            ];
            if (new RegExp(er).test(i) && !/IEMobile\b/.test(i)) return [
                Cr + " " + er,
                ""
            ];
            var e = /Windows NT ([0-9.]+)/i.exec(i);
            if (e && e[1]) {
                var r = e[1], s = Wr[r] || "";
                return /arm/i.test(i) && (s = "RT"), [
                    Cr,
                    s
                ];
            }
            return [
                Cr,
                ""
            ];
        }
    ],
    [
        /((iPhone|iPad|iPod).*?OS (\d+)_(\d+)_?(\d+)?|iPhone)/,
        (t)=>{
            if (t && t[3]) {
                var i = [
                    t[3],
                    t[4],
                    t[5] || "0"
                ];
                return [
                    rr,
                    i.join(".")
                ];
            }
            return [
                rr,
                ""
            ];
        }
    ],
    [
        /(watch.*\/(\d+\.\d+\.\d+)|watch os,(\d+\.\d+),)/i,
        (t)=>{
            var i = "";
            return t && t.length >= 3 && (i = C(t[2]) ? t[3] : t[2]), [
                "watchOS",
                i
            ];
        }
    ],
    [
        new RegExp("(" + sr + " (\\d+)\\.(\\d+)\\.?(\\d+)?|" + sr + ")", "i"),
        (t)=>{
            if (t && t[2]) {
                var i = [
                    t[2],
                    t[3],
                    t[4] || "0"
                ];
                return [
                    sr,
                    i.join(".")
                ];
            }
            return [
                sr,
                ""
            ];
        }
    ],
    [
        /Mac OS X (\d+)[_.](\d+)[_.]?(\d+)?/i,
        (t)=>{
            var i = [
                "Mac OS X",
                ""
            ];
            if (t && t[1]) {
                var e = [
                    t[1],
                    t[2],
                    t[3] || "0"
                ];
                i[1] = e.join(".");
            }
            return i;
        }
    ],
    [
        /Mac/i,
        [
            "Mac OS X",
            ""
        ]
    ],
    [
        /CrOS/,
        [
            gr,
            ""
        ]
    ],
    [
        /Linux|debian/i,
        [
            "Linux",
            ""
        ]
    ]
], Xr = function(t) {
    return Br.test(t) ? kr : Hr.test(t) ? Pr : zr.test(t) ? Tr : new RegExp(Mr, "i").test(t) ? Mr : new RegExp("(" + Or + "|WPDesktop)", "i").test(t) ? Or : /iPad/.test(t) ? ar : /iPod/.test(t) ? "iPod Touch" : /iPhone/.test(t) ? "iPhone" : /(watch)(?: ?os[,/]|\d,\d\/)[\d.]+/i.test(t) ? ur : qr.test(t) ? dr : /(kobo)\s(ereader|touch)/i.test(t) ? "Kobo" : new RegExp(Fr, "i").test(t) ? Fr : /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i.test(t) || /(kf[a-z]+)( bui|\)).+silk\//i.test(t) ? "Kindle Fire" : /(Android|ZTE)/i.test(t) ? !new RegExp(er).test(t) || /(9138B|TB782B|Nexus [97]|pixel c|HUAWEISHT|BTV|noble nook|smart ultra 6)/i.test(t) ? /pixel[\daxl ]{1,6}/i.test(t) && !/pixel c/i.test(t) || /(huaweimed-al00|tah-|APA|SM-G92|i980|zte|U304AA)/i.test(t) || /lmy47v/i.test(t) && !/QTAQZ3/i.test(t) ? sr : or : sr : new RegExp("(pda|" + er + ")", "i").test(t) ? jr : new RegExp(nr, "i").test(t) && !new RegExp(nr + " pc", "i").test(t) ? Dr : "";
}, Qr = "https?://(.*)", Zr = [
    "gclid",
    "gclsrc",
    "dclid",
    "gbraid",
    "wbraid",
    "fbclid",
    "msclkid",
    "twclid",
    "li_fat_id",
    "igshid",
    "ttclid",
    "rdt_cid",
    "epik",
    "qclid",
    "sccid",
    "irclid",
    "_kx"
], ts = Ft([
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_content",
    "utm_term",
    "gad_source",
    "mc_cid"
], Zr), is = "<masked>", es = [
    "li_fat_id"
];
function rs(t, i, e) {
    if (!o) return {};
    var r, s = i ? Ft([], Zr, e || []) : [], n = ss(oe(o.URL, s, is), t), a = (r = {}, Ct(es, function(t) {
        var i = $e.J(t);
        r[t] = i || null;
    }), r);
    return Ot(a, n);
}
function ss(t, i) {
    var e = ts.concat(i || []), r = {};
    return Ct(e, function(i) {
        var e = ne(t, i);
        r[i] = e || null;
    }), r;
}
function ns(t) {
    var i = function(t) {
        return t ? 0 === t.search(Qr + "google.([^/?]*)") ? "google" : 0 === t.search(Qr + "bing.com") ? "bing" : 0 === t.search(Qr + "yahoo.com") ? "yahoo" : 0 === t.search(Qr + "duckduckgo.com") ? "duckduckgo" : null : null;
    }(t), e = "yahoo" != i ? "q" : "p", r = {};
    if (!M(i)) {
        r.$search_engine = i;
        var s = o ? ne(o.referrer, e) : "";
        s.length && (r.ph_keyword = s);
    }
    return r;
}
function os() {
    return navigator.language || navigator.userLanguage;
}
function as() {
    return (null == o ? void 0 : o.referrer) || "$direct";
}
function ls(t, i) {
    var e = t ? Ft([], Zr, i || []) : [], r = null == a ? void 0 : a.href.substring(0, 1e3);
    return {
        r: as().substring(0, 1e3),
        u: r ? oe(r, e, is) : void 0
    };
}
function us(t) {
    var i, { r: e, u: r } = t, s = {
        $referrer: e,
        $referring_domain: null == e ? void 0 : "$direct" == e ? "$direct" : null == (i = re(e)) ? void 0 : i.host
    };
    if (r) {
        s.$current_url = r;
        var n = re(r);
        s.$host = null == n ? void 0 : n.host, s.$pathname = null == n ? void 0 : n.pathname;
        var o = ss(r);
        Ot(s, o);
    }
    if (e) {
        var a = ns(e);
        Ot(s, a);
    }
    return s;
}
function hs() {
    try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch (t) {
        return;
    }
}
function ds() {
    try {
        return (new Date).getTimezoneOffset();
    } catch (t) {
        return;
    }
}
function vs(i, e) {
    if (!d) return {};
    var r, s, n, o = i ? Ft([], Zr, e || []) : [], [l, u] = function(t) {
        for(var i = 0; i < Yr.length; i++){
            var [e, r] = Yr[i], s = e.exec(t), n = s && (T(r) ? r(s, t) : r);
            if (n) return n;
        }
        return [
            "",
            ""
        ];
    }(d);
    return Ot(Dt({
        $os: l,
        $os_version: u,
        $browser: Vr(d, navigator.vendor),
        $device: Xr(d),
        $device_type: (s = d, n = Xr(s), n === ar || n === or || "Kobo" === n || "Kindle Fire" === n || n === Dr ? nr : n === kr || n === Tr || n === Pr || n === Mr ? "Console" : n === ur ? "Wearable" : n ? er : "Desktop"),
        $timezone: hs(),
        $timezone_offset: ds()
    }), {
        $current_url: oe(null == a ? void 0 : a.href, o, is),
        $host: null == a ? void 0 : a.host,
        $pathname: null == a ? void 0 : a.pathname,
        $raw_user_agent: d.length > 1e3 ? d.substring(0, 997) + "..." : d,
        $browser_version: Kr(d, navigator.vendor),
        $browser_language: os(),
        $browser_language_prefix: (r = os(), "string" == typeof r ? r.split("-")[0] : void 0),
        $screen_height: null == t ? void 0 : t.screen.height,
        $screen_width: null == t ? void 0 : t.screen.width,
        $viewport_height: null == t ? void 0 : t.innerHeight,
        $viewport_width: null == t ? void 0 : t.innerWidth,
        $lib: "web",
        $lib_version: c.LIB_VERSION,
        $insert_id: Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10),
        $time: Date.now() / 1e3
    });
}
var cs = kt("[Web Vitals]"), fs = 9e5;
class ps {
    get allowedMetrics() {
        var t, i, e = I(this._instance.config.capture_performance) ? null == (t = this._instance.config.capture_performance) ? void 0 : t.web_vitals_allowed_metrics : void 0;
        return C(e) ? (null == (i = this._instance.persistence) ? void 0 : i.props[Zt]) || [
            "CLS",
            "FCP",
            "INP",
            "LCP"
        ] : e;
    }
    get flushToCaptureTimeoutMs() {
        return (I(this._instance.config.capture_performance) ? this._instance.config.capture_performance.web_vitals_delayed_flush_ms : void 0) || 5e3;
    }
    get Ft() {
        var t = I(this._instance.config.capture_performance) && j(this._instance.config.capture_performance.__web_vitals_max_value) ? this._instance.config.capture_performance.__web_vitals_max_value : fs;
        return 0 < t && t <= 6e4 ? fs : t;
    }
    get isEnabled() {
        var t = null == a ? void 0 : a.protocol;
        if ("http:" !== t && "https:" !== t) return cs.info("Web Vitals are disabled on non-http/https protocols"), !1;
        var i = I(this._instance.config.capture_performance) ? this._instance.config.capture_performance.web_vitals : D(this._instance.config.capture_performance) ? this._instance.config.capture_performance : void 0;
        return D(i) ? i : this.Tt;
    }
    startIfEnabled() {
        this.isEnabled && !this.C && (cs.info("enabled, starting..."), this.nt(this.lt));
    }
    onRemoteConfig(t) {
        var i = I(t.capturePerformance) && !!t.capturePerformance.web_vitals, e = I(t.capturePerformance) ? t.capturePerformance.web_vitals_allowed_metrics : void 0;
        this._instance.persistence && (this._instance.persistence.register({
            [Xt]: i
        }), this._instance.persistence.register({
            [Zt]: e
        })), this.Tt = i, this.startIfEnabled();
    }
    nt(t) {
        var i, e;
        null != (i = v.__PosthogExtensions__) && i.postHogWebVitalsCallbacks && t(), null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, "web-vitals", (i)=>{
            i ? cs.error("failed to load script", i) : t();
        });
    }
    Ot() {
        var i = t ? t.location.href : void 0;
        if (i) {
            var e = this._instance.config.mask_personal_data_properties, r = this._instance.config.custom_personal_data_properties, s = e ? Ft([], Zr, r || []) : [];
            return oe(i, s, is);
        }
        cs.error("Could not determine current URL");
    }
    constructor(t){
        var i;
        this.Tt = !1, this.C = !1, this.q = {
            url: void 0,
            metrics: [],
            firstMetricTimestamp: void 0
        }, this.It = ()=>{
            clearTimeout(this.Rt), 0 !== this.q.metrics.length && (this._instance.capture("$web_vitals", this.q.metrics.reduce((t, i)=>g({}, t, {
                    ["$web_vitals_" + i.name + "_event"]: g({}, i),
                    ["$web_vitals_" + i.name + "_value"]: i.value
                }), {})), this.q = {
                url: void 0,
                metrics: [],
                firstMetricTimestamp: void 0
            });
        }, this.Ct = (t)=>{
            var i, e = null == (i = this._instance.sessionManager) ? void 0 : i.checkAndGetSessionAndWindowId(!0);
            if (C(e)) cs.error("Could not read session ID. Dropping metrics!");
            else {
                this.q = this.q || {
                    url: void 0,
                    metrics: [],
                    firstMetricTimestamp: void 0
                };
                var r = this.Ot();
                if (!C(r)) if (A(null == t ? void 0 : t.name) || A(null == t ? void 0 : t.value)) cs.error("Invalid metric received", t);
                else if (this.Ft && t.value >= this.Ft) cs.error("Ignoring metric with value >= " + this.Ft, t);
                else this.q.url !== r && (this.It(), this.Rt = setTimeout(this.It, this.flushToCaptureTimeoutMs)), C(this.q.url) && (this.q.url = r), this.q.firstMetricTimestamp = C(this.q.firstMetricTimestamp) ? Date.now() : this.q.firstMetricTimestamp, t.attribution && t.attribution.interactionTargetElement && (t.attribution.interactionTargetElement = void 0), this.q.metrics.push(g({}, t, {
                    $current_url: r,
                    $session_id: e.sessionId,
                    $window_id: e.windowId,
                    timestamp: Date.now()
                })), this.q.metrics.length === this.allowedMetrics.length && this.It();
            }
        }, this.lt = ()=>{
            var t, i, e, r, s = v.__PosthogExtensions__;
            C(s) || C(s.postHogWebVitalsCallbacks) || ({ onLCP: t, onCLS: i, onFCP: e, onINP: r } = s.postHogWebVitalsCallbacks), t && i && e && r ? (this.allowedMetrics.indexOf("LCP") > -1 && t(this.Ct.bind(this)), this.allowedMetrics.indexOf("CLS") > -1 && i(this.Ct.bind(this)), this.allowedMetrics.indexOf("FCP") > -1 && e(this.Ct.bind(this)), this.allowedMetrics.indexOf("INP") > -1 && r(this.Ct.bind(this)), this.C = !0) : cs.error("web vitals callbacks not loaded - not starting");
        }, this._instance = t, this.Tt = !(null == (i = this._instance.persistence) || !i.props[Xt]), this.startIfEnabled();
    }
}
var gs = kt("[Heatmaps]");
function _s(t) {
    return I(t) && "clientX" in t && "clientY" in t && j(t.clientX) && j(t.clientY);
}
class ms {
    get flushIntervalMilliseconds() {
        var t = 5e3;
        return I(this.instance.config.capture_heatmaps) && this.instance.config.capture_heatmaps.flush_interval_milliseconds && (t = this.instance.config.capture_heatmaps.flush_interval_milliseconds), t;
    }
    get isEnabled() {
        return C(this.instance.config.capture_heatmaps) ? C(this.instance.config.enable_heatmaps) ? this.Tt : this.instance.config.enable_heatmaps : !1 !== this.instance.config.capture_heatmaps;
    }
    startIfEnabled() {
        if (this.isEnabled) {
            if (this.C) return;
            gs.info("starting..."), this.At(), this.Mt = setInterval(this.jt.bind(this), this.flushIntervalMilliseconds);
        } else {
            var t, i;
            clearInterval(null !== (t = this.Mt) && void 0 !== t ? t : void 0), null == (i = this.Dt) || i.stop(), this.getAndClearBuffer();
        }
    }
    onRemoteConfig(t) {
        var i = !!t.heatmaps;
        this.instance.persistence && this.instance.persistence.register({
            [Vt]: i
        }), this.Tt = i, this.startIfEnabled();
    }
    getAndClearBuffer() {
        var t = this.q;
        return this.q = void 0, t;
    }
    Lt(t) {
        this.Nt(t.originalEvent, "deadclick");
    }
    At() {
        t && o && (Ht(t, "beforeunload", this.jt.bind(this)), Ht(o, "click", (i)=>this.Nt(i || (null == t ? void 0 : t.event)), {
            capture: !0
        }), Ht(o, "mousemove", (i)=>this.Ut(i || (null == t ? void 0 : t.event)), {
            capture: !0
        }), this.Dt = new Ne(this.instance, De, this.Lt.bind(this)), this.Dt.startIfEnabled(), this.C = !0);
    }
    zt(i, e) {
        var r = this.instance.scrollManager.scrollY(), s = this.instance.scrollManager.scrollX(), n = this.instance.scrollManager.scrollElement(), o = function(i, e, r) {
            for(var s = i; s && Si(s) && !xi(s, "body");){
                if (s === r) return !1;
                if (y(e, null == t ? void 0 : t.getComputedStyle(s).position)) return !0;
                s = Mi(s);
            }
            return !1;
        }(Ci(i), [
            "fixed",
            "sticky"
        ], n);
        return {
            x: i.clientX + (o ? 0 : s),
            y: i.clientY + (o ? 0 : r),
            target_fixed: o,
            type: e
        };
    }
    Nt(t, i) {
        var e;
        if (void 0 === i && (i = "click"), !wi(t.target) && _s(t)) {
            var r = this.zt(t, i);
            null != (e = this.rageclicks) && e.isRageClick(t.clientX, t.clientY, (new Date).getTime()) && this.Ht(g({}, r, {
                type: "rageclick"
            })), this.Ht(r);
        }
    }
    Ut(t) {
        !wi(t.target) && _s(t) && (clearTimeout(this.Bt), this.Bt = setTimeout(()=>{
            this.Ht(this.zt(t, "mousemove"));
        }, 500));
    }
    Ht(i) {
        if (t) {
            var e = t.location.href, r = this.instance.config.mask_personal_data_properties, s = this.instance.config.custom_personal_data_properties, n = r ? Ft([], Zr, s || []) : [], o = oe(e, n, is);
            this.q = this.q || {}, this.q[o] || (this.q[o] = []), this.q[o].push(i);
        }
    }
    jt() {
        this.q && !R(this.q) && this.instance.capture("$$heatmap", {
            $heatmap_data: this.getAndClearBuffer()
        });
    }
    constructor(t){
        var i;
        this.rageclicks = new Zi, this.Tt = !1, this.C = !1, this.Mt = null, this.instance = t, this.Tt = !(null == (i = this.instance.persistence) || !i.props[Vt]);
    }
}
class ys {
    doPageView(i, e) {
        var r, s = this.qt(i, e);
        return this.Wt = {
            pathname: null !== (r = null == t ? void 0 : t.location.pathname) && void 0 !== r ? r : "",
            pageViewId: e,
            timestamp: i
        }, this._instance.scrollManager.resetContext(), s;
    }
    doPageLeave(t) {
        var i;
        return this.qt(t, null == (i = this.Wt) ? void 0 : i.pageViewId);
    }
    doEvent() {
        var t;
        return {
            $pageview_id: null == (t = this.Wt) ? void 0 : t.pageViewId
        };
    }
    qt(t, i) {
        var e = this.Wt;
        if (!e) return {
            $pageview_id: i
        };
        var r = {
            $pageview_id: i,
            $prev_pageview_id: e.pageViewId
        }, s = this._instance.scrollManager.getContext();
        if (s && !this._instance.config.disable_scroll_properties) {
            var { maxScrollHeight: n, lastScrollY: o, maxScrollY: a, maxContentHeight: l, lastContentY: u, maxContentY: h } = s;
            if (!(C(n) || C(o) || C(a) || C(l) || C(u) || C(h))) {
                n = Math.ceil(n), o = Math.ceil(o), a = Math.ceil(a), l = Math.ceil(l), u = Math.ceil(u), h = Math.ceil(h);
                var d = n <= 1 ? 1 : G(o / n, 0, 1, $t), v = n <= 1 ? 1 : G(a / n, 0, 1, $t), c = l <= 1 ? 1 : G(u / l, 0, 1, $t), f = l <= 1 ? 1 : G(h / l, 0, 1, $t);
                r = Ot(r, {
                    $prev_pageview_last_scroll: o,
                    $prev_pageview_last_scroll_percentage: d,
                    $prev_pageview_max_scroll: a,
                    $prev_pageview_max_scroll_percentage: v,
                    $prev_pageview_last_content: u,
                    $prev_pageview_last_content_percentage: c,
                    $prev_pageview_max_content: h,
                    $prev_pageview_max_content_percentage: f
                });
            }
        }
        return e.pathname && (r.$prev_pageview_pathname = e.pathname), e.timestamp && (r.$prev_pageview_duration = (t.getTime() - e.timestamp.getTime()) / 1e3), r;
    }
    constructor(t){
        this._instance = t;
    }
}
var bs = Uint8Array, ws = Uint16Array, Ss = Uint32Array, xs = new bs([
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    0,
    0,
    0,
    0
]), Es = new bs([
    0,
    0,
    0,
    0,
    1,
    1,
    2,
    2,
    3,
    3,
    4,
    4,
    5,
    5,
    6,
    6,
    7,
    7,
    8,
    8,
    9,
    9,
    10,
    10,
    11,
    11,
    12,
    12,
    13,
    13,
    0,
    0
]), $s = new bs([
    16,
    17,
    18,
    0,
    8,
    7,
    9,
    6,
    10,
    5,
    11,
    4,
    12,
    3,
    13,
    2,
    14,
    1,
    15
]), ks = function(t, i) {
    for(var e = new ws(31), r = 0; r < 31; ++r)e[r] = i += 1 << t[r - 1];
    var s = new Ss(e[30]);
    for(r = 1; r < 30; ++r)for(var n = e[r]; n < e[r + 1]; ++n)s[n] = n - e[r] << 5 | r;
    return [
        e,
        s
    ];
}, Ps = ks(xs, 2), Ts = Ps[0], Is = Ps[1];
Ts[28] = 258, Is[258] = 28;
for(var Rs = ks(Es, 0)[1], Cs = new ws(32768), Os = 0; Os < 32768; ++Os){
    var Fs = (43690 & Os) >>> 1 | (21845 & Os) << 1;
    Fs = (61680 & (Fs = (52428 & Fs) >>> 2 | (13107 & Fs) << 2)) >>> 4 | (3855 & Fs) << 4, Cs[Os] = ((65280 & Fs) >>> 8 | (255 & Fs) << 8) >>> 1;
}
var Ms = function(t, i, e) {
    for(var r = t.length, s = 0, n = new ws(i); s < r; ++s)++n[t[s] - 1];
    var o, a = new ws(i);
    for(s = 0; s < i; ++s)a[s] = a[s - 1] + n[s - 1] << 1;
    if (e) {
        o = new ws(1 << i);
        var l = 15 - i;
        for(s = 0; s < r; ++s)if (t[s]) for(var u = s << 4 | t[s], h = i - t[s], d = a[t[s] - 1]++ << h, v = d | (1 << h) - 1; d <= v; ++d)o[Cs[d] >>> l] = u;
    } else for(o = new ws(r), s = 0; s < r; ++s)o[s] = Cs[a[t[s] - 1]++] >>> 15 - t[s];
    return o;
}, As = new bs(288);
for(Os = 0; Os < 144; ++Os)As[Os] = 8;
for(Os = 144; Os < 256; ++Os)As[Os] = 9;
for(Os = 256; Os < 280; ++Os)As[Os] = 7;
for(Os = 280; Os < 288; ++Os)As[Os] = 8;
var js = new bs(32);
for(Os = 0; Os < 32; ++Os)js[Os] = 5;
var Ds = Ms(As, 9, 0), Ls = Ms(js, 5, 0), Ns = function(t) {
    return (t / 8 >> 0) + (7 & t && 1);
}, Us = function(t, i, e) {
    (null == e || e > t.length) && (e = t.length);
    var r = new (t instanceof ws ? ws : t instanceof Ss ? Ss : bs)(e - i);
    return r.set(t.subarray(i, e)), r;
}, zs = function(t, i, e) {
    e <<= 7 & i;
    var r = i / 8 >> 0;
    t[r] |= e, t[r + 1] |= e >>> 8;
}, Hs = function(t, i, e) {
    e <<= 7 & i;
    var r = i / 8 >> 0;
    t[r] |= e, t[r + 1] |= e >>> 8, t[r + 2] |= e >>> 16;
}, Bs = function(t, i) {
    for(var e = [], r = 0; r < t.length; ++r)t[r] && e.push({
        s: r,
        f: t[r]
    });
    var s = e.length, n = e.slice();
    if (!s) return [
        new bs(0),
        0
    ];
    if (1 == s) {
        var o = new bs(e[0].s + 1);
        return o[e[0].s] = 1, [
            o,
            1
        ];
    }
    e.sort(function(t, i) {
        return t.f - i.f;
    }), e.push({
        s: -1,
        f: 25001
    });
    var a = e[0], l = e[1], u = 0, h = 1, d = 2;
    for(e[0] = {
        s: -1,
        f: a.f + l.f,
        l: a,
        r: l
    }; h != s - 1;)a = e[e[u].f < e[d].f ? u++ : d++], l = e[u != h && e[u].f < e[d].f ? u++ : d++], e[h++] = {
        s: -1,
        f: a.f + l.f,
        l: a,
        r: l
    };
    var v = n[0].s;
    for(r = 1; r < s; ++r)n[r].s > v && (v = n[r].s);
    var c = new ws(v + 1), f = qs(e[h - 1], c, 0);
    if (f > i) {
        r = 0;
        var p = 0, g = f - i, _ = 1 << g;
        for(n.sort(function(t, i) {
            return c[i.s] - c[t.s] || t.f - i.f;
        }); r < s; ++r){
            var m = n[r].s;
            if (!(c[m] > i)) break;
            p += _ - (1 << f - c[m]), c[m] = i;
        }
        for(p >>>= g; p > 0;){
            var y = n[r].s;
            c[y] < i ? p -= 1 << i - c[y]++ - 1 : ++r;
        }
        for(; r >= 0 && p; --r){
            var b = n[r].s;
            c[b] == i && (--c[b], ++p);
        }
        f = i;
    }
    return [
        new bs(c),
        f
    ];
}, qs = function(t, i, e) {
    return -1 == t.s ? Math.max(qs(t.l, i, e + 1), qs(t.r, i, e + 1)) : i[t.s] = e;
}, Ws = function(t) {
    for(var i = t.length; i && !t[--i];);
    for(var e = new ws(++i), r = 0, s = t[0], n = 1, o = function(t) {
        e[r++] = t;
    }, a = 1; a <= i; ++a)if (t[a] == s && a != i) ++n;
    else {
        if (!s && n > 2) {
            for(; n > 138; n -= 138)o(32754);
            n > 2 && (o(n > 10 ? n - 11 << 5 | 28690 : n - 3 << 5 | 12305), n = 0);
        } else if (n > 3) {
            for(o(s), --n; n > 6; n -= 6)o(8304);
            n > 2 && (o(n - 3 << 5 | 8208), n = 0);
        }
        for(; n--;)o(s);
        n = 1, s = t[a];
    }
    return [
        e.subarray(0, r),
        i
    ];
}, Gs = function(t, i) {
    for(var e = 0, r = 0; r < i.length; ++r)e += t[r] * i[r];
    return e;
}, Vs = function(t, i, e) {
    var r = e.length, s = Ns(i + 2);
    t[s] = 255 & r, t[s + 1] = r >>> 8, t[s + 2] = 255 ^ t[s], t[s + 3] = 255 ^ t[s + 1];
    for(var n = 0; n < r; ++n)t[s + n + 4] = e[n];
    return 8 * (s + 4 + r);
}, Js = function(t, i, e, r, s, n, o, a, l, u, h) {
    zs(i, h++, e), ++s[256];
    for(var d = Bs(s, 15), v = d[0], c = d[1], f = Bs(n, 15), p = f[0], g = f[1], _ = Ws(v), m = _[0], y = _[1], b = Ws(p), w = b[0], S = b[1], x = new ws(19), E = 0; E < m.length; ++E)x[31 & m[E]]++;
    for(E = 0; E < w.length; ++E)x[31 & w[E]]++;
    for(var k = Bs(x, 7), P = k[0], T = k[1], I = 19; I > 4 && !P[$s[I - 1]]; --I);
    var R, C, O, F, M = u + 5 << 3, A = Gs(s, As) + Gs(n, js) + o, j = Gs(s, v) + Gs(n, p) + o + 14 + 3 * I + Gs(x, P) + (2 * x[16] + 3 * x[17] + 7 * x[18]);
    if (M <= A && M <= j) return Vs(i, h, t.subarray(l, l + u));
    if (zs(i, h, 1 + (j < A)), h += 2, j < A) {
        R = Ms(v, c, 0), C = v, O = Ms(p, g, 0), F = p;
        var D = Ms(P, T, 0);
        zs(i, h, y - 257), zs(i, h + 5, S - 1), zs(i, h + 10, I - 4), h += 14;
        for(E = 0; E < I; ++E)zs(i, h + 3 * E, P[$s[E]]);
        h += 3 * I;
        for(var L = [
            m,
            w
        ], N = 0; N < 2; ++N){
            var U = L[N];
            for(E = 0; E < U.length; ++E){
                var z = 31 & U[E];
                zs(i, h, D[z]), h += P[z], z > 15 && (zs(i, h, U[E] >>> 5 & 127), h += U[E] >>> 12);
            }
        }
    } else R = Ds, C = As, O = Ls, F = js;
    for(E = 0; E < a; ++E)if (r[E] > 255) {
        z = r[E] >>> 18 & 31;
        Hs(i, h, R[z + 257]), h += C[z + 257], z > 7 && (zs(i, h, r[E] >>> 23 & 31), h += xs[z]);
        var H = 31 & r[E];
        Hs(i, h, O[H]), h += F[H], H > 3 && (Hs(i, h, r[E] >>> 5 & 8191), h += Es[H]);
    } else Hs(i, h, R[r[E]]), h += C[r[E]];
    return Hs(i, h, R[256]), h + C[256];
}, Ks = new Ss([
    65540,
    131080,
    131088,
    131104,
    262176,
    1048704,
    1048832,
    2114560,
    2117632
]), Ys = function() {
    for(var t = new Ss(256), i = 0; i < 256; ++i){
        for(var e = i, r = 9; --r;)e = (1 & e && 3988292384) ^ e >>> 1;
        t[i] = e;
    }
    return t;
}(), Xs = function(t, i, e, r, s) {
    return function(t, i, e, r, s, n) {
        var o = t.length, a = new bs(r + o + 5 * (1 + Math.floor(o / 7e3)) + s), l = a.subarray(r, a.length - s), u = 0;
        if (!i || o < 8) for(var h = 0; h <= o; h += 65535){
            var d = h + 65535;
            d < o ? u = Vs(l, u, t.subarray(h, d)) : (l[h] = n, u = Vs(l, u, t.subarray(h, o)));
        }
        else {
            for(var v = Ks[i - 1], c = v >>> 13, f = 8191 & v, p = (1 << e) - 1, g = new ws(32768), _ = new ws(p + 1), m = Math.ceil(e / 3), y = 2 * m, b = function(i) {
                return (t[i] ^ t[i + 1] << m ^ t[i + 2] << y) & p;
            }, w = new Ss(25e3), S = new ws(288), x = new ws(32), E = 0, k = 0, P = (h = 0, 0), T = 0, I = 0; h < o; ++h){
                var R = b(h), C = 32767 & h, O = _[R];
                if (g[C] = O, _[R] = C, T <= h) {
                    var F = o - h;
                    if ((E > 7e3 || P > 24576) && F > 423) {
                        u = Js(t, l, 0, w, S, x, k, P, I, h - I, u), P = E = k = 0, I = h;
                        for(var M = 0; M < 286; ++M)S[M] = 0;
                        for(M = 0; M < 30; ++M)x[M] = 0;
                    }
                    var A = 2, j = 0, D = f, L = C - O & 32767;
                    if (F > 2 && R == b(h - L)) for(var N = Math.min(c, F) - 1, U = Math.min(32767, h), z = Math.min(258, F); L <= U && --D && C != O;){
                        if (t[h + A] == t[h + A - L]) {
                            for(var H = 0; H < z && t[h + H] == t[h + H - L]; ++H);
                            if (H > A) {
                                if (A = H, j = L, H > N) break;
                                var B = Math.min(L, H - 2), q = 0;
                                for(M = 0; M < B; ++M){
                                    var W = h - L + M + 32768 & 32767, G = W - g[W] + 32768 & 32767;
                                    G > q && (q = G, O = W);
                                }
                            }
                        }
                        L += (C = O) - (O = g[C]) + 32768 & 32767;
                    }
                    if (j) {
                        w[P++] = 268435456 | Is[A] << 18 | Rs[j];
                        var V = 31 & Is[A], J = 31 & Rs[j];
                        k += xs[V] + Es[J], ++S[257 + V], ++x[J], T = h + A, ++E;
                    } else w[P++] = t[h], ++S[t[h]];
                }
            }
            u = Js(t, l, n, w, S, x, k, P, I, h - I, u);
        }
        return Us(a, 0, r + Ns(u) + s);
    }(t, null == i.level ? 6 : i.level, null == i.mem ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(t.length)))) : 12 + i.mem, e, r, !0);
}, Qs = function(t, i, e) {
    for(; e; ++i)t[i] = e, e >>>= 8;
};
function Zs(t, i) {
    void 0 === i && (i = {});
    var e = function() {
        var t = 4294967295;
        return {
            p: function(i) {
                for(var e = t, r = 0; r < i.length; ++r)e = Ys[255 & e ^ i[r]] ^ e >>> 8;
                t = e;
            },
            d: function() {
                return 4294967295 ^ t;
            }
        };
    }(), r = t.length;
    e.p(t);
    var s, n = Xs(t, i, 10 + ((s = i).filename && s.filename.length + 1 || 0), 8), o = n.length;
    return function(t, i) {
        var e = i.filename;
        if (t[0] = 31, t[1] = 139, t[2] = 8, t[8] = i.level < 2 ? 4 : 9 == i.level ? 2 : 0, t[9] = 3, 0 != i.mtime && Qs(t, 4, Math.floor(new Date(i.mtime || Date.now()) / 1e3)), e) {
            t[3] = 8;
            for(var r = 0; r <= e.length; ++r)t[r + 10] = e.charCodeAt(r);
        }
    }(n, i), Qs(n, o - 8, e.d()), Qs(n, o - 4, r), n;
}
var tn = function(t) {
    var i, e, r, s, n = "";
    for(i = e = 0, r = (t = (t + "").replace(/\r\n/g, "\n").replace(/\r/g, "\n")).length, s = 0; s < r; s++){
        var o = t.charCodeAt(s), a = null;
        o < 128 ? e++ : a = o > 127 && o < 2048 ? String.fromCharCode(o >> 6 | 192, 63 & o | 128) : String.fromCharCode(o >> 12 | 224, o >> 6 & 63 | 128, 63 & o | 128), M(a) || (e > i && (n += t.substring(i, e)), n += a, i = e = s + 1);
    }
    return e > i && (n += t.substring(i, t.length)), n;
}, en = !!u || !!l, rn = "text/plain", sn = (t, i)=>{
    var [e, r] = t.split("?"), s = g({}, i);
    null == r || r.split("&").forEach((t)=>{
        var [i] = t.split("=");
        delete s[i];
    });
    var n = se(s);
    return e + "?" + (n = n ? (r ? r + "&" : "") + n : r);
}, nn = (t, i)=>JSON.stringify(t, (t, i)=>"bigint" == typeof i ? i.toString() : i, i), on = (t)=>{
    var { data: i, compression: e } = t;
    if (i) {
        if (e === ie.GZipJS) {
            var r = Zs(function(t, i) {
                var e = t.length;
                if ("undefined" != typeof TextEncoder) return (new TextEncoder).encode(t);
                for(var r = new bs(t.length + (t.length >>> 1)), s = 0, n = function(t) {
                    r[s++] = t;
                }, o = 0; o < e; ++o){
                    if (s + 5 > r.length) {
                        var a = new bs(s + 8 + (e - o << 1));
                        a.set(r), r = a;
                    }
                    var l = t.charCodeAt(o);
                    l < 128 || i ? n(l) : l < 2048 ? (n(192 | l >>> 6), n(128 | 63 & l)) : l > 55295 && l < 57344 ? (n(240 | (l = 65536 + (1047552 & l) | 1023 & t.charCodeAt(++o)) >>> 18), n(128 | l >>> 12 & 63), n(128 | l >>> 6 & 63), n(128 | 63 & l)) : (n(224 | l >>> 12), n(128 | l >>> 6 & 63), n(128 | 63 & l));
                }
                return Us(r, 0, s);
            }(nn(i)), {
                mtime: 0
            }), s = new Blob([
                r
            ], {
                type: rn
            });
            return {
                contentType: rn,
                body: s,
                estimatedSize: s.size
            };
        }
        if (e === ie.Base64) {
            var n = function(t) {
                var i, e, r, s, n, o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a = 0, l = 0, u = "", h = [];
                if (!t) return t;
                t = tn(t);
                do {
                    i = (n = t.charCodeAt(a++) << 16 | t.charCodeAt(a++) << 8 | t.charCodeAt(a++)) >> 18 & 63, e = n >> 12 & 63, r = n >> 6 & 63, s = 63 & n, h[l++] = o.charAt(i) + o.charAt(e) + o.charAt(r) + o.charAt(s);
                }while (a < t.length)
                switch(u = h.join(""), t.length % 3){
                    case 1:
                        u = u.slice(0, -2) + "==";
                        break;
                    case 2:
                        u = u.slice(0, -1) + "=";
                }
                return u;
            }(nn(i)), o = ((t)=>"data=" + encodeURIComponent("string" == typeof t ? t : nn(t)))(n);
            return {
                contentType: "application/x-www-form-urlencoded",
                body: o,
                estimatedSize: new Blob([
                    o
                ]).size
            };
        }
        var a = nn(i);
        return {
            contentType: "application/json",
            body: a,
            estimatedSize: new Blob([
                a
            ]).size
        };
    }
}, an = [];
l && an.push({
    transport: "fetch",
    method: (t)=>{
        var i, e, { contentType: r, body: s, estimatedSize: n } = null !== (i = on(t)) && void 0 !== i ? i : {}, o = new Headers;
        Ct(t.headers, function(t, i) {
            o.append(i, t);
        }), r && o.append("Content-Type", r);
        var a = t.url, u = null;
        if (h) {
            var d = new h;
            u = {
                signal: d.signal,
                timeout: setTimeout(()=>d.abort(), t.timeout)
            };
        }
        l(a, g({
            method: (null == t ? void 0 : t.method) || "GET",
            headers: o,
            keepalive: "POST" === t.method && (n || 0) < 52428.8,
            body: s,
            signal: null == (e = u) ? void 0 : e.signal
        }, t.fetchOptions)).then((i)=>i.text().then((e)=>{
                var r = {
                    statusCode: i.status,
                    text: e
                };
                if (200 === i.status) try {
                    r.json = JSON.parse(e);
                } catch (t) {
                    $t.error(t);
                }
                null == t.callback || t.callback(r);
            })).catch((i)=>{
            $t.error(i), null == t.callback || t.callback({
                statusCode: 0,
                text: i
            });
        }).finally(()=>u ? clearTimeout(u.timeout) : null);
    }
}), u && an.push({
    transport: "XHR",
    method: (t)=>{
        var i, e = new u;
        e.open(t.method || "GET", t.url, !0);
        var { contentType: r, body: s } = null !== (i = on(t)) && void 0 !== i ? i : {};
        Ct(t.headers, function(t, i) {
            e.setRequestHeader(i, t);
        }), r && e.setRequestHeader("Content-Type", r), t.timeout && (e.timeout = t.timeout), t.disableXHRCredentials || (e.withCredentials = !0), e.onreadystatechange = ()=>{
            if (4 === e.readyState) {
                var i = {
                    statusCode: e.status,
                    text: e.responseText
                };
                if (200 === e.status) try {
                    i.json = JSON.parse(e.responseText);
                } catch (t) {}
                null == t.callback || t.callback(i);
            }
        }, e.send(s);
    }
}), null != n && n.sendBeacon && an.push({
    transport: "sendBeacon",
    method: (t)=>{
        var i = sn(t.url, {
            beacon: "1"
        });
        try {
            var e, { contentType: r, body: s } = null !== (e = on(t)) && void 0 !== e ? e : {}, o = "string" == typeof s ? new Blob([
                s
            ], {
                type: r
            }) : s;
            n.sendBeacon(i, o);
        } catch (t) {}
    }
});
var ln = function(t, i) {
    if (!function(t) {
        try {
            new RegExp(t);
        } catch (t) {
            return !1;
        }
        return !0;
    }(i)) return !1;
    try {
        return new RegExp(i).test(t);
    } catch (t) {
        return !1;
    }
};
function un(t, i, e) {
    return nn({
        distinct_id: t,
        userPropertiesToSet: i,
        userPropertiesToSetOnce: e
    });
}
var hn = {
    exact: (t, i)=>i.some((i)=>t.some((t)=>i === t)),
    is_not: (t, i)=>i.every((i)=>t.every((t)=>i !== t)),
    regex: (t, i)=>i.some((i)=>t.some((t)=>ln(i, t))),
    not_regex: (t, i)=>i.every((i)=>t.every((t)=>!ln(i, t))),
    icontains: (t, i)=>i.map(dn).some((i)=>t.map(dn).some((t)=>i.includes(t))),
    not_icontains: (t, i)=>i.map(dn).every((i)=>t.map(dn).every((t)=>!i.includes(t)))
}, dn = (t)=>t.toLowerCase(), vn = kt("[Error tracking]");
class cn {
    onRemoteConfig(t) {
        var i, e, r, s = null !== (i = null == (e = t.errorTracking) ? void 0 : e.suppressionRules) && void 0 !== i ? i : [], n = null == (r = t.errorTracking) ? void 0 : r.captureExtensionExceptions;
        this.Gt = s, this._instance.persistence && this._instance.persistence.register({
            [Kt]: this.Gt,
            [Yt]: n
        });
    }
    get Jt() {
        var t, i = !!this._instance.get_property(Yt), e = this._instance.config.error_tracking.captureExtensionExceptions;
        return null !== (t = null != e ? e : i) && void 0 !== t && t;
    }
    buildProperties(t, i) {
        return this.Vt.buildFromUnknown(t, {
            syntheticException: null == i ? void 0 : i.syntheticException,
            mechanism: {
                handled: null == i ? void 0 : i.handled
            }
        });
    }
    sendExceptionEvent(t) {
        if (this.Kt(t)) vn.info("Skipping exception capture because a suppression rule matched");
        else {
            if (this.Jt || !this.Yt(t)) return this._instance.capture("$exception", t, {
                _noTruncate: !0,
                _batchKey: "exceptionEvent"
            });
            vn.info("Skipping exception capture because it was thrown by an extension");
        }
    }
    Kt(t) {
        var i = t.$exception_list;
        if (!i || !P(i) || 0 === i.length) return !1;
        var e = i.reduce((t, i)=>{
            var { type: e, value: r } = i;
            return O(e) && e.length > 0 && t.$exception_types.push(e), O(r) && r.length > 0 && t.$exception_values.push(r), t;
        }, {
            $exception_types: [],
            $exception_values: []
        });
        return this.Gt.some((t)=>{
            var i = t.values.map((t)=>{
                var i, r = hn[t.operator], s = P(t.value) ? t.value : [
                    t.value
                ], n = null !== (i = e[t.key]) && void 0 !== i ? i : [];
                return s.length > 0 && r(s, n);
            });
            return "OR" === t.type ? i.some(Boolean) : i.every(Boolean);
        });
    }
    Yt(t) {
        var i = t.$exception_list;
        return !(!i || !P(i)) && i.flatMap((t)=>{
            var i, e;
            return null !== (i = null == (e = t.stacktrace) ? void 0 : e.frames) && void 0 !== i ? i : [];
        }).some((t)=>t.filename && t.filename.startsWith("chrome-extension://"));
    }
    constructor(t){
        var i, e;
        this.Gt = [], this.Vt = new vt([
            new ct,
            new xt,
            new pt,
            new ft,
            new wt,
            new bt,
            new _t,
            new St
        ], [
            nt,
            lt
        ]), this._instance = t, this.Gt = null !== (i = null == (e = this._instance.persistence) ? void 0 : e.get_property(Kt)) && void 0 !== i ? i : [];
    }
}
var fn = kt("[FeatureFlags]"), pn = "$active_feature_flags", gn = "$override_feature_flags", _n = "$feature_flag_payloads", mn = "$override_feature_flag_payloads", yn = "$feature_flag_request_id", bn = (t)=>{
    var i = {};
    for (var [e, r] of Mt(t || {}))r && (i[e] = r);
    return i;
}, wn = (t)=>{
    var i = t.flags;
    return i ? (t.featureFlags = Object.fromEntries(Object.keys(i).map((t)=>{
        var e;
        return [
            t,
            null !== (e = i[t].variant) && void 0 !== e ? e : i[t].enabled
        ];
    })), t.featureFlagPayloads = Object.fromEntries(Object.keys(i).filter((t)=>i[t].enabled).filter((t)=>{
        var e;
        return null == (e = i[t].metadata) ? void 0 : e.payload;
    }).map((t)=>{
        var e;
        return [
            t,
            null == (e = i[t].metadata) ? void 0 : e.payload
        ];
    }))) : fn.warn("Using an older version of the feature flags endpoint. Please upgrade your PostHog server to the latest version"), t;
}, Sn = function(t) {
    return t.FeatureFlags = "feature_flags", t.Recordings = "recordings", t;
}({});
class xn {
    si() {
        var t = this._instance.config.evaluation_environments;
        return null != t && t.length ? t.filter((t)=>{
            var i = t && "string" == typeof t && t.trim().length > 0;
            return i || fn.error("Invalid evaluation environment found:", t, "Expected non-empty string"), i;
        }) : [];
    }
    ni() {
        return this.si().length > 0;
    }
    flags() {
        if (this._instance.config.__preview_remote_config) this.ei = !0;
        else {
            var t = !this.oi && (this._instance.config.advanced_disable_feature_flags || this._instance.config.advanced_disable_feature_flags_on_first_load);
            this.ai({
                disableFlags: t
            });
        }
    }
    get hasLoadedFlags() {
        return this.Qt;
    }
    getFlags() {
        return Object.keys(this.getFlagVariants());
    }
    getFlagsWithDetails() {
        var t = this._instance.get_property(ni), i = this._instance.get_property(gn), e = this._instance.get_property(mn);
        if (!e && !i) return t || {};
        var r = Ot({}, t || {}), s = [
            ...new Set([
                ...Object.keys(e || {}),
                ...Object.keys(i || {})
            ])
        ];
        for (var n of s){
            var o, a, l = r[n], u = null == i ? void 0 : i[n], h = C(u) ? null !== (o = null == l ? void 0 : l.enabled) && void 0 !== o && o : !!u, d = C(u) ? l.variant : "string" == typeof u ? u : void 0, v = null == e ? void 0 : e[n], c = g({}, l, {
                enabled: h,
                variant: h ? null != d ? d : null == l ? void 0 : l.variant : void 0
            });
            if (h !== (null == l ? void 0 : l.enabled) && (c.original_enabled = null == l ? void 0 : l.enabled), d !== (null == l ? void 0 : l.variant) && (c.original_variant = null == l ? void 0 : l.variant), v) c.metadata = g({}, null == l ? void 0 : l.metadata, {
                payload: v,
                original_payload: null == l || null == (a = l.metadata) ? void 0 : a.payload
            });
            r[n] = c;
        }
        return this.Xt || (fn.warn(" Overriding feature flag details!", {
            flagDetails: t,
            overriddenPayloads: e,
            finalDetails: r
        }), this.Xt = !0), r;
    }
    getFlagVariants() {
        var t = this._instance.get_property(ri), i = this._instance.get_property(gn);
        if (!i) return t || {};
        for(var e = Ot({}, t), r = Object.keys(i), s = 0; s < r.length; s++)e[r[s]] = i[r[s]];
        return this.Xt || (fn.warn(" Overriding feature flags!", {
            enabledFlags: t,
            overriddenFlags: i,
            finalFlags: e
        }), this.Xt = !0), e;
    }
    getFlagPayloads() {
        var t = this._instance.get_property(_n), i = this._instance.get_property(mn);
        if (!i) return t || {};
        for(var e = Ot({}, t || {}), r = Object.keys(i), s = 0; s < r.length; s++)e[r[s]] = i[r[s]];
        return this.Xt || (fn.warn(" Overriding feature flag payloads!", {
            flagPayloads: t,
            overriddenPayloads: i,
            finalPayloads: e
        }), this.Xt = !0), e;
    }
    reloadFeatureFlags() {
        this.ti || this._instance.config.advanced_disable_feature_flags || this.oi || (this.oi = setTimeout(()=>{
            this.ai();
        }, 5));
    }
    li() {
        clearTimeout(this.oi), this.oi = void 0;
    }
    ensureFlagsLoaded() {
        this.Qt || this.Zt || this.oi || this.reloadFeatureFlags();
    }
    setAnonymousDistinctId(t) {
        this.$anon_distinct_id = t;
    }
    setReloadingPaused(t) {
        this.ti = t;
    }
    ai(t) {
        var i;
        if (this.li(), !this._instance.L()) if (this.Zt) this.ii = !0;
        else {
            var e = {
                token: this._instance.config.token,
                distinct_id: this._instance.get_distinct_id(),
                groups: this._instance.getGroups(),
                $anon_distinct_id: this.$anon_distinct_id,
                person_properties: g({}, (null == (i = this._instance.persistence) ? void 0 : i.get_initial_props()) || {}, this._instance.get_property(oi) || {}),
                group_properties: this._instance.get_property(ai)
            };
            (null != t && t.disableFlags || this._instance.config.advanced_disable_feature_flags) && (e.disable_flags = !0), this.ni() && (e.evaluation_environments = this.si());
            var r = this._instance.config.__preview_remote_config, s = r ? "/flags/?v=2" : "/flags/?v=2&config=true", n = this._instance.config.advanced_only_evaluate_survey_feature_flags ? "&only_evaluate_survey_feature_flags=true" : "", o = this._instance.requestRouter.endpointFor("api", s + n);
            r && (e.timezone = hs()), this.Zt = !0, this._instance.ui({
                method: "POST",
                url: o,
                data: e,
                compression: this._instance.config.disable_compression ? void 0 : ie.Base64,
                timeout: this._instance.config.feature_flag_request_timeout_ms,
                callback: (t)=>{
                    var i, r, s = !0;
                    (200 === t.statusCode && (this.ii || (this.$anon_distinct_id = void 0), s = !1), this.Zt = !1, this.ei) || (this.ei = !0, this._instance.hi(null !== (r = t.json) && void 0 !== r ? r : {}));
                    if (!e.disable_flags || this.ii) if (this.ri = !s, t.json && null != (i = t.json.quotaLimited) && i.includes(Sn.FeatureFlags)) fn.warn("You have hit your feature flags quota limit, and will not be able to load feature flags until the quota is reset.  Please visit https://posthog.com/docs/billing/limits-alerts to learn more.");
                    else {
                        var n;
                        if (!e.disable_flags) this.receivedFeatureFlags(null !== (n = t.json) && void 0 !== n ? n : {}, s);
                        this.ii && (this.ii = !1, this.ai());
                    }
                }
            });
        }
    }
    getFeatureFlag(t, i) {
        if (void 0 === i && (i = {}), this.Qt || this.getFlags() && this.getFlags().length > 0) {
            var e = this.getFlagVariants()[t], r = "" + e, s = this._instance.get_property(yn) || void 0, n = this._instance.get_property(hi) || {};
            if ((i.send_event || !("send_event" in i)) && (!(t in n) || !n[t].includes(r))) {
                var o, a, l, u, h, d, v, c, f;
                P(n[t]) ? n[t].push(r) : n[t] = [
                    r
                ], null == (o = this._instance.persistence) || o.register({
                    [hi]: n
                });
                var p = this.getFeatureFlagDetails(t), g = {
                    $feature_flag: t,
                    $feature_flag_response: e,
                    $feature_flag_payload: this.getFeatureFlagPayload(t) || null,
                    $feature_flag_request_id: s,
                    $feature_flag_bootstrapped_response: (null == (a = this._instance.config.bootstrap) || null == (a = a.featureFlags) ? void 0 : a[t]) || null,
                    $feature_flag_bootstrapped_payload: (null == (l = this._instance.config.bootstrap) || null == (l = l.featureFlagPayloads) ? void 0 : l[t]) || null,
                    $used_bootstrap_value: !this.ri
                };
                C(null == p || null == (u = p.metadata) ? void 0 : u.version) || (g.$feature_flag_version = p.metadata.version);
                var _, m = null !== (h = null == p || null == (d = p.reason) ? void 0 : d.description) && void 0 !== h ? h : null == p || null == (v = p.reason) ? void 0 : v.code;
                if (m && (g.$feature_flag_reason = m), null != p && null != (c = p.metadata) && c.id && (g.$feature_flag_id = p.metadata.id), C(null == p ? void 0 : p.original_variant) && C(null == p ? void 0 : p.original_enabled) || (g.$feature_flag_original_response = C(p.original_variant) ? p.original_enabled : p.original_variant), null != p && null != (f = p.metadata) && f.original_payload) g.$feature_flag_original_payload = null == p || null == (_ = p.metadata) ? void 0 : _.original_payload;
                this._instance.capture("$feature_flag_called", g);
            }
            return e;
        }
        fn.warn('getFeatureFlag for key "' + t + "\" failed. Feature flags didn't load in time.");
    }
    getFeatureFlagDetails(t) {
        return this.getFlagsWithDetails()[t];
    }
    getFeatureFlagPayload(t) {
        return this.getFlagPayloads()[t];
    }
    getRemoteConfigPayload(t, i) {
        var e = this._instance.config.token, r = {
            distinct_id: this._instance.get_distinct_id(),
            token: e
        };
        this.ni() && (r.evaluation_environments = this.si()), this._instance.ui({
            method: "POST",
            url: this._instance.requestRouter.endpointFor("api", "/flags/?v=2&config=true"),
            data: r,
            compression: this._instance.config.disable_compression ? void 0 : ie.Base64,
            timeout: this._instance.config.feature_flag_request_timeout_ms,
            callback: (e)=>{
                var r, s = null == (r = e.json) ? void 0 : r.featureFlagPayloads;
                i((null == s ? void 0 : s[t]) || void 0);
            }
        });
    }
    isFeatureEnabled(t, i) {
        if (void 0 === i && (i = {}), this.Qt || this.getFlags() && this.getFlags().length > 0) {
            var e = this.getFeatureFlag(t, i);
            return C(e) ? void 0 : !!e;
        }
        fn.warn('isFeatureEnabled for key "' + t + "\" failed. Feature flags didn't load in time.");
    }
    addFeatureFlagsHandler(t) {
        this.featureFlagEventHandlers.push(t);
    }
    removeFeatureFlagsHandler(t) {
        this.featureFlagEventHandlers = this.featureFlagEventHandlers.filter((i)=>i !== t);
    }
    receivedFeatureFlags(t, i) {
        if (this._instance.persistence) {
            this.Qt = !0;
            var e = this.getFlagVariants(), r = this.getFlagPayloads(), s = this.getFlagsWithDetails();
            !function(t, i, e, r, s) {
                void 0 === e && (e = {}), void 0 === r && (r = {}), void 0 === s && (s = {});
                var n = wn(t), o = n.flags, a = n.featureFlags, l = n.featureFlagPayloads;
                if (a) {
                    var u = t.requestId;
                    if (P(a)) {
                        fn.warn("v1 of the feature flags endpoint is deprecated. Please use the latest version.");
                        var h = {};
                        if (a) for(var d = 0; d < a.length; d++)h[a[d]] = !0;
                        i && i.register({
                            [pn]: a,
                            [ri]: h
                        });
                    } else {
                        var v = a, c = l, f = o;
                        t.errorsWhileComputingFlags && (v = g({}, e, v), c = g({}, r, c), f = g({}, s, f)), i && i.register(g({
                            [pn]: Object.keys(bn(v)),
                            [ri]: v || {},
                            [_n]: c || {},
                            [ni]: f || {}
                        }, u ? {
                            [yn]: u
                        } : {}));
                    }
                }
            }(t, this._instance.persistence, e, r, s), this.di(i);
        }
    }
    override(t, i) {
        void 0 === i && (i = !1), fn.warn("override is deprecated. Please use overrideFeatureFlags instead."), this.overrideFeatureFlags({
            flags: t,
            suppressWarning: i
        });
    }
    overrideFeatureFlags(t) {
        if (!this._instance.__loaded || !this._instance.persistence) return fn.uninitializedWarning("posthog.featureFlags.overrideFeatureFlags");
        if (!1 === t) return this._instance.persistence.unregister(gn), this._instance.persistence.unregister(mn), void this.di();
        if (t && "object" == typeof t && ("flags" in t || "payloads" in t)) {
            var i, e = t;
            if (this.Xt = Boolean(null !== (i = e.suppressWarning) && void 0 !== i && i), "flags" in e) {
                if (!1 === e.flags) this._instance.persistence.unregister(gn);
                else if (e.flags) if (P(e.flags)) {
                    for(var r = {}, s = 0; s < e.flags.length; s++)r[e.flags[s]] = !0;
                    this._instance.persistence.register({
                        [gn]: r
                    });
                } else this._instance.persistence.register({
                    [gn]: e.flags
                });
            }
            return "payloads" in e && (!1 === e.payloads ? this._instance.persistence.unregister(mn) : e.payloads && this._instance.persistence.register({
                [mn]: e.payloads
            })), void this.di();
        }
        this.di();
    }
    onFeatureFlags(t) {
        if (this.addFeatureFlagsHandler(t), this.Qt) {
            var { flags: i, flagVariants: e } = this.vi();
            t(i, e);
        }
        return ()=>this.removeFeatureFlagsHandler(t);
    }
    updateEarlyAccessFeatureEnrollment(t, i, e) {
        var r, s = (this._instance.get_property(si) || []).find((i)=>i.flagKey === t), n = {
            ["$feature_enrollment/" + t]: i
        }, o = {
            $feature_flag: t,
            $feature_enrollment: i,
            $set: n
        };
        s && (o.$early_access_feature_name = s.name), e && (o.$feature_enrollment_stage = e), this._instance.capture("$feature_enrollment_update", o), this.setPersonPropertiesForFlags(n, !1);
        var a = g({}, this.getFlagVariants(), {
            [t]: i
        });
        null == (r = this._instance.persistence) || r.register({
            [pn]: Object.keys(bn(a)),
            [ri]: a
        }), this.di();
    }
    getEarlyAccessFeatures(t, i, e) {
        void 0 === i && (i = !1);
        var r = this._instance.get_property(si), s = e ? "&" + e.map((t)=>"stage=" + t).join("&") : "";
        if (r && !i) return t(r);
        this._instance.ui({
            url: this._instance.requestRouter.endpointFor("api", "/api/early_access_features/?token=" + this._instance.config.token + s),
            method: "GET",
            callback: (i)=>{
                var e, r;
                if (i.json) {
                    var s = i.json.earlyAccessFeatures;
                    return null == (e = this._instance.persistence) || e.unregister(si), null == (r = this._instance.persistence) || r.register({
                        [si]: s
                    }), t(s);
                }
            }
        });
    }
    vi() {
        var t = this.getFlags(), i = this.getFlagVariants();
        return {
            flags: t.filter((t)=>i[t]),
            flagVariants: Object.keys(i).filter((t)=>i[t]).reduce((t, e)=>(t[e] = i[e], t), {})
        };
    }
    di(t) {
        var { flags: i, flagVariants: e } = this.vi();
        this.featureFlagEventHandlers.forEach((r)=>r(i, e, {
                errorsLoading: t
            }));
    }
    setPersonPropertiesForFlags(t, i) {
        void 0 === i && (i = !0);
        var e = this._instance.get_property(oi) || {};
        this._instance.register({
            [oi]: g({}, e, t)
        }), i && this._instance.reloadFeatureFlags();
    }
    resetPersonPropertiesForFlags() {
        this._instance.unregister(oi);
    }
    setGroupPropertiesForFlags(t, i) {
        void 0 === i && (i = !0);
        var e = this._instance.get_property(ai) || {};
        0 !== Object.keys(e).length && Object.keys(e).forEach((i)=>{
            e[i] = g({}, e[i], t[i]), delete t[i];
        }), this._instance.register({
            [ai]: g({}, e, t)
        }), i && this._instance.reloadFeatureFlags();
    }
    resetGroupPropertiesForFlags(t) {
        if (t) {
            var i = this._instance.get_property(ai) || {};
            this._instance.register({
                [ai]: g({}, i, {
                    [t]: {}
                })
            });
        } else this._instance.unregister(ai);
    }
    reset() {
        this.Qt = !1, this.Zt = !1, this.ti = !1, this.ii = !1, this.ei = !1, this.ri = !1, this.$anon_distinct_id = void 0, this.li(), this.Xt = !1;
    }
    constructor(t){
        this.Xt = !1, this.Qt = !1, this.Zt = !1, this.ti = !1, this.ii = !1, this.ei = !1, this.ri = !1, this._instance = t, this.featureFlagEventHandlers = [];
    }
}
var En = [
    "cookie",
    "localstorage",
    "localstorage+cookie",
    "sessionstorage",
    "memory"
];
class $n {
    isDisabled() {
        return !!this.gi;
    }
    pi(t) {
        -1 === En.indexOf(t.persistence.toLowerCase()) && ($t.critical("Unknown persistence type " + t.persistence + "; falling back to localStorage+cookie"), t.persistence = "localStorage+cookie");
        var i = t.persistence.toLowerCase();
        return "localstorage" === i && Pe.G() ? Pe : "localstorage+cookie" === i && Ie.G() ? Ie : "sessionstorage" === i && Fe.G() ? Fe : "memory" === i ? Ce : "cookie" === i ? $e : Ie.G() ? Ie : $e;
    }
    properties() {
        var t = {};
        return Ct(this.props, function(i, e) {
            if (e === ri && I(i)) for(var r = Object.keys(i), n = 0; n < r.length; n++)t["$feature/" + r[n]] = i[r[n]];
            else a = e, l = !1, (M(o = bi) ? l : s && o.indexOf === s ? -1 != o.indexOf(a) : (Ct(o, function(t) {
                if (l || (l = t === a)) return It;
            }), l)) || (t[e] = i);
            var o, a, l;
        }), t;
    }
    load() {
        if (!this.gi) {
            var t = this.it.K(this.fi);
            t && (this.props = Ot({}, t));
        }
    }
    save() {
        this.gi || this.it.Y(this.fi, this.props, this.mi, this.yi, this.bi, this.A.debug);
    }
    remove() {
        this.it.X(this.fi, !1), this.it.X(this.fi, !0);
    }
    clear() {
        this.remove(), this.props = {};
    }
    register_once(t, i, e) {
        if (I(t)) {
            C(i) && (i = "None"), this.mi = C(e) ? this.wi : e;
            var r = !1;
            if (Ct(t, (t, e)=>{
                this.props.hasOwnProperty(e) && this.props[e] !== i || (this.props[e] = t, r = !0);
            }), r) return this.save(), !0;
        }
        return !1;
    }
    register(t, i) {
        if (I(t)) {
            this.mi = C(i) ? this.wi : i;
            var e = !1;
            if (Ct(t, (i, r)=>{
                t.hasOwnProperty(r) && this.props[r] !== i && (this.props[r] = i, e = !0);
            }), e) return this.save(), !0;
        }
        return !1;
    }
    unregister(t) {
        t in this.props && (delete this.props[t], this.save());
    }
    update_campaign_params() {
        if (!this.ci) {
            var t = rs(this.A.custom_campaign_params, this.A.mask_personal_data_properties, this.A.custom_personal_data_properties);
            R(Dt(t)) || this.register(t), this.ci = !0;
        }
    }
    update_search_keyword() {
        var t;
        this.register((t = null == o ? void 0 : o.referrer) ? ns(t) : {});
    }
    update_referrer_info() {
        var t;
        this.register_once({
            $referrer: as(),
            $referring_domain: null != o && o.referrer && (null == (t = re(o.referrer)) ? void 0 : t.host) || "$direct"
        }, void 0);
    }
    set_initial_person_info() {
        this.props[fi] || this.props[pi] || this.register_once({
            [gi]: ls(this.A.mask_personal_data_properties, this.A.custom_personal_data_properties)
        }, void 0);
    }
    get_initial_props() {
        var t = {};
        Ct([
            pi,
            fi
        ], (i)=>{
            var e = this.props[i];
            e && Ct(e, function(i, e) {
                t["$initial_" + w(e)] = i;
            });
        });
        var i, e, r = this.props[gi];
        if (r) {
            var s = (i = us(r), e = {}, Ct(i, function(t, i) {
                e["$initial_" + w(i)] = t;
            }), e);
            Ot(t, s);
        }
        return t;
    }
    safe_merge(t) {
        return Ct(this.props, function(i, e) {
            e in t || (t[e] = i);
        }), t;
    }
    update_config(t, i, e) {
        if (this.wi = this.mi = t.cookie_expiration, this.set_disabled(t.disable_persistence || !!e), this.set_cross_subdomain(t.cross_subdomain_cookie), this.set_secure(t.secure_cookie), t.persistence !== i.persistence) {
            var r = this.pi(t), s = this.props;
            this.clear(), this.it = r, this.props = s, this.save();
        }
    }
    set_disabled(t) {
        this.gi = t, this.gi ? this.remove() : this.save();
    }
    set_cross_subdomain(t) {
        t !== this.yi && (this.yi = t, this.remove(), this.save());
    }
    set_secure(t) {
        t !== this.bi && (this.bi = t, this.remove(), this.save());
    }
    set_event_timer(t, i) {
        var e = this.props[Wt] || {};
        e[t] = i, this.props[Wt] = e, this.save();
    }
    remove_event_timer(t) {
        var i = (this.props[Wt] || {})[t];
        return C(i) || (delete this.props[Wt][t], this.save()), i;
    }
    get_property(t) {
        return this.props[t];
    }
    set_property(t, i) {
        this.props[t] = i, this.save();
    }
    constructor(t, i){
        this.A = t, this.props = {}, this.ci = !1, this.fi = ((t)=>{
            var i = "";
            return t.token && (i = t.token.replace(/\+/g, "PL").replace(/\//g, "SL").replace(/=/g, "EQ")), t.persistence_name ? "ph_" + t.persistence_name : "ph_" + i + "_posthog";
        })(t), this.it = this.pi(t), this.load(), t.debug && $t.info("Persistence loaded", t.persistence, g({}, this.props)), this.update_config(t, t, i), this.save();
    }
}
var kn = function(t) {
    return t.Button = "button", t.Tab = "tab", t.Selector = "selector", t;
}({}), Pn = function(t) {
    return t.TopLeft = "top_left", t.TopRight = "top_right", t.TopCenter = "top_center", t.MiddleLeft = "middle_left", t.MiddleRight = "middle_right", t.MiddleCenter = "middle_center", t.Left = "left", t.Center = "center", t.Right = "right", t.NextToTrigger = "next_to_trigger", t;
}({}), Tn = function(t) {
    return t.Popover = "popover", t.API = "api", t.Widget = "widget", t.ExternalSurvey = "external_survey", t;
}({}), In = function(t) {
    return t.Open = "open", t.MultipleChoice = "multiple_choice", t.SingleChoice = "single_choice", t.Rating = "rating", t.Link = "link", t;
}({}), Rn = function(t) {
    return t.NextQuestion = "next_question", t.End = "end", t.ResponseBased = "response_based", t.SpecificQuestion = "specific_question", t;
}({}), Cn = function(t) {
    return t.Once = "once", t.Recurring = "recurring", t.Always = "always", t;
}({}), On = function(t) {
    return t.SHOWN = "survey shown", t.DISMISSED = "survey dismissed", t.SENT = "survey sent", t;
}({}), Fn = function(t) {
    return t.SURVEY_ID = "$survey_id", t.SURVEY_NAME = "$survey_name", t.SURVEY_RESPONSE = "$survey_response", t.SURVEY_ITERATION = "$survey_iteration", t.SURVEY_ITERATION_START_DATE = "$survey_iteration_start_date", t.SURVEY_PARTIALLY_COMPLETED = "$survey_partially_completed", t.SURVEY_SUBMISSION_ID = "$survey_submission_id", t.SURVEY_QUESTIONS = "$survey_questions", t.SURVEY_COMPLETED = "$survey_completed", t;
}({}), Mn = function(t) {
    return t.Popover = "popover", t.Inline = "inline", t;
}({});
class An {
    on(t, i) {
        return this.Si[t] || (this.Si[t] = []), this.Si[t].push(i), ()=>{
            this.Si[t] = this.Si[t].filter((t)=>t !== i);
        };
    }
    emit(t, i) {
        for (var e of this.Si[t] || [])e(i);
        for (var r of this.Si["*"] || [])r(t, i);
    }
    constructor(){
        this.Si = {}, this.Si = {};
    }
}
class jn {
    init() {
        var t;
        if (!C(null == (t = this._instance) ? void 0 : t.Ri)) {
            var i;
            null == (i = this._instance) || i.Ri((t, i)=>{
                this.on(t, i);
            });
        }
    }
    register(t) {
        var i, e;
        if (!C(null == (i = this._instance) ? void 0 : i.Ri) && (t.forEach((t)=>{
            var i, e;
            null == (i = this.Ii) || i.add(t), null == (e = t.steps) || e.forEach((t)=>{
                var i;
                null == (i = this.Ti) || i.add((null == t ? void 0 : t.event) || "");
            });
        }), null != (e = this._instance) && e.autocapture)) {
            var r, s = new Set;
            t.forEach((t)=>{
                var i;
                null == (i = t.steps) || i.forEach((t)=>{
                    null != t && t.selector && s.add(null == t ? void 0 : t.selector);
                });
            }), null == (r = this._instance) || r.autocapture.setElementSelectors(s);
        }
    }
    on(t, i) {
        var e;
        null != i && 0 != t.length && (this.Ti.has(t) || this.Ti.has(null == i ? void 0 : i.event)) && this.Ii && (null == (e = this.Ii) ? void 0 : e.size) > 0 && this.Ii.forEach((t)=>{
            this.Ci(i, t) && this.xi.emit("actionCaptured", t.name);
        });
    }
    Oi(t) {
        this.onAction("actionCaptured", (i)=>t(i));
    }
    Ci(t, i) {
        if (null == (null == i ? void 0 : i.steps)) return !1;
        for (var e of i.steps)if (this.Ei(t, e)) return !0;
        return !1;
    }
    onAction(t, i) {
        return this.xi.on(t, i);
    }
    ki(t, i) {
        if (null != i && i.url) {
            var e, r = null == t || null == (e = t.properties) ? void 0 : e.$current_url;
            if (!r || "string" != typeof r) return !1;
            if (!jn.Fi(r, null == i ? void 0 : i.url, (null == i ? void 0 : i.url_matching) || "contains")) return !1;
        }
        return !0;
    }
    static Fi(i, e, r) {
        switch(r){
            case "regex":
                return !!t && ln(i, e);
            case "exact":
                return e === i;
            case "contains":
                var s = jn.Mi(e).replace(/_/g, ".").replace(/%/g, ".*");
                return ln(i, s);
            default:
                return !1;
        }
    }
    static Mi(t) {
        return t.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
    }
    Pi(t, i) {
        if ((null != i && i.href || null != i && i.tag_name || null != i && i.text) && !this.Ai(t).some((t)=>!(null != i && i.href && !jn.Fi(t.href || "", null == i ? void 0 : i.href, (null == i ? void 0 : i.href_matching) || "exact")) && (null == i || !i.tag_name || t.tag_name === (null == i ? void 0 : i.tag_name)) && !(null != i && i.text && !jn.Fi(t.text || "", null == i ? void 0 : i.text, (null == i ? void 0 : i.text_matching) || "exact") && !jn.Fi(t.$el_text || "", null == i ? void 0 : i.text, (null == i ? void 0 : i.text_matching) || "exact")))) return !1;
        if (null != i && i.selector) {
            var e, r = null == t || null == (e = t.properties) ? void 0 : e.$element_selectors;
            if (!r) return !1;
            if (!r.includes(null == i ? void 0 : i.selector)) return !1;
        }
        return !0;
    }
    Ai(t) {
        return null == (null == t ? void 0 : t.properties.$elements) ? [] : null == t ? void 0 : t.properties.$elements;
    }
    constructor(t){
        this.xi = new An, this.Ei = (t, i)=>this.$i(t, i) && this.ki(t, i) && this.Pi(t, i), this.$i = (t, i)=>null == i || !i.event || (null == t ? void 0 : t.event) === (null == i ? void 0 : i.event), this._instance = t, this.Ti = new Set, this.Ii = new Set;
    }
}
var Dn = kt("[Surveys]");
var Ln = "seenSurvey_", Nn = (t, i)=>{
    var e = "$survey_" + i + "/" + t.id;
    return t.current_iteration && t.current_iteration > 0 && (e = "$survey_" + i + "/" + t.id + "/" + t.current_iteration), e;
}, Un = (t)=>{
    var i = "" + Ln + t.id;
    return t.current_iteration && t.current_iteration > 0 && (i = "" + Ln + t.id + "_" + t.current_iteration), i;
}, zn = [
    Tn.Popover,
    Tn.Widget,
    Tn.API
], Hn = {
    ignoreConditions: !1,
    ignoreDelay: !1,
    displayType: Mn.Popover
};
class Bn {
    register(t) {
        var i;
        C(null == (i = this._instance) ? void 0 : i.Ri) || (this.Li(t), this.Ni(t));
    }
    Ni(t) {
        var i = t.filter((t)=>{
            var i, e;
            return (null == (i = t.conditions) ? void 0 : i.actions) && (null == (e = t.conditions) || null == (e = e.actions) || null == (e = e.values) ? void 0 : e.length) > 0;
        });
        if (0 !== i.length) {
            if (null == this.Ui) {
                this.Ui = new jn(this._instance), this.Ui.init();
                this.Ui.Oi((t)=>{
                    this.onAction(t);
                });
            }
            i.forEach((t)=>{
                var i, e, r, s, n;
                t.conditions && null != (i = t.conditions) && i.actions && null != (e = t.conditions) && null != (e = e.actions) && e.values && (null == (r = t.conditions) || null == (r = r.actions) || null == (r = r.values) ? void 0 : r.length) > 0 && (null == (s = this.Ui) || s.register(t.conditions.actions.values), null == (n = t.conditions) || null == (n = n.actions) || null == (n = n.values) || n.forEach((i)=>{
                    if (i && i.name) {
                        var e = this.Di.get(i.name);
                        e && e.push(t.id), this.Di.set(i.name, e || [
                            t.id
                        ]);
                    }
                }));
            });
        }
    }
    Li(t) {
        var i;
        if (0 !== t.filter((t)=>{
            var i, e;
            return (null == (i = t.conditions) ? void 0 : i.events) && (null == (e = t.conditions) || null == (e = e.events) || null == (e = e.values) ? void 0 : e.length) > 0;
        }).length) {
            null == (i = this._instance) || i.Ri((t, i)=>{
                this.onEvent(t, i);
            }), t.forEach((t)=>{
                var i;
                null == (i = t.conditions) || null == (i = i.events) || null == (i = i.values) || i.forEach((i)=>{
                    if (i && i.name) {
                        var e = this.ji.get(i.name);
                        e && e.push(t.id), this.ji.set(i.name, e || [
                            t.id
                        ]);
                    }
                });
            });
        }
    }
    onEvent(t, i) {
        var e, r, s = (null == (e = this._instance) || null == (e = e.persistence) ? void 0 : e.props[ui]) || [];
        if (On.SHOWN === t && i && s.length > 0) {
            var n;
            Dn.info("survey event matched, removing survey from activated surveys", {
                event: t,
                eventPayload: i,
                existingActivatedSurveys: s
            });
            var o = null == i || null == (n = i.properties) ? void 0 : n.$survey_id;
            if (o) {
                var a = s.indexOf(o);
                a >= 0 && (s.splice(a, 1), this.zi(s));
            }
        } else if (this.ji.has(t)) {
            Dn.info("survey event name matched", {
                event: t,
                eventPayload: i,
                surveys: this.ji.get(t)
            });
            var l = [];
            null == (r = this._instance) || r.getSurveys((i)=>{
                l = i.filter((i)=>{
                    var e;
                    return null == (e = this.ji.get(t)) ? void 0 : e.includes(i.id);
                });
            });
            var u = l.filter((e)=>{
                var r, s = null == (r = e.conditions) || null == (r = r.events) || null == (r = r.values) ? void 0 : r.find((i)=>i.name === t);
                return !!s && (!s.propertyFilters || Object.entries(s.propertyFilters).every((t)=>{
                    var e, [r, s] = t, n = null == i || null == (e = i.properties) ? void 0 : e[r];
                    if (C(n) || M(n)) return !1;
                    var o = [
                        String(n)
                    ], a = hn[s.operator];
                    return a ? a(s.values, o) : (Dn.warn("Unknown property comparison operator: " + s.operator), !1);
                }));
            });
            this.zi(s.concat(u.map((t)=>t.id) || []));
        }
    }
    onAction(t) {
        var i, e = (null == (i = this._instance) || null == (i = i.persistence) ? void 0 : i.props[ui]) || [];
        this.Di.has(t) && this.zi(e.concat(this.Di.get(t) || []));
    }
    zi(t) {
        var i;
        Dn.info("updating activated surveys", {
            activatedSurveys: t
        }), null == (i = this._instance) || null == (i = i.persistence) || i.register({
            [ui]: [
                ...new Set(t)
            ]
        });
    }
    getSurveys() {
        var t, i = null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.props[ui];
        return i || [];
    }
    getEventToSurveys() {
        return this.ji;
    }
    Hi() {
        return this.Ui;
    }
    constructor(t){
        this._instance = t, this.ji = new Map, this.Di = new Map;
    }
}
class qn {
    onRemoteConfig(t) {
        if (!this._instance.config.disable_surveys) {
            var i = t.surveys;
            if (A(i)) return Dn.warn("Flags not loaded yet. Not loading surveys.");
            var e = P(i);
            this.Bi = e ? i.length > 0 : i, Dn.info("flags response received, isSurveysEnabled: " + this.Bi), this.loadIfEnabled();
        }
    }
    reset() {
        localStorage.removeItem("lastSeenSurveyDate");
        for(var t = [], i = 0; i < localStorage.length; i++){
            var e = localStorage.key(i);
            (null != e && e.startsWith(Ln) || null != e && e.startsWith("inProgressSurvey_")) && t.push(e);
        }
        t.forEach((t)=>localStorage.removeItem(t));
    }
    loadIfEnabled() {
        if (!this._surveyManager) if (this.Wi) Dn.info("Already initializing surveys, skipping...");
        else if (this._instance.config.disable_surveys) Dn.info("Disabled. Not loading surveys.");
        else if (this._instance.config.cookieless_mode && this._instance.consent.isOptedOut()) Dn.info("Not loading surveys in cookieless mode without consent.");
        else {
            var t = null == v ? void 0 : v.__PosthogExtensions__;
            if (t) {
                if (!C(this.Bi) || this._instance.config.advanced_enable_surveys) {
                    var i = this.Bi || this._instance.config.advanced_enable_surveys;
                    this.Wi = !0;
                    try {
                        var e = t.generateSurveys;
                        if (e) return void this.Vi(e, i);
                        var r = t.loadExternalDependency;
                        if (!r) return void this.Ji("PostHog loadExternalDependency extension not found.");
                        r(this._instance, "surveys", (e)=>{
                            e || !t.generateSurveys ? this.Ji("Could not load surveys script", e) : this.Vi(t.generateSurveys, i);
                        });
                    } catch (t) {
                        throw this.Ji("Error initializing surveys", t), t;
                    } finally{
                        this.Wi = !1;
                    }
                }
            } else Dn.error("PostHog Extensions not found.");
        }
    }
    Vi(t, i) {
        this._surveyManager = t(this._instance, i), this._surveyEventReceiver = new Bn(this._instance), Dn.info("Surveys loaded successfully"), this.Ki({
            isLoaded: !0
        });
    }
    Ji(t, i) {
        Dn.error(t, i), this.Ki({
            isLoaded: !1,
            error: t
        });
    }
    onSurveysLoaded(t) {
        return this.Gi.push(t), this._surveyManager && this.Ki({
            isLoaded: !0
        }), ()=>{
            this.Gi = this.Gi.filter((i)=>i !== t);
        };
    }
    getSurveys(t, i) {
        if (void 0 === i && (i = !1), this._instance.config.disable_surveys) return Dn.info("Disabled. Not loading surveys."), t([]);
        var e = this._instance.get_property(li);
        if (e && !i) return t(e, {
            isLoaded: !0
        });
        if (this.qi) return t([], {
            isLoaded: !1,
            error: "Surveys are already being loaded"
        });
        try {
            this.qi = !0, this._instance.ui({
                url: this._instance.requestRouter.endpointFor("api", "/api/surveys/?token=" + this._instance.config.token),
                method: "GET",
                timeout: this._instance.config.surveys_request_timeout_ms,
                callback: (i)=>{
                    var e;
                    this.qi = !1;
                    var r = i.statusCode;
                    if (200 !== r || !i.json) {
                        var s = "Surveys API could not be loaded, status: " + r;
                        return Dn.error(s), t([], {
                            isLoaded: !1,
                            error: s
                        });
                    }
                    var n, o = i.json.surveys || [], a = o.filter((t)=>(function(t) {
                            return !(!t.start_date || t.end_date);
                        })(t) && (function(t) {
                            var i;
                            return !(null == (i = t.conditions) || null == (i = i.events) || null == (i = i.values) || !i.length);
                        }(t) || function(t) {
                            var i;
                            return !(null == (i = t.conditions) || null == (i = i.actions) || null == (i = i.values) || !i.length);
                        }(t)));
                    a.length > 0 && (null == (n = this._surveyEventReceiver) || n.register(a));
                    return null == (e = this._instance.persistence) || e.register({
                        [li]: o
                    }), t(o, {
                        isLoaded: !0
                    });
                }
            });
        } catch (t) {
            throw this.qi = !1, t;
        }
    }
    Ki(t) {
        for (var i of this.Gi)try {
            if (!t.isLoaded) return i([], t);
            this.getSurveys(i);
        } catch (t) {
            Dn.error("Error in survey callback", t);
        }
    }
    getActiveMatchingSurveys(t, i) {
        if (void 0 === i && (i = !1), !A(this._surveyManager)) return this._surveyManager.getActiveMatchingSurveys(t, i);
        Dn.warn("init was not called");
    }
    Yi(t) {
        var i = null;
        return this.getSurveys((e)=>{
            var r;
            i = null !== (r = e.find((i)=>i.id === t)) && void 0 !== r ? r : null;
        }), i;
    }
    Xi(t) {
        if (A(this._surveyManager)) return {
            eligible: !1,
            reason: "SDK is not enabled or survey functionality is not yet loaded"
        };
        var i = "string" == typeof t ? this.Yi(t) : t;
        return i ? this._surveyManager.checkSurveyEligibility(i) : {
            eligible: !1,
            reason: "Survey not found"
        };
    }
    canRenderSurvey(t) {
        if (A(this._surveyManager)) return Dn.warn("init was not called"), {
            visible: !1,
            disabledReason: "SDK is not enabled or survey functionality is not yet loaded"
        };
        var i = this.Xi(t);
        return {
            visible: i.eligible,
            disabledReason: i.reason
        };
    }
    canRenderSurveyAsync(t, i) {
        return A(this._surveyManager) ? (Dn.warn("init was not called"), Promise.resolve({
            visible: !1,
            disabledReason: "SDK is not enabled or survey functionality is not yet loaded"
        })) : new Promise((e)=>{
            this.getSurveys((i)=>{
                var r, s = null !== (r = i.find((i)=>i.id === t)) && void 0 !== r ? r : null;
                if (s) {
                    var n = this.Xi(s);
                    e({
                        visible: n.eligible,
                        disabledReason: n.reason
                    });
                } else e({
                    visible: !1,
                    disabledReason: "Survey not found"
                });
            }, i);
        });
    }
    renderSurvey(t, i) {
        var e;
        if (A(this._surveyManager)) Dn.warn("init was not called");
        else {
            var r = "string" == typeof t ? this.Yi(t) : t;
            if (null != r && r.id) if (zn.includes(r.type)) {
                var s = null == o ? void 0 : o.querySelector(i);
                if (s) return null != (e = r.appearance) && e.surveyPopupDelaySeconds ? (Dn.info("Rendering survey " + r.id + " with delay of " + r.appearance.surveyPopupDelaySeconds + " seconds"), void setTimeout(()=>{
                    var t, i;
                    Dn.info("Rendering survey " + r.id + " with delay of " + (null == (t = r.appearance) ? void 0 : t.surveyPopupDelaySeconds) + " seconds"), null == (i = this._surveyManager) || i.renderSurvey(r, s), Dn.info("Survey " + r.id + " rendered");
                }, 1e3 * r.appearance.surveyPopupDelaySeconds)) : void this._surveyManager.renderSurvey(r, s);
                Dn.warn("Survey element not found");
            } else Dn.warn("Surveys of type " + r.type + " cannot be rendered in the app");
            else Dn.warn("Survey not found");
        }
    }
    displaySurvey(t, i) {
        var e;
        if (A(this._surveyManager)) Dn.warn("init was not called");
        else {
            var r = this.Yi(t);
            if (r) {
                var s = r;
                if (null != (e = r.appearance) && e.surveyPopupDelaySeconds && i.ignoreDelay && (s = g({}, r, {
                    appearance: g({}, r.appearance, {
                        surveyPopupDelaySeconds: 0
                    })
                })), !1 === i.ignoreConditions) {
                    var n = this.canRenderSurvey(r);
                    if (!n.visible) return void Dn.warn("Survey is not eligible to be displayed: ", n.disabledReason);
                }
                i.displayType !== Mn.Inline ? this._surveyManager.handlePopoverSurvey(s) : this.renderSurvey(s, i.selector);
            } else Dn.warn("Survey not found");
        }
    }
    constructor(t){
        this.Bi = void 0, this._surveyManager = null, this.qi = !1, this.Wi = !1, this.Gi = [], this._instance = t, this._surveyEventReceiver = null;
    }
}
var Wn = kt("[RateLimiter]");
class Gn {
    clientRateLimitContext(t) {
        var i, e, r;
        void 0 === t && (t = !1);
        var s = (new Date).getTime(), n = null !== (i = null == (e = this.instance.persistence) ? void 0 : e.get_property(ci)) && void 0 !== i ? i : {
            tokens: this.captureEventsBurstLimit,
            last: s
        };
        n.tokens += (s - n.last) / 1e3 * this.captureEventsPerSecond, n.last = s, n.tokens > this.captureEventsBurstLimit && (n.tokens = this.captureEventsBurstLimit);
        var o = n.tokens < 1;
        return o || t || (n.tokens = Math.max(0, n.tokens - 1)), !o || this.lastEventRateLimited || t || this.instance.capture("$$client_ingestion_warning", {
            $$client_ingestion_warning_message: "posthog-js client rate limited. Config is set to " + this.captureEventsPerSecond + " events per second and " + this.captureEventsBurstLimit + " events burst limit."
        }, {
            skip_client_rate_limiting: !0
        }), this.lastEventRateLimited = o, null == (r = this.instance.persistence) || r.set_property(ci, n), {
            isRateLimited: o,
            remainingTokens: n.tokens
        };
    }
    isServerRateLimited(t) {
        var i = this.serverLimits[t || "events"] || !1;
        return !1 !== i && (new Date).getTime() < i;
    }
    constructor(t){
        var i, e;
        this.serverLimits = {}, this.lastEventRateLimited = !1, this.checkForLimiting = (t)=>{
            var i = t.text;
            if (i && i.length) try {
                (JSON.parse(i).quota_limited || []).forEach((t)=>{
                    Wn.info((t || "events") + " is quota limited."), this.serverLimits[t] = (new Date).getTime() + 6e4;
                });
            } catch (t) {
                return void Wn.warn('could not rate limit - continuing. Error: "' + (null == t ? void 0 : t.message) + '"', {
                    text: i
                });
            }
        }, this.instance = t, this.captureEventsPerSecond = (null == (i = t.config.rate_limiting) ? void 0 : i.events_per_second) || 10, this.captureEventsBurstLimit = Math.max((null == (e = t.config.rate_limiting) ? void 0 : e.events_burst_limit) || 10 * this.captureEventsPerSecond, this.captureEventsPerSecond), this.lastEventRateLimited = this.clientRateLimitContext(!0).isRateLimited;
    }
}
var Vn = kt("[RemoteConfig]");
class Jn {
    get remoteConfig() {
        var t;
        return null == (t = v._POSTHOG_REMOTE_CONFIG) || null == (t = t[this._instance.config.token]) ? void 0 : t.config;
    }
    Qi(t) {
        var i, e;
        null != (i = v.__PosthogExtensions__) && i.loadExternalDependency ? null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, "remote-config", ()=>t(this.remoteConfig)) : (Vn.error("PostHog Extensions not found. Cannot load remote config."), t());
    }
    Zi(t) {
        this._instance.ui({
            method: "GET",
            url: this._instance.requestRouter.endpointFor("assets", "/array/" + this._instance.config.token + "/config"),
            callback: (i)=>{
                t(i.json);
            }
        });
    }
    load() {
        try {
            if (this.remoteConfig) return Vn.info("Using preloaded remote config", this.remoteConfig), void this.hi(this.remoteConfig);
            if (this._instance.L()) return void Vn.warn("Remote config is disabled. Falling back to local config.");
            this.Qi((t)=>{
                if (!t) return Vn.info("No config found after loading remote JS config. Falling back to JSON."), void this.Zi((t)=>{
                    this.hi(t);
                });
                this.hi(t);
            });
        } catch (t) {
            Vn.error("Error loading remote config", t);
        }
    }
    hi(t) {
        t ? this._instance.config.__preview_remote_config ? (this._instance.hi(t), !1 !== t.hasFeatureFlags && this._instance.featureFlags.ensureFlagsLoaded()) : Vn.info("__preview_remote_config is disabled. Logging config instead", t) : Vn.error("Failed to fetch remote config from PostHog.");
    }
    constructor(t){
        this._instance = t;
    }
}
var Kn = 3e3;
class Yn {
    enqueue(t) {
        this.ie.push(t), this.se || this.ne();
    }
    unload() {
        this.oe();
        var t = this.ie.length > 0 ? this.ae() : {}, i = Object.values(t);
        [
            ...i.filter((t)=>0 === t.url.indexOf("/e")),
            ...i.filter((t)=>0 !== t.url.indexOf("/e"))
        ].map((t)=>{
            this.re(g({}, t, {
                transport: "sendBeacon"
            }));
        });
    }
    enable() {
        this.te = !1, this.ne();
    }
    ne() {
        var t = this;
        this.te || (this.se = setTimeout(()=>{
            if (this.oe(), this.ie.length > 0) {
                var i = this.ae(), e = function() {
                    var e = i[r], s = (new Date).getTime();
                    e.data && P(e.data) && Ct(e.data, (t)=>{
                        t.offset = Math.abs(t.timestamp - s), delete t.timestamp;
                    }), t.re(e);
                };
                for(var r in i)e();
            }
        }, this.ee));
    }
    oe() {
        clearTimeout(this.se), this.se = void 0;
    }
    ae() {
        var t = {};
        return Ct(this.ie, (i)=>{
            var e, r = i, s = (r ? r.batchKey : null) || r.url;
            C(t[s]) && (t[s] = g({}, r, {
                data: []
            })), null == (e = t[s].data) || e.push(r.data);
        }), this.ie = [], t;
    }
    constructor(t, i){
        this.te = !0, this.ie = [], this.ee = G((null == i ? void 0 : i.flush_interval_ms) || Kn, 250, 5e3, $t.createLogger("flush interval"), Kn), this.re = t;
    }
}
var Xn = [
    "retriesPerformedSoFar"
];
class Qn {
    get length() {
        return this.ie.length;
    }
    retriableRequest(t) {
        var { retriesPerformedSoFar: i } = t, e = _(t, Xn);
        j(i) && i > 0 && (e.url = sn(e.url, {
            retry_count: i
        })), this._instance.ui(g({}, e, {
            callback: (t)=>{
                200 !== t.statusCode && (t.statusCode < 400 || t.statusCode >= 500) && (null != i ? i : 0) < 10 ? this.de(g({
                    retriesPerformedSoFar: i
                }, e)) : null == e.callback || e.callback(t);
            }
        }));
    }
    de(t) {
        var i = t.retriesPerformedSoFar || 0;
        t.retriesPerformedSoFar = i + 1;
        var e = function(t) {
            var i = 3e3 * Math.pow(2, t), e = i / 2, r = Math.min(18e5, i), s = (Math.random() - .5) * (r - e);
            return Math.ceil(r + s);
        }(i), r = Date.now() + e;
        this.ie.push({
            retryAt: r,
            requestOptions: t
        });
        var s = "Enqueued failed request for retry in " + e;
        navigator.onLine || (s += " (Browser is offline)"), $t.warn(s), this.le || (this.le = !0, this.ve());
    }
    ve() {
        this.ce && clearTimeout(this.ce), this.ce = setTimeout(()=>{
            this.he && this.ie.length > 0 && this.jt(), this.ve();
        }, this.ue);
    }
    jt() {
        var t = Date.now(), i = [], e = this.ie.filter((e)=>e.retryAt < t || (i.push(e), !1));
        if (this.ie = i, e.length > 0) for (var { requestOptions: r } of e)this.retriableRequest(r);
    }
    unload() {
        for (var { requestOptions: t } of (this.ce && (clearTimeout(this.ce), this.ce = void 0), this.ie))try {
            this._instance.ui(g({}, t, {
                transport: "sendBeacon"
            }));
        } catch (t) {
            $t.error(t);
        }
        this.ie = [];
    }
    constructor(i){
        this.le = !1, this.ue = 3e3, this.ie = [], this._instance = i, this.ie = [], this.he = !0, !C(t) && "onLine" in t.navigator && (this.he = t.navigator.onLine, Ht(t, "online", ()=>{
            this.he = !0, this.jt();
        }), Ht(t, "offline", ()=>{
            this.he = !1;
        }));
    }
}
class Zn {
    getContext() {
        return this.pe;
    }
    resetContext() {
        var t = this.pe;
        return setTimeout(this.fe, 0), t;
    }
    startMeasuringScrollPosition() {
        Ht(t, "scroll", this.fe, {
            capture: !0
        }), Ht(t, "scrollend", this.fe, {
            capture: !0
        }), Ht(t, "resize", this.fe);
    }
    scrollElement() {
        if (!this._instance.config.scroll_root_selector) return null == t ? void 0 : t.document.documentElement;
        var i = P(this._instance.config.scroll_root_selector) ? this._instance.config.scroll_root_selector : [
            this._instance.config.scroll_root_selector
        ];
        for (var e of i){
            var r = null == t ? void 0 : t.document.querySelector(e);
            if (r) return r;
        }
    }
    scrollY() {
        if (this._instance.config.scroll_root_selector) {
            var i = this.scrollElement();
            return i && i.scrollTop || 0;
        }
        return t && (t.scrollY || t.pageYOffset || t.document.documentElement.scrollTop) || 0;
    }
    scrollX() {
        if (this._instance.config.scroll_root_selector) {
            var i = this.scrollElement();
            return i && i.scrollLeft || 0;
        }
        return t && (t.scrollX || t.pageXOffset || t.document.documentElement.scrollLeft) || 0;
    }
    constructor(t){
        this.fe = ()=>{
            var t, i, e, r;
            this.pe || (this.pe = {});
            var s = this.scrollElement(), n = this.scrollY(), o = s ? Math.max(0, s.scrollHeight - s.clientHeight) : 0, a = n + ((null == s ? void 0 : s.clientHeight) || 0), l = (null == s ? void 0 : s.scrollHeight) || 0;
            this.pe.lastScrollY = Math.ceil(n), this.pe.maxScrollY = Math.max(n, null !== (t = this.pe.maxScrollY) && void 0 !== t ? t : 0), this.pe.maxScrollHeight = Math.max(o, null !== (i = this.pe.maxScrollHeight) && void 0 !== i ? i : 0), this.pe.lastContentY = a, this.pe.maxContentY = Math.max(a, null !== (e = this.pe.maxContentY) && void 0 !== e ? e : 0), this.pe.maxContentHeight = Math.max(l, null !== (r = this.pe.maxContentHeight) && void 0 !== r ? r : 0);
        }, this._instance = t;
    }
}
var to = (t)=>ls(null == t ? void 0 : t.config.mask_personal_data_properties, null == t ? void 0 : t.config.custom_personal_data_properties);
class io {
    _e() {
        return this.ye.props[vi];
    }
    getSetOnceProps() {
        var t, i = null == (t = this._e()) ? void 0 : t.props;
        return i ? "r" in i ? us(i) : {
            $referring_domain: i.referringDomain,
            $pathname: i.initialPathName,
            utm_source: i.utm_source,
            utm_campaign: i.utm_campaign,
            utm_medium: i.utm_medium,
            utm_content: i.utm_content,
            utm_term: i.utm_term
        } : {};
    }
    getSessionProps() {
        var t = {};
        return Ct(Dt(this.getSetOnceProps()), (i, e)=>{
            "$current_url" === e && (e = "url"), t["$session_entry_" + w(e)] = i;
        }), t;
    }
    constructor(t, i, e, r){
        this.ge = (t)=>{
            var i = this._e();
            if (!i || i.sessionId !== t) {
                var e = {
                    sessionId: t,
                    props: this.me(this._instance)
                };
                this.ye.register({
                    [vi]: e
                });
            }
        }, this._instance = t, this.be = i, this.ye = e, this.me = r || to, this.be.onSessionId(this.ge);
    }
}
var eo = kt("[SessionId]");
class ro {
    on(t, i) {
        return this.we.on(t, i);
    }
    get sessionTimeoutMs() {
        return this._sessionTimeoutMs;
    }
    onSessionId(t) {
        return C(this.Se) && (this.Se = []), this.Se.push(t), this.ke && t(this.ke, this.$e), ()=>{
            this.Se = this.Se.filter((i)=>i !== t);
        };
    }
    Oe() {
        return "memory" !== this.A.persistence && !this.ye.gi && Fe.G();
    }
    Ae(t) {
        t !== this.$e && (this.$e = t, this.Oe() && Fe.Y(this.Re, t));
    }
    je() {
        return this.$e ? this.$e : this.Oe() ? Fe.K(this.Re) : null;
    }
    Fe(t, i, e) {
        t === this.ke && i === this._sessionActivityTimestamp && e === this._sessionStartTimestamp || (this._sessionStartTimestamp = e, this._sessionActivityTimestamp = i, this.ke = t, this.ye.register({
            [ii]: [
                i,
                t,
                e
            ]
        }));
    }
    De() {
        if (this.ke && this._sessionActivityTimestamp && this._sessionStartTimestamp) return [
            this._sessionActivityTimestamp,
            this.ke,
            this._sessionStartTimestamp
        ];
        var t = this.ye.props[ii];
        return P(t) && 2 === t.length && t.push(t[0]), t || [
            0,
            null,
            0
        ];
    }
    resetSessionId() {
        this.Fe(null, null, null);
    }
    destroy() {
        clearTimeout(this.Le), this.Le = void 0, this.xe && t && (t.removeEventListener("beforeunload", this.xe, {
            capture: !1
        }), this.xe = void 0), this.Se = [];
    }
    Me() {
        this.xe = ()=>{
            this.Oe() && Fe.X(this.Ce);
        }, Ht(t, "beforeunload", this.xe, {
            capture: !1
        });
    }
    checkAndGetSessionAndWindowId(t, i) {
        if (void 0 === t && (t = !1), void 0 === i && (i = null), "always" === this.A.cookieless_mode) throw new Error('checkAndGetSessionAndWindowId should not be called with cookieless_mode="always"');
        var e = i || (new Date).getTime(), [r, s, n] = this.De(), o = this.je(), a = j(n) && n > 0 && Math.abs(e - n) > 864e5, l = !1, u = !s, h = !t && this.Ee(e, r);
        u || h || a ? (s = this.Pe(), o = this.Te(), eo.info("new session ID generated", {
            sessionId: s,
            windowId: o,
            changeReason: {
                noSessionId: u,
                activityTimeout: h,
                sessionPastMaximumLength: a
            }
        }), n = e, l = !0) : o || (o = this.Te(), l = !0);
        var d = 0 === r || !t || a ? e : r, v = 0 === n ? (new Date).getTime() : n;
        return this.Ae(o), this.Fe(s, d, v), t || this.Ie(), l && this.Se.forEach((t)=>t(s, o, l ? {
                noSessionId: u,
                activityTimeout: h,
                sessionPastMaximumLength: a
            } : void 0)), {
            sessionId: s,
            windowId: o,
            sessionStartTimestamp: v,
            changeReason: l ? {
                noSessionId: u,
                activityTimeout: h,
                sessionPastMaximumLength: a
            } : void 0,
            lastActivityTimestamp: r
        };
    }
    Ie() {
        clearTimeout(this.Le), this.Le = setTimeout(()=>{
            var [t] = this.De();
            if (this.Ee((new Date).getTime(), t)) {
                var i = this.ke;
                this.resetSessionId(), this.we.emit("forcedIdleReset", {
                    idleSessionId: i
                });
            }
        }, 1.1 * this.sessionTimeoutMs);
    }
    constructor(t, i, e){
        var r;
        if (this.Se = [], this.xe = void 0, this.we = new An, this.Ee = (t, i)=>Math.abs(t - i) > this.sessionTimeoutMs, !t.persistence) throw new Error("SessionIdManager requires a PostHogPersistence instance");
        if ("always" === t.config.cookieless_mode) throw new Error('SessionIdManager cannot be used with cookieless_mode="always"');
        this.A = t.config, this.ye = t.persistence, this.$e = void 0, this.ke = void 0, this._sessionStartTimestamp = null, this._sessionActivityTimestamp = null, this.Pe = i || be, this.Te = e || be;
        var s = this.A.persistence_name || this.A.token, n = this.A.session_idle_timeout_seconds || 1800;
        if (this._sessionTimeoutMs = 1e3 * G(n, 60, 36e3, eo.createLogger("session_idle_timeout_seconds"), 1800), t.register({
            $configured_session_timeout_ms: this._sessionTimeoutMs
        }), this.Ie(), this.Re = "ph_" + s + "_window_id", this.Ce = "ph_" + s + "_primary_window_exists", this.Oe()) {
            var o = Fe.K(this.Re), a = Fe.K(this.Ce);
            o && !a ? this.$e = o : Fe.X(this.Re), Fe.Y(this.Ce, !0);
        }
        if (null != (r = this.A.bootstrap) && r.sessionID) try {
            var l = ((t)=>{
                var i = t.replace(/-/g, "");
                if (32 !== i.length) throw new Error("Not a valid UUID");
                if ("7" !== i[12]) throw new Error("Not a UUIDv7");
                return parseInt(i.substring(0, 12), 16);
            })(this.A.bootstrap.sessionID);
            this.Fe(this.A.bootstrap.sessionID, (new Date).getTime(), l);
        } catch (t) {
            eo.error("Invalid sessionID in bootstrap", t);
        }
        this.Me();
    }
}
var so = [
    "$set_once",
    "$set"
], no = kt("[SiteApps]");
class oo {
    get isEnabled() {
        return !!this._instance.config.opt_in_site_apps;
    }
    Ue(t, i) {
        if (i) {
            var e = this.globalsForEvent(i);
            this.Ne.push(e), this.Ne.length > 1e3 && (this.Ne = this.Ne.slice(10));
        }
    }
    get siteAppLoaders() {
        var t;
        return null == (t = v._POSTHOG_REMOTE_CONFIG) || null == (t = t[this._instance.config.token]) ? void 0 : t.siteApps;
    }
    init() {
        if (this.isEnabled) {
            var t = this._instance.Ri(this.Ue.bind(this));
            this.ze = ()=>{
                t(), this.Ne = [], this.ze = void 0;
            };
        }
    }
    globalsForEvent(t) {
        var i, e, r, s, n, o, a;
        if (!t) throw new Error("Event payload is required");
        var l = {}, u = this._instance.get_property("$groups") || [], h = this._instance.get_property("$stored_group_properties") || {};
        for (var [d, v] of Object.entries(h))l[d] = {
            id: u[d],
            type: d,
            properties: v
        };
        var { $set_once: c, $set: f } = t;
        return {
            event: g({}, _(t, so), {
                properties: g({}, t.properties, f ? {
                    $set: g({}, null !== (i = null == (e = t.properties) ? void 0 : e.$set) && void 0 !== i ? i : {}, f)
                } : {}, c ? {
                    $set_once: g({}, null !== (r = null == (s = t.properties) ? void 0 : s.$set_once) && void 0 !== r ? r : {}, c)
                } : {}),
                elements_chain: null !== (n = null == (o = t.properties) ? void 0 : o.$elements_chain) && void 0 !== n ? n : "",
                distinct_id: null == (a = t.properties) ? void 0 : a.distinct_id
            }),
            person: {
                properties: this._instance.get_property("$stored_person_properties")
            },
            groups: l
        };
    }
    setupSiteApp(t) {
        var i = this.apps[t.id], e = ()=>{
            var e;
            (!i.errored && this.Ne.length && (no.info("Processing " + this.Ne.length + " events for site app with id " + t.id), this.Ne.forEach((t)=>null == i.processEvent ? void 0 : i.processEvent(t)), i.processedBuffer = !0), Object.values(this.apps).every((t)=>t.processedBuffer || t.errored)) && (null == (e = this.ze) || e.call(this));
        }, r = !1, s = (s)=>{
            i.errored = !s, i.loaded = !0, no.info("Site app with id " + t.id + " " + (s ? "loaded" : "errored")), r && e();
        };
        try {
            var { processEvent: n } = t.init({
                posthog: this._instance,
                callback: (t)=>{
                    s(t);
                }
            });
            n && (i.processEvent = n), r = !0;
        } catch (i) {
            no.error("Error while initializing PostHog app with config id " + t.id, i), s(!1);
        }
        if (r && i.loaded) try {
            e();
        } catch (e) {
            no.error("Error while processing buffered events PostHog app with config id " + t.id, e), i.errored = !0;
        }
    }
    He() {
        var t = this.siteAppLoaders || [];
        for (var i of t)this.apps[i.id] = {
            id: i.id,
            loaded: !1,
            errored: !1,
            processedBuffer: !1
        };
        for (var e of t)this.setupSiteApp(e);
    }
    Be(t) {
        if (0 !== Object.keys(this.apps).length) {
            var i = this.globalsForEvent(t);
            for (var e of Object.values(this.apps))try {
                null == e.processEvent || e.processEvent(i);
            } catch (i) {
                no.error("Error while processing event " + t.event + " for site app " + e.id, i);
            }
        }
    }
    onRemoteConfig(t) {
        var i, e, r, s = this;
        if (null != (i = this.siteAppLoaders) && i.length) return this.isEnabled ? (this.He(), void this._instance.on("eventCaptured", (t)=>this.Be(t))) : void no.error('PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.');
        if (null == (e = this.ze) || e.call(this), null != (r = t.siteApps) && r.length) if (this.isEnabled) {
            var n = function(t) {
                var i;
                v["__$$ph_site_app_" + t] = s._instance, null == (i = v.__PosthogExtensions__) || null == i.loadSiteApp || i.loadSiteApp(s._instance, a, (i)=>{
                    if (i) return no.error("Error while initializing PostHog app with config id " + t, i);
                });
            };
            for (var { id: o, url: a } of t.siteApps)n(o);
        } else no.error('PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.');
    }
    constructor(t){
        this._instance = t, this.Ne = [], this.apps = {};
    }
}
var ao = [
    "amazonbot",
    "amazonproductbot",
    "app.hypefactors.com",
    "applebot",
    "archive.org_bot",
    "awariobot",
    "backlinksextendedbot",
    "baiduspider",
    "bingbot",
    "bingpreview",
    "chrome-lighthouse",
    "dataforseobot",
    "deepscan",
    "duckduckbot",
    "facebookexternal",
    "facebookcatalog",
    "http://yandex.com/bots",
    "hubspot",
    "ia_archiver",
    "leikibot",
    "linkedinbot",
    "meta-externalagent",
    "mj12bot",
    "msnbot",
    "nessus",
    "petalbot",
    "pinterest",
    "prerender",
    "rogerbot",
    "screaming frog",
    "sebot-wa",
    "sitebulb",
    "slackbot",
    "slurp",
    "trendictionbot",
    "turnitin",
    "twitterbot",
    "vercel-screenshot",
    "vercelbot",
    "yahoo! slurp",
    "yandexbot",
    "zoombot",
    "bot.htm",
    "bot.php",
    "(bot;",
    "bot/",
    "crawler",
    "ahrefsbot",
    "ahrefssiteaudit",
    "semrushbot",
    "siteauditbot",
    "splitsignalbot",
    "gptbot",
    "oai-searchbot",
    "chatgpt-user",
    "perplexitybot",
    "better uptime bot",
    "sentryuptimebot",
    "uptimerobot",
    "headlesschrome",
    "cypress",
    "google-hoteladsverifier",
    "adsbot-google",
    "apis-google",
    "duplexweb-google",
    "feedfetcher-google",
    "google favicon",
    "google web preview",
    "google-read-aloud",
    "googlebot",
    "googleother",
    "google-cloudvertexbot",
    "googleweblight",
    "mediapartners-google",
    "storebot-google",
    "google-inspectiontool",
    "bytespider"
], lo = function(t, i) {
    if (!t) return !1;
    var e = t.toLowerCase();
    return ao.concat(i || []).some((t)=>{
        var i = t.toLowerCase();
        return -1 !== e.indexOf(i);
    });
}, uo = function(t, i) {
    if (!t) return !1;
    var e = t.userAgent;
    if (e && lo(e, i)) return !0;
    try {
        var r = null == t ? void 0 : t.userAgentData;
        if (null != r && r.brands && r.brands.some((t)=>lo(null == t ? void 0 : t.brand, i))) return !0;
    } catch (t) {}
    return !!t.webdriver;
}, ho = function(t) {
    return t.US = "us", t.EU = "eu", t.CUSTOM = "custom", t;
}({}), vo = "i.posthog.com";
class co {
    get apiHost() {
        var t = this.instance.config.api_host.trim().replace(/\/$/, "");
        return "https://app.posthog.com" === t ? "https://us.i.posthog.com" : t;
    }
    get uiHost() {
        var t, i = null == (t = this.instance.config.ui_host) ? void 0 : t.replace(/\/$/, "");
        return i || (i = this.apiHost.replace("." + vo, ".posthog.com")), "https://app.posthog.com" === i ? "https://us.posthog.com" : i;
    }
    get region() {
        return this.qe[this.apiHost] || (/https:\/\/(app|us|us-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? this.qe[this.apiHost] = ho.US : /https:\/\/(eu|eu-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? this.qe[this.apiHost] = ho.EU : this.qe[this.apiHost] = ho.CUSTOM), this.qe[this.apiHost];
    }
    endpointFor(t, i) {
        if (void 0 === i && (i = ""), i && (i = "/" === i[0] ? i : "/" + i), "ui" === t) return this.uiHost + i;
        if (this.region === ho.CUSTOM) return this.apiHost + i;
        var e = vo + i;
        switch(t){
            case "assets":
                return "https://" + this.region + "-assets." + e;
            case "api":
                return "https://" + this.region + "." + e;
        }
    }
    constructor(t){
        this.qe = {}, this.instance = t;
    }
}
var fo = {
    icontains: (i, e)=>!!t && e.href.toLowerCase().indexOf(i.toLowerCase()) > -1,
    not_icontains: (i, e)=>!!t && -1 === e.href.toLowerCase().indexOf(i.toLowerCase()),
    regex: (i, e)=>!!t && ln(e.href, i),
    not_regex: (i, e)=>!!t && !ln(e.href, i),
    exact: (t, i)=>i.href === t,
    is_not: (t, i)=>i.href !== t
};
class po {
    onFeatureFlags(t) {
        if (this._is_bot()) po.We("Refusing to render web experiment since the viewer is a likely bot");
        else if (!this._instance.config.disable_web_experiments) {
            if (A(this.Ge)) return this.Ge = new Map, this.loadIfEnabled(), void this.previewWebExperiment();
            po.We("applying feature flags", t), t.forEach((t)=>{
                var i;
                if (this.Ge && null != (i = this.Ge) && i.has(t)) {
                    var e, r = this._instance.getFeatureFlag(t), s = null == (e = this.Ge) ? void 0 : e.get(t);
                    r && null != s && s.variants[r] && this.Ve(s.name, r, s.variants[r].transforms);
                }
            });
        }
    }
    previewWebExperiment() {
        var t = po.getWindowLocation();
        if (null != t && t.search) {
            var i = ne(null == t ? void 0 : t.search, "__experiment_id"), e = ne(null == t ? void 0 : t.search, "__experiment_variant");
            i && e && (po.We("previewing web experiments " + i + " && " + e), this.getWebExperiments((t)=>{
                this.Ke(parseInt(i), e, t);
            }, !1, !0));
        }
    }
    loadIfEnabled() {
        this._instance.config.disable_web_experiments || this.getWebExperimentsAndEvaluateDisplayLogic();
    }
    getWebExperiments(t, i, e) {
        if (this._instance.config.disable_web_experiments && !e) return t([]);
        var r = this._instance.get_property("$web_experiments");
        if (r && !i) return t(r);
        this._instance.ui({
            url: this._instance.requestRouter.endpointFor("api", "/api/web_experiments/?token=" + this._instance.config.token),
            method: "GET",
            callback: (i)=>{
                if (200 !== i.statusCode || !i.json) return t([]);
                var e = i.json.experiments || [];
                return t(e);
            }
        });
    }
    Ke(t, i, e) {
        var r = e.filter((i)=>i.id === t);
        r && r.length > 0 && (po.We("Previewing web experiment [" + r[0].name + "] with variant [" + i + "]"), this.Ve(r[0].name, i, r[0].variants[i].transforms));
    }
    static Je(t) {
        return !A(t.conditions) && po.Ye(t) && po.Xe(t);
    }
    static Ye(t) {
        var i;
        if (A(t.conditions) || A(null == (i = t.conditions) ? void 0 : i.url)) return !0;
        var e, r, s, n = po.getWindowLocation();
        return !!n && (null == (e = t.conditions) || !e.url || fo[null !== (r = null == (s = t.conditions) ? void 0 : s.urlMatchType) && void 0 !== r ? r : "icontains"](t.conditions.url, n));
    }
    static getWindowLocation() {
        return null == t ? void 0 : t.location;
    }
    static Xe(t) {
        var i;
        if (A(t.conditions) || A(null == (i = t.conditions) ? void 0 : i.utm)) return !0;
        var e = rs();
        if (e.utm_source) {
            var r, s, n, o, a, l, u, h, d = null == (r = t.conditions) || null == (r = r.utm) || !r.utm_campaign || (null == (s = t.conditions) || null == (s = s.utm) ? void 0 : s.utm_campaign) == e.utm_campaign, v = null == (n = t.conditions) || null == (n = n.utm) || !n.utm_source || (null == (o = t.conditions) || null == (o = o.utm) ? void 0 : o.utm_source) == e.utm_source, c = null == (a = t.conditions) || null == (a = a.utm) || !a.utm_medium || (null == (l = t.conditions) || null == (l = l.utm) ? void 0 : l.utm_medium) == e.utm_medium, f = null == (u = t.conditions) || null == (u = u.utm) || !u.utm_term || (null == (h = t.conditions) || null == (h = h.utm) ? void 0 : h.utm_term) == e.utm_term;
            return d && c && f && v;
        }
        return !1;
    }
    static We(t) {
        for(var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++)e[r - 1] = arguments[r];
        $t.info("[WebExperiments] " + t, e);
    }
    Ve(t, i, e) {
        this._is_bot() ? po.We("Refusing to render web experiment since the viewer is a likely bot") : "control" !== i ? e.forEach((e)=>{
            if (e.selector) {
                var r;
                po.We("applying transform of variant " + i + " for experiment " + t + " ", e);
                var s = null == (r = document) ? void 0 : r.querySelectorAll(e.selector);
                null == s || s.forEach((t)=>{
                    var i = t;
                    e.html && (i.innerHTML = e.html), e.css && i.setAttribute("style", e.css);
                });
            }
        }) : po.We("Control variants leave the page unmodified.");
    }
    _is_bot() {
        return n && this._instance ? uo(n, this._instance.config.custom_blocked_useragents) : void 0;
    }
    constructor(t){
        var i = this;
        this.getWebExperimentsAndEvaluateDisplayLogic = function(t) {
            void 0 === t && (t = !1), i.getWebExperiments((t)=>{
                po.We("retrieved web experiments from the server"), i.Ge = new Map, t.forEach((t)=>{
                    if (t.feature_flag_key) {
                        var e;
                        if (i.Ge) po.We("setting flag key ", t.feature_flag_key, " to web experiment ", t), null == (e = i.Ge) || e.set(t.feature_flag_key, t);
                        var r = i._instance.getFeatureFlag(t.feature_flag_key);
                        O(r) && t.variants[r] && i.Ve(t.name, r, t.variants[r].transforms);
                    } else if (t.variants) for(var s in t.variants){
                        var n = t.variants[s];
                        po.Je(n) && i.Ve(t.name, s, n.transforms);
                    }
                });
            }, t);
        }, this._instance = t, this._instance.onFeatureFlags((t)=>{
            this.onFeatureFlags(t);
        });
    }
}
var go = kt("[PostHog ExternalIntegrations]"), _o = {
    intercom: "intercom-integration",
    crispChat: "crisp-chat-integration"
};
class mo {
    nt(t, i) {
        var e;
        null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, t, (t)=>{
            if (t) return go.error("failed to load script", t);
            i();
        });
    }
    startIfEnabledOrStop() {
        var t = this, i = function(i) {
            var e, s, n;
            (!r || null != (e = v.__PosthogExtensions__) && null != (e = e.integrations) && e[i] || t.nt(_o[i], ()=>{
                var e;
                null == (e = v.__PosthogExtensions__) || null == (e = e.integrations) || null == (e = e[i]) || e.start(t._instance);
            }), !r && null != (s = v.__PosthogExtensions__) && null != (s = s.integrations) && s[i]) && (null == (n = v.__PosthogExtensions__) || null == (n = n.integrations) || null == (n = n[i]) || n.stop());
        };
        for (var [e, r] of Object.entries(null !== (s = this._instance.config.integrations) && void 0 !== s ? s : {})){
            var s;
            i(e);
        }
    }
    constructor(t){
        this._instance = t;
    }
}
var yo = "[SessionRecording]", bo = kt(yo);
class wo {
    get started() {
        var t;
        return !(null == (t = this.Qe) || !t.isStarted);
    }
    get status() {
        return this.Qe ? this.Qe.status : this.Ze && !this.tr ? "disabled" : "lazy_loading";
    }
    get tr() {
        var i, e = !(null == (i = this._instance.get_property(ti)) || !i.enabled), r = !this._instance.config.disable_session_recording, s = this._instance.config.disable_session_recording || this._instance.consent.isOptedOut();
        return t && e && r && !s;
    }
    startIfEnabledOrStop(t) {
        var i;
        if (!this.tr || null == (i = this.Qe) || !i.isStarted) {
            var e = !C(Object.assign) && !C(Array.from);
            this.tr && e ? (this.er(t), bo.info("starting")) : this.stopRecording();
        }
    }
    er(t) {
        var i, e, r;
        this.tr && (null != v && null != (i = v.__PosthogExtensions__) && null != (i = i.rrweb) && i.record && null != (e = v.__PosthogExtensions__) && e.initSessionRecording ? this.rr(t) : null == (r = v.__PosthogExtensions__) || null == r.loadExternalDependency || r.loadExternalDependency(this._instance, this.sr, (i)=>{
            if (i) return bo.error("could not load recorder", i);
            this.rr(t);
        }));
    }
    stopRecording() {
        var t, i;
        null == (t = this.ir) || t.call(this), this.ir = void 0, null == (i = this.Qe) || i.stop();
    }
    nr() {
        var t;
        null == (t = this._instance.persistence) || t.unregister(ei);
    }
    ar(t) {
        if (this._instance.persistence) {
            var i, e, r = this._instance.persistence, s = ()=>{
                var i = !1 === t.sessionRecording ? void 0 : t.sessionRecording, e = null == i ? void 0 : i.sampleRate, s = A(e) ? null : parseFloat(e);
                A(s) && this.nr();
                var n = null == i ? void 0 : i.minimumDurationMilliseconds;
                r.register({
                    [ti]: g({
                        enabled: !!i
                    }, i, {
                        networkPayloadCapture: g({
                            capturePerformance: t.capturePerformance
                        }, null == i ? void 0 : i.networkPayloadCapture),
                        canvasRecording: {
                            enabled: null == i ? void 0 : i.recordCanvas,
                            fps: null == i ? void 0 : i.canvasFps,
                            quality: null == i ? void 0 : i.canvasQuality
                        },
                        sampleRate: s,
                        minimumDurationMilliseconds: C(n) ? null : n,
                        endpoint: null == i ? void 0 : i.endpoint,
                        triggerMatchType: null == i ? void 0 : i.triggerMatchType,
                        masking: null == i ? void 0 : i.masking,
                        urlTriggers: null == i ? void 0 : i.urlTriggers
                    })
                });
            };
            s(), null == (i = this.ir) || i.call(this), this.ir = null == (e = this._instance.sessionManager) ? void 0 : e.onSessionId(s);
        }
    }
    onRemoteConfig(t) {
        "sessionRecording" in t ? !1 !== t.sessionRecording ? (this.ar(t), this.Ze = !0, this.startIfEnabledOrStop()) : this.Ze = !0 : bo.info("skipping remote config with no sessionRecording", t);
    }
    log(t, i) {
        var e;
        void 0 === i && (i = "log"), null != (e = this.Qe) && e.log ? this.Qe.log(t, i) : bo.warn("log called before recorder was ready");
    }
    get sr() {
        var t, i, e = null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.get_property(ti);
        return (null == e || null == (i = e.scriptConfig) ? void 0 : i.script) || "lazy-recorder";
    }
    rr(t) {
        var i, e;
        if (null == (i = v.__PosthogExtensions__) || !i.initSessionRecording) throw Error("Called on script loaded before session recording is available");
        this.Qe || (this.Qe = null == (e = v.__PosthogExtensions__) ? void 0 : e.initSessionRecording(this._instance), this.Qe._forceAllowLocalhostNetworkCapture = this._forceAllowLocalhostNetworkCapture);
        this.Qe.start(t);
    }
    onRRwebEmit(t) {
        var i;
        null == (i = this.Qe) || null == i.onRRwebEmit || i.onRRwebEmit(t);
    }
    overrideLinkedFlag() {
        var t;
        null == (t = this.Qe) || t.overrideLinkedFlag();
    }
    overrideSampling() {
        var t;
        null == (t = this.Qe) || t.overrideSampling();
    }
    overrideTrigger(t) {
        var i;
        null == (i = this.Qe) || i.overrideTrigger(t);
    }
    get sdkDebugProperties() {
        var t;
        return (null == (t = this.Qe) ? void 0 : t.sdkDebugProperties) || {
            $recording_status: this.status
        };
    }
    tryAddCustomEvent(t, i) {
        var e;
        return !(null == (e = this.Qe) || !e.tryAddCustomEvent(t, i));
    }
    constructor(t){
        if (this._forceAllowLocalhostNetworkCapture = !1, this.Ze = !1, this.ir = void 0, this._instance = t, !this._instance.sessionManager) throw bo.error("started without valid sessionManager"), new Error(yo + " started without valid sessionManager. This is a bug.");
        if ("always" === this._instance.config.cookieless_mode) throw new Error(yo + ' cannot be used with cookieless_mode="always"');
    }
}
var So = {}, xo = ()=>{}, Eo = "posthog", $o = !en && -1 === (null == d ? void 0 : d.indexOf("MSIE")) && -1 === (null == d ? void 0 : d.indexOf("Mozilla")), ko = (i)=>{
    var e;
    return {
        api_host: "https://us.i.posthog.com",
        ui_host: null,
        token: "",
        autocapture: !0,
        rageclick: !0,
        cross_subdomain_cookie: Ut(null == o ? void 0 : o.location),
        persistence: "localStorage+cookie",
        persistence_name: "",
        loaded: xo,
        save_campaign_params: !0,
        custom_campaign_params: [],
        custom_blocked_useragents: [],
        save_referrer: !0,
        capture_pageview: "2025-05-24" !== i || "history_change",
        capture_pageleave: "if_capture_pageview",
        defaults: null != i ? i : "unset",
        debug: a && O(null == a ? void 0 : a.search) && -1 !== a.search.indexOf("__posthog_debug=true") || !1,
        cookie_expiration: 365,
        upgrade: !1,
        disable_session_recording: !1,
        disable_persistence: !1,
        disable_web_experiments: !0,
        disable_surveys: !1,
        disable_surveys_automatic_display: !1,
        disable_external_dependency_loading: !1,
        enable_recording_console_log: void 0,
        secure_cookie: "https:" === (null == t || null == (e = t.location) ? void 0 : e.protocol),
        ip: !1,
        opt_out_capturing_by_default: !1,
        opt_out_persistence_by_default: !1,
        opt_out_useragent_filter: !1,
        opt_out_capturing_persistence_type: "localStorage",
        consent_persistence_name: null,
        opt_out_capturing_cookie_prefix: null,
        opt_in_site_apps: !1,
        property_denylist: [],
        respect_dnt: !1,
        sanitize_properties: null,
        request_headers: {},
        request_batching: !0,
        properties_string_max_length: 65535,
        session_recording: {},
        mask_all_element_attributes: !1,
        mask_all_text: !1,
        mask_personal_data_properties: !1,
        custom_personal_data_properties: [],
        advanced_disable_flags: !1,
        advanced_disable_decide: !1,
        advanced_disable_feature_flags: !1,
        advanced_disable_feature_flags_on_first_load: !1,
        advanced_only_evaluate_survey_feature_flags: !1,
        advanced_enable_surveys: !1,
        advanced_disable_toolbar_metrics: !1,
        feature_flag_request_timeout_ms: 3e3,
        surveys_request_timeout_ms: 1e4,
        on_request_error: (t)=>{
            var i = "Bad HTTP status: " + t.statusCode + " " + t.text;
            $t.error(i);
        },
        get_device_id: (t)=>t,
        capture_performance: void 0,
        name: "posthog",
        bootstrap: {},
        disable_compression: !1,
        session_idle_timeout_seconds: 1800,
        person_profiles: "identified_only",
        before_send: void 0,
        request_queue_config: {
            flush_interval_ms: Kn
        },
        error_tracking: {},
        _onCapture: xo,
        __preview_eager_load_replay: !1
    };
}, Po = (t)=>{
    var i = {};
    C(t.process_person) || (i.person_profiles = t.process_person), C(t.xhr_headers) || (i.request_headers = t.xhr_headers), C(t.cookie_name) || (i.persistence_name = t.cookie_name), C(t.disable_cookie) || (i.disable_persistence = t.disable_cookie), C(t.store_google) || (i.save_campaign_params = t.store_google), C(t.verbose) || (i.debug = t.verbose);
    var e = Ot({}, i, t);
    return P(t.property_blacklist) && (C(t.property_denylist) ? e.property_denylist = t.property_blacklist : P(t.property_denylist) ? e.property_denylist = [
        ...t.property_blacklist,
        ...t.property_denylist
    ] : $t.error("Invalid value for property_denylist config: " + t.property_denylist)), e;
};
class To {
    get lr() {
        return this.__forceAllowLocalhost;
    }
    set lr(t) {
        $t.error("WebPerformanceObserver is deprecated and has no impact on network capture. Use `_forceAllowLocalhostNetworkCapture` on `posthog.sessionRecording`"), this.__forceAllowLocalhost = t;
    }
    constructor(){
        this.__forceAllowLocalhost = !1;
    }
}
class Io {
    get decideEndpointWasHit() {
        var t, i;
        return null !== (t = null == (i = this.featureFlags) ? void 0 : i.hasLoadedFlags) && void 0 !== t && t;
    }
    get flagsEndpointWasHit() {
        var t, i;
        return null !== (t = null == (i = this.featureFlags) ? void 0 : i.hasLoadedFlags) && void 0 !== t && t;
    }
    init(t, i, e) {
        if (e && e !== Eo) {
            var r, s = null !== (r = So[e]) && void 0 !== r ? r : new Io;
            return s._init(t, i, e), So[e] = s, So[Eo][e] = s, s;
        }
        return this._init(t, i, e);
    }
    _init(i, e, r) {
        var s, n;
        if (void 0 === e && (e = {}), C(i) || F(i)) return $t.critical("PostHog was initialized without a token. This likely indicates a misconfiguration. Please check the first argument passed to posthog.init()"), this;
        if (this.__loaded) return $t.warn("You have already initialized PostHog! Re-initializing is a no-op"), this;
        this.__loaded = !0, this.config = {}, this.gr = e, this._r = [], e.person_profiles && (this.cr = e.person_profiles), this.set_config(Ot({}, ko(e.defaults), Po(e), {
            name: r,
            token: i
        })), this.config.on_xhr_error && $t.error("on_xhr_error is deprecated. Use on_request_error instead"), this.compression = e.disable_compression ? void 0 : ie.GZipJS;
        var o = this.mr();
        this.persistence = new $n(this.config, o), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new $n(g({}, this.config, {
            persistence: "sessionStorage"
        }), o);
        var a = g({}, this.persistence.props), l = g({}, this.sessionPersistence.props);
        this.register({
            $initialization_time: (new Date).toISOString()
        }), this.yr = new Yn((t)=>this.br(t), this.config.request_queue_config), this.wr = new Qn(this), this.__request_queue = [];
        var u = "always" === this.config.cookieless_mode || "on_reject" === this.config.cookieless_mode && this.consent.isExplicitlyOptedOut();
        if (u || (this.sessionManager = new ro(this), this.sessionPropsManager = new io(this, this.sessionManager, this.persistence)), new ir(this).startIfEnabledOrStop(), this.siteApps = new oo(this), null == (s = this.siteApps) || s.init(), u || (this.sessionRecording = new wo(this), this.sessionRecording.startIfEnabledOrStop()), this.config.disable_scroll_properties || this.scrollManager.startMeasuringScrollPosition(), this.autocapture = new ce(this), this.autocapture.startIfEnabled(), this.surveys.loadIfEnabled(), this.heatmaps = new ms(this), this.heatmaps.startIfEnabled(), this.webVitalsAutocapture = new ps(this), this.exceptionObserver = new ze(this), this.exceptionObserver.startIfEnabled(), this.deadClicksAutocapture = new Ne(this, Le), this.deadClicksAutocapture.startIfEnabled(), this.historyAutocapture = new Be(this), this.historyAutocapture.startIfEnabled(), c.DEBUG = c.DEBUG || this.config.debug, c.DEBUG && $t.info("Starting in debug mode", {
            this: this,
            config: e,
            thisC: g({}, this.config),
            p: a,
            s: l
        }), void 0 !== (null == (n = e.bootstrap) ? void 0 : n.distinctID)) {
            var h, d, v = this.config.get_device_id(be()), f = null != (h = e.bootstrap) && h.isIdentifiedID ? v : e.bootstrap.distinctID;
            this.persistence.set_property(di, null != (d = e.bootstrap) && d.isIdentifiedID ? "identified" : "anonymous"), this.register({
                distinct_id: e.bootstrap.distinctID,
                $device_id: f
            });
        }
        if (this.Sr()) {
            var p, _, m = Object.keys((null == (p = e.bootstrap) ? void 0 : p.featureFlags) || {}).filter((t)=>{
                var i;
                return !(null == (i = e.bootstrap) || null == (i = i.featureFlags) || !i[t]);
            }).reduce((t, i)=>{
                var r;
                return t[i] = (null == (r = e.bootstrap) || null == (r = r.featureFlags) ? void 0 : r[i]) || !1, t;
            }, {}), y = Object.keys((null == (_ = e.bootstrap) ? void 0 : _.featureFlagPayloads) || {}).filter((t)=>m[t]).reduce((t, i)=>{
                var r, s;
                null != (r = e.bootstrap) && null != (r = r.featureFlagPayloads) && r[i] && (t[i] = null == (s = e.bootstrap) || null == (s = s.featureFlagPayloads) ? void 0 : s[i]);
                return t;
            }, {});
            this.featureFlags.receivedFeatureFlags({
                featureFlags: m,
                featureFlagPayloads: y
            });
        }
        if (u) this.register_once({
            distinct_id: yi,
            $device_id: null
        }, "");
        else if (!this.get_distinct_id()) {
            var b = this.config.get_device_id(be());
            this.register_once({
                distinct_id: b,
                $device_id: b
            }, ""), this.persistence.set_property(di, "anonymous");
        }
        return Ht(t, "onpagehide" in self ? "pagehide" : "unload", this._handle_unload.bind(this), {
            passive: !1
        }), this.toolbar.maybeLoadToolbar(), e.segment ? We(this, ()=>this.Er()) : this.Er(), T(this.config._onCapture) && this.config._onCapture !== xo && ($t.warn("onCapture is deprecated. Please use `before_send` instead"), this.on("eventCaptured", (t)=>this.config._onCapture(t.event, t))), this.config.ip && $t.warn('The `ip` config option has NO EFFECT AT ALL and has been deprecated. Use a custom transformation or "Discard IP data" project setting instead. See https://posthog.com/tutorials/web-redact-properties#hiding-customer-ip-address for more information.'), this;
    }
    hi(t) {
        var i, e, r, s, n, a, l, u;
        if (!o || !o.body) return $t.info("document not ready yet, trying again in 500 milliseconds..."), void setTimeout(()=>{
            this.hi(t);
        }, 500);
        this.compression = void 0, t.supportedCompression && !this.config.disable_compression && (this.compression = y(t.supportedCompression, ie.GZipJS) ? ie.GZipJS : y(t.supportedCompression, ie.Base64) ? ie.Base64 : void 0), null != (i = t.analytics) && i.endpoint && (this.analyticsDefaultEndpoint = t.analytics.endpoint), this.set_config({
            person_profiles: this.cr ? this.cr : "identified_only"
        }), null == (e = this.siteApps) || e.onRemoteConfig(t), null == (r = this.sessionRecording) || r.onRemoteConfig(t), null == (s = this.autocapture) || s.onRemoteConfig(t), null == (n = this.heatmaps) || n.onRemoteConfig(t), this.surveys.onRemoteConfig(t), null == (a = this.webVitalsAutocapture) || a.onRemoteConfig(t), null == (l = this.exceptionObserver) || l.onRemoteConfig(t), this.exceptions.onRemoteConfig(t), null == (u = this.deadClicksAutocapture) || u.onRemoteConfig(t);
    }
    Er() {
        try {
            this.config.loaded(this);
        } catch (t) {
            $t.critical("`loaded` function failed", t);
        }
        this.$r(), this.config.capture_pageview && setTimeout(()=>{
            (this.consent.isOptedIn() || "always" === this.config.cookieless_mode) && this.kr();
        }, 1), new Jn(this).load(), this.featureFlags.flags();
    }
    $r() {
        var t;
        this.is_capturing() && this.config.request_batching && (null == (t = this.yr) || t.enable());
    }
    _dom_loaded() {
        this.is_capturing() && Rt(this.__request_queue, (t)=>this.br(t)), this.__request_queue = [], this.$r();
    }
    _handle_unload() {
        var t, i;
        this.config.request_batching ? (this.Pr() && this.capture("$pageleave"), null == (t = this.yr) || t.unload(), null == (i = this.wr) || i.unload()) : this.Pr() && this.capture("$pageleave", null, {
            transport: "sendBeacon"
        });
    }
    ui(t) {
        this.__loaded && ($o ? this.__request_queue.push(t) : this.rateLimiter.isServerRateLimited(t.batchKey) || (t.transport = t.transport || this.config.api_transport, t.url = sn(t.url, {
            ip: this.config.ip ? 1 : 0
        }), t.headers = g({}, this.config.request_headers), t.compression = "best-available" === t.compression ? this.compression : t.compression, t.disableXHRCredentials = this.config.__preview_disable_xhr_credentials, this.config.__preview_disable_beacon && (t.disableTransport = [
            "sendBeacon"
        ]), t.fetchOptions = t.fetchOptions || this.config.fetch_options, ((t)=>{
            var i, e, r, s = g({}, t);
            s.timeout = s.timeout || 6e4, s.url = sn(s.url, {
                _: (new Date).getTime().toString(),
                ver: c.LIB_VERSION,
                compression: s.compression
            });
            var n = null !== (i = s.transport) && void 0 !== i ? i : "fetch", o = an.filter((t)=>!s.disableTransport || !t.transport || !s.disableTransport.includes(t.transport)), a = null !== (e = null == (r = zt(o, (t)=>t.transport === n)) ? void 0 : r.method) && void 0 !== e ? e : o[0].method;
            if (!a) throw new Error("No available transport method");
            a(s);
        })(g({}, t, {
            callback: (i)=>{
                var e, r;
                (this.rateLimiter.checkForLimiting(i), i.statusCode >= 400) && (null == (e = (r = this.config).on_request_error) || e.call(r, i));
                null == t.callback || t.callback(i);
            }
        }))));
    }
    br(t) {
        this.wr ? this.wr.retriableRequest(t) : this.ui(t);
    }
    _execute_array(t) {
        var i, e = [], r = [], s = [];
        Rt(t, (t)=>{
            t && (i = t[0], P(i) ? s.push(t) : T(t) ? t.call(this) : P(t) && "alias" === i ? e.push(t) : P(t) && -1 !== i.indexOf("capture") && T(this[i]) ? s.push(t) : r.push(t));
        });
        var n = function(t, i) {
            Rt(t, function(t) {
                if (P(t[0])) {
                    var e = i;
                    Ct(t, function(t) {
                        e = e[t[0]].apply(e, t.slice(1));
                    });
                } else this[t[0]].apply(this, t.slice(1));
            }, i);
        };
        n(e, this), n(r, this), n(s, this);
    }
    Sr() {
        var t, i;
        return (null == (t = this.config.bootstrap) ? void 0 : t.featureFlags) && Object.keys(null == (i = this.config.bootstrap) ? void 0 : i.featureFlags).length > 0 || !1;
    }
    push(t) {
        this._execute_array([
            t
        ]);
    }
    capture(t, i, e) {
        var r;
        if (this.__loaded && this.persistence && this.sessionPersistence && this.yr) {
            if (this.is_capturing()) if (!C(t) && O(t)) {
                if (this.config.opt_out_useragent_filter || !this._is_bot()) {
                    var s = null != e && e.skip_client_rate_limiting ? void 0 : this.rateLimiter.clientRateLimitContext();
                    if (null == s || !s.isRateLimited) {
                        null != i && i.$current_url && !O(null == i ? void 0 : i.$current_url) && ($t.error("Invalid `$current_url` property provided to `posthog.capture`. Input must be a string. Ignoring provided value."), null == i || delete i.$current_url), this.sessionPersistence.update_search_keyword(), this.config.save_campaign_params && this.sessionPersistence.update_campaign_params(), this.config.save_referrer && this.sessionPersistence.update_referrer_info(), (this.config.save_campaign_params || this.config.save_referrer) && this.persistence.set_initial_person_info();
                        var n = new Date, o = (null == e ? void 0 : e.timestamp) || n, a = be(), l = {
                            uuid: a,
                            event: t,
                            properties: this.calculateEventProperties(t, i || {}, o, a)
                        };
                        s && (l.properties.$lib_rate_limit_remaining_tokens = s.remainingTokens), (null == e ? void 0 : e.$set) && (l.$set = null == e ? void 0 : e.$set);
                        var u, h = this.Tr(null == e ? void 0 : e.$set_once);
                        if (h && (l.$set_once = h), (l = Lt(l, null != e && e._noTruncate ? null : this.config.properties_string_max_length)).timestamp = o, C(null == e ? void 0 : e.timestamp) || (l.properties.$event_time_override_provided = !0, l.properties.$event_time_override_system_time = n), t === On.DISMISSED || t === On.SENT) {
                            var d = null == i ? void 0 : i[Fn.SURVEY_ID], v = null == i ? void 0 : i[Fn.SURVEY_ITERATION];
                            u = {
                                id: d,
                                current_iteration: v
                            }, localStorage.getItem(Un(u)) || localStorage.setItem(Un(u), "true"), l.$set = g({}, l.$set, {
                                [Nn({
                                    id: d,
                                    current_iteration: v
                                }, t === On.SENT ? "responded" : "dismissed")]: !0
                            });
                        }
                        var c = g({}, l.properties.$set, l.$set);
                        if (R(c) || this.setPersonPropertiesForFlags(c), !A(this.config.before_send)) {
                            var f = this.Ir(l);
                            if (!f) return;
                            l = f;
                        }
                        this.hr.emit("eventCaptured", l);
                        var p = {
                            method: "POST",
                            url: null !== (r = null == e ? void 0 : e._url) && void 0 !== r ? r : this.requestRouter.endpointFor("api", this.analyticsDefaultEndpoint),
                            data: l,
                            compression: "best-available",
                            batchKey: null == e ? void 0 : e._batchKey
                        };
                        return !this.config.request_batching || e && (null == e || !e._batchKey) || null != e && e.send_instantly ? this.br(p) : this.yr.enqueue(p), l;
                    }
                    $t.critical("This capture call is ignored due to client rate limiting.");
                }
            } else $t.error("No event name provided to posthog.capture");
        } else $t.uninitializedWarning("posthog.capture");
    }
    Ri(t) {
        return this.on("eventCaptured", (i)=>t(i.event, i));
    }
    calculateEventProperties(t, i, e, r, s) {
        if (e = e || new Date, !this.persistence || !this.sessionPersistence) return i;
        var n = s ? void 0 : this.persistence.remove_event_timer(t), a = g({}, i);
        if (a.token = this.config.token, a.$config_defaults = this.config.defaults, ("always" == this.config.cookieless_mode || "on_reject" == this.config.cookieless_mode && this.consent.isExplicitlyOptedOut()) && (a.$cookieless_mode = !0), "$snapshot" === t) {
            var l = g({}, this.persistence.properties(), this.sessionPersistence.properties());
            return a.distinct_id = l.distinct_id, (!O(a.distinct_id) && !j(a.distinct_id) || F(a.distinct_id)) && $t.error("Invalid distinct_id for replay event. This indicates a bug in your implementation"), a;
        }
        var u, h = vs(this.config.mask_personal_data_properties, this.config.custom_personal_data_properties);
        if (this.sessionManager) {
            var { sessionId: v, windowId: c } = this.sessionManager.checkAndGetSessionAndWindowId(s, e.getTime());
            a.$session_id = v, a.$window_id = c;
        }
        this.sessionPropsManager && Ot(a, this.sessionPropsManager.getSessionProps());
        try {
            var f;
            this.sessionRecording && Ot(a, this.sessionRecording.sdkDebugProperties), a.$sdk_debug_retry_queue_size = null == (f = this.wr) ? void 0 : f.length;
        } catch (t) {
            a.$sdk_debug_error_capturing_properties = String(t);
        }
        if (this.requestRouter.region === ho.CUSTOM && (a.$lib_custom_api_host = this.config.api_host), u = "$pageview" !== t || s ? "$pageleave" !== t || s ? this.pageViewManager.doEvent() : this.pageViewManager.doPageLeave(e) : this.pageViewManager.doPageView(e, r), a = Ot(a, u), "$pageview" === t && o && (a.title = o.title), !C(n)) {
            var p = e.getTime() - n;
            a.$duration = parseFloat((p / 1e3).toFixed(3));
        }
        d && this.config.opt_out_useragent_filter && (a.$browser_type = this._is_bot() ? "bot" : "browser"), (a = Ot({}, h, this.persistence.properties(), this.sessionPersistence.properties(), a)).$is_identified = this._isIdentified(), P(this.config.property_denylist) ? Ct(this.config.property_denylist, function(t) {
            delete a[t];
        }) : $t.error("Invalid value for property_denylist config: " + this.config.property_denylist + " or property_blacklist config: " + this.config.property_blacklist);
        var _ = this.config.sanitize_properties;
        _ && ($t.error("sanitize_properties is deprecated. Use before_send instead"), a = _(a, t));
        var m = this.Rr();
        return a.$process_person_profile = m, m && !s && this.Cr("_calculate_event_properties"), a;
    }
    Tr(t) {
        var i;
        if (!this.persistence || !this.Rr()) return t;
        if (this.ur) return t;
        var e = this.persistence.get_initial_props(), r = null == (i = this.sessionPropsManager) ? void 0 : i.getSetOnceProps(), s = Ot({}, e, r || {}, t || {}), n = this.config.sanitize_properties;
        return n && ($t.error("sanitize_properties is deprecated. Use before_send instead"), s = n(s, "$set_once")), this.ur = !0, R(s) ? void 0 : s;
    }
    register(t, i) {
        var e;
        null == (e = this.persistence) || e.register(t, i);
    }
    register_once(t, i, e) {
        var r;
        null == (r = this.persistence) || r.register_once(t, i, e);
    }
    register_for_session(t) {
        var i;
        null == (i = this.sessionPersistence) || i.register(t);
    }
    unregister(t) {
        var i;
        null == (i = this.persistence) || i.unregister(t);
    }
    unregister_for_session(t) {
        var i;
        null == (i = this.sessionPersistence) || i.unregister(t);
    }
    Or(t, i) {
        this.register({
            [t]: i
        });
    }
    getFeatureFlag(t, i) {
        return this.featureFlags.getFeatureFlag(t, i);
    }
    getFeatureFlagPayload(t) {
        var i = this.featureFlags.getFeatureFlagPayload(t);
        try {
            return JSON.parse(i);
        } catch (t) {
            return i;
        }
    }
    isFeatureEnabled(t, i) {
        return this.featureFlags.isFeatureEnabled(t, i);
    }
    reloadFeatureFlags() {
        this.featureFlags.reloadFeatureFlags();
    }
    updateEarlyAccessFeatureEnrollment(t, i, e) {
        this.featureFlags.updateEarlyAccessFeatureEnrollment(t, i, e);
    }
    getEarlyAccessFeatures(t, i, e) {
        return void 0 === i && (i = !1), this.featureFlags.getEarlyAccessFeatures(t, i, e);
    }
    on(t, i) {
        return this.hr.on(t, i);
    }
    onFeatureFlags(t) {
        return this.featureFlags.onFeatureFlags(t);
    }
    onSurveysLoaded(t) {
        return this.surveys.onSurveysLoaded(t);
    }
    onSessionId(t) {
        var i, e;
        return null !== (i = null == (e = this.sessionManager) ? void 0 : e.onSessionId(t)) && void 0 !== i ? i : ()=>{};
    }
    getSurveys(t, i) {
        void 0 === i && (i = !1), this.surveys.getSurveys(t, i);
    }
    getActiveMatchingSurveys(t, i) {
        void 0 === i && (i = !1), this.surveys.getActiveMatchingSurveys(t, i);
    }
    renderSurvey(t, i) {
        this.surveys.renderSurvey(t, i);
    }
    displaySurvey(t, i) {
        void 0 === i && (i = Hn), this.surveys.displaySurvey(t, i);
    }
    canRenderSurvey(t) {
        return this.surveys.canRenderSurvey(t);
    }
    canRenderSurveyAsync(t, i) {
        return void 0 === i && (i = !1), this.surveys.canRenderSurveyAsync(t, i);
    }
    identify(t, i, e) {
        if (!this.__loaded || !this.persistence) return $t.uninitializedWarning("posthog.identify");
        if (j(t) && (t = t.toString(), $t.warn("The first argument to posthog.identify was a number, but it should be a string. It has been converted to a string.")), t) if ([
            "distinct_id",
            "distinctid"
        ].includes(t.toLowerCase())) $t.critical('The string "' + t + '" was set in posthog.identify which indicates an error. This ID should be unique to the user and not a hardcoded string.');
        else if (t !== yi) {
            if (this.Cr("posthog.identify")) {
                var r = this.get_distinct_id();
                if (this.register({
                    $user_id: t
                }), !this.get_property("$device_id")) {
                    var s = r;
                    this.register_once({
                        $had_persisted_distinct_id: !0,
                        $device_id: s
                    }, "");
                }
                t !== r && t !== this.get_property(qt) && (this.unregister(qt), this.register({
                    distinct_id: t
                }));
                var n = "anonymous" === (this.persistence.get_property(di) || "anonymous");
                t !== r && n ? (this.persistence.set_property(di, "identified"), this.setPersonPropertiesForFlags(g({}, e || {}, i || {}), !1), this.capture("$identify", {
                    distinct_id: t,
                    $anon_distinct_id: r
                }, {
                    $set: i || {},
                    $set_once: e || {}
                }), this.pr = un(t, i, e), this.featureFlags.setAnonymousDistinctId(r)) : (i || e) && this.setPersonProperties(i, e), t !== r && (this.reloadFeatureFlags(), this.unregister(hi));
            }
        } else $t.critical('The string "' + yi + '" was set in posthog.identify which indicates an error. This ID is only used as a sentinel value.');
        else $t.error("Unique user id has not been set in posthog.identify");
    }
    setPersonProperties(t, i) {
        if ((t || i) && this.Cr("posthog.setPersonProperties")) {
            var e = un(this.get_distinct_id(), t, i);
            this.pr !== e ? (this.setPersonPropertiesForFlags(g({}, i || {}, t || {})), this.capture("$set", {
                $set: t || {},
                $set_once: i || {}
            }), this.pr = e) : $t.info("A duplicate setPersonProperties call was made with the same properties. It has been ignored.");
        }
    }
    group(t, i, e) {
        if (t && i) {
            if (this.Cr("posthog.group")) {
                var r = this.getGroups();
                r[t] !== i && this.resetGroupPropertiesForFlags(t), this.register({
                    $groups: g({}, r, {
                        [t]: i
                    })
                }), e && (this.capture("$groupidentify", {
                    $group_type: t,
                    $group_key: i,
                    $group_set: e
                }), this.setGroupPropertiesForFlags({
                    [t]: e
                })), r[t] === i || e || this.reloadFeatureFlags();
            }
        } else $t.error("posthog.group requires a group type and group key");
    }
    resetGroups() {
        this.register({
            $groups: {}
        }), this.resetGroupPropertiesForFlags(), this.reloadFeatureFlags();
    }
    setPersonPropertiesForFlags(t, i) {
        void 0 === i && (i = !0), this.featureFlags.setPersonPropertiesForFlags(t, i);
    }
    resetPersonPropertiesForFlags() {
        this.featureFlags.resetPersonPropertiesForFlags();
    }
    setGroupPropertiesForFlags(t, i) {
        void 0 === i && (i = !0), this.Cr("posthog.setGroupPropertiesForFlags") && this.featureFlags.setGroupPropertiesForFlags(t, i);
    }
    resetGroupPropertiesForFlags(t) {
        this.featureFlags.resetGroupPropertiesForFlags(t);
    }
    reset(t) {
        var i, e, r, s;
        if ($t.info("reset"), !this.__loaded) return $t.uninitializedWarning("posthog.reset");
        var n = this.get_property("$device_id");
        if (this.consent.reset(), null == (i = this.persistence) || i.clear(), null == (e = this.sessionPersistence) || e.clear(), this.surveys.reset(), this.featureFlags.reset(), null == (r = this.persistence) || r.set_property(di, "anonymous"), null == (s = this.sessionManager) || s.resetSessionId(), this.pr = null, "always" === this.config.cookieless_mode) this.register_once({
            distinct_id: yi,
            $device_id: null
        }, "");
        else {
            var o = this.config.get_device_id(be());
            this.register_once({
                distinct_id: o,
                $device_id: t ? o : n
            }, "");
        }
        this.register({
            $last_posthog_reset: (new Date).toISOString()
        }, 1);
    }
    get_distinct_id() {
        return this.get_property("distinct_id");
    }
    getGroups() {
        return this.get_property("$groups") || {};
    }
    get_session_id() {
        var t, i;
        return null !== (t = null == (i = this.sessionManager) ? void 0 : i.checkAndGetSessionAndWindowId(!0).sessionId) && void 0 !== t ? t : "";
    }
    get_session_replay_url(t) {
        if (!this.sessionManager) return "";
        var { sessionId: i, sessionStartTimestamp: e } = this.sessionManager.checkAndGetSessionAndWindowId(!0), r = this.requestRouter.endpointFor("ui", "/project/" + this.config.token + "/replay/" + i);
        if (null != t && t.withTimestamp && e) {
            var s, n = null !== (s = t.timestampLookBack) && void 0 !== s ? s : 10;
            if (!e) return r;
            r += "?t=" + Math.max(Math.floor(((new Date).getTime() - e) / 1e3) - n, 0);
        }
        return r;
    }
    alias(t, i) {
        return t === this.get_property(Bt) ? ($t.critical("Attempting to create alias for existing People user - aborting."), -2) : this.Cr("posthog.alias") ? (C(i) && (i = this.get_distinct_id()), t !== i ? (this.Or(qt, t), this.capture("$create_alias", {
            alias: t,
            distinct_id: i
        })) : ($t.warn("alias matches current distinct_id - skipping api call."), this.identify(t), -1)) : void 0;
    }
    set_config(t) {
        var i = g({}, this.config);
        if (I(t)) {
            var e, r, s, n, o;
            Ot(this.config, Po(t));
            var a = this.mr();
            null == (e = this.persistence) || e.update_config(this.config, i, a), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new $n(g({}, this.config, {
                persistence: "sessionStorage"
            }), a), Pe.G() && "true" === Pe.J("ph_debug") && (this.config.debug = !0), this.config.debug && (c.DEBUG = !0, $t.info("set_config", {
                config: t,
                oldConfig: i,
                newConfig: g({}, this.config)
            })), null == (r = this.sessionRecording) || r.startIfEnabledOrStop(), null == (s = this.autocapture) || s.startIfEnabled(), null == (n = this.heatmaps) || n.startIfEnabled(), this.surveys.loadIfEnabled(), this.Fr(), null == (o = this.externalIntegrations) || o.startIfEnabledOrStop();
        }
    }
    startSessionRecording(t) {
        var i = !0 === t, e = {
            sampling: i || !(null == t || !t.sampling),
            linked_flag: i || !(null == t || !t.linked_flag),
            url_trigger: i || !(null == t || !t.url_trigger),
            event_trigger: i || !(null == t || !t.event_trigger)
        };
        if (Object.values(e).some(Boolean)) {
            var r, s, n, o, a;
            if (null == (r = this.sessionManager) || r.checkAndGetSessionAndWindowId(), e.sampling) null == (s = this.sessionRecording) || s.overrideSampling();
            if (e.linked_flag) null == (n = this.sessionRecording) || n.overrideLinkedFlag();
            if (e.url_trigger) null == (o = this.sessionRecording) || o.overrideTrigger("url");
            if (e.event_trigger) null == (a = this.sessionRecording) || a.overrideTrigger("event");
        }
        this.set_config({
            disable_session_recording: !1
        });
    }
    stopSessionRecording() {
        this.set_config({
            disable_session_recording: !0
        });
    }
    sessionRecordingStarted() {
        var t;
        return !(null == (t = this.sessionRecording) || !t.started);
    }
    captureException(t, i) {
        var e = new Error("PostHog syntheticException"), r = this.exceptions.buildProperties(t, {
            handled: !0,
            syntheticException: e
        });
        return this.exceptions.sendExceptionEvent(g({}, r, i));
    }
    loadToolbar(t) {
        return this.toolbar.loadToolbar(t);
    }
    get_property(t) {
        var i;
        return null == (i = this.persistence) ? void 0 : i.props[t];
    }
    getSessionProperty(t) {
        var i;
        return null == (i = this.sessionPersistence) ? void 0 : i.props[t];
    }
    toString() {
        var t, i = null !== (t = this.config.name) && void 0 !== t ? t : Eo;
        return i !== Eo && (i = Eo + "." + i), i;
    }
    _isIdentified() {
        var t, i;
        return "identified" === (null == (t = this.persistence) ? void 0 : t.get_property(di)) || "identified" === (null == (i = this.sessionPersistence) ? void 0 : i.get_property(di));
    }
    Rr() {
        var t, i;
        return !("never" === this.config.person_profiles || "identified_only" === this.config.person_profiles && !this._isIdentified() && R(this.getGroups()) && (null == (t = this.persistence) || null == (t = t.props) || !t[qt]) && (null == (i = this.persistence) || null == (i = i.props) || !i[_i]));
    }
    Pr() {
        return !0 === this.config.capture_pageleave || "if_capture_pageview" === this.config.capture_pageleave && (!0 === this.config.capture_pageview || "history_change" === this.config.capture_pageview);
    }
    createPersonProfile() {
        this.Rr() || this.Cr("posthog.createPersonProfile") && this.setPersonProperties({}, {});
    }
    Cr(t) {
        return "never" === this.config.person_profiles ? ($t.error(t + ' was called, but process_person is set to "never". This call will be ignored.'), !1) : (this.Or(_i, !0), !0);
    }
    mr() {
        if ("always" === this.config.cookieless_mode) return !0;
        var t = this.consent.isOptedOut(), i = this.config.opt_out_persistence_by_default || "on_reject" === this.config.cookieless_mode;
        return this.config.disable_persistence || t && !!i;
    }
    Fr() {
        var t, i, e, r, s = this.mr();
        (null == (t = this.persistence) ? void 0 : t.gi) !== s && (null == (e = this.persistence) || e.set_disabled(s));
        (null == (i = this.sessionPersistence) ? void 0 : i.gi) !== s && (null == (r = this.sessionPersistence) || r.set_disabled(s));
        return s;
    }
    opt_in_capturing(t) {
        if ("always" !== this.config.cookieless_mode) {
            var i, e;
            if ("on_reject" === this.config.cookieless_mode && this.consent.isExplicitlyOptedOut()) this.reset(!0), null == (i = this.sessionManager) || i.destroy(), this.sessionManager = new ro(this), this.persistence && (this.sessionPropsManager = new io(this, this.sessionManager, this.persistence)), this.sessionRecording = new wo(this), this.sessionRecording.startIfEnabledOrStop();
            if (this.consent.optInOut(!0), this.Fr(), this.$r(), "on_reject" == this.config.cookieless_mode && this.surveys.loadIfEnabled(), C(null == t ? void 0 : t.captureEventName) || null != t && t.captureEventName) this.capture(null !== (e = null == t ? void 0 : t.captureEventName) && void 0 !== e ? e : "$opt_in", null == t ? void 0 : t.captureProperties, {
                send_instantly: !0
            });
            this.config.capture_pageview && this.kr();
        } else $t.warn('Consent opt in/out is not valid with cookieless_mode="always" and will be ignored');
    }
    opt_out_capturing() {
        var t, i;
        "always" !== this.config.cookieless_mode ? ("on_reject" === this.config.cookieless_mode && this.consent.isOptedIn() && this.reset(!0), this.consent.optInOut(!1), this.Fr(), "on_reject" === this.config.cookieless_mode && (this.register({
            distinct_id: yi,
            $device_id: null
        }), null == (t = this.sessionManager) || t.destroy(), this.sessionManager = void 0, this.sessionPropsManager = void 0, null == (i = this.sessionRecording) || i.stopRecording(), this.sessionRecording = void 0, this.kr())) : $t.warn('Consent opt in/out is not valid with cookieless_mode="always" and will be ignored');
    }
    has_opted_in_capturing() {
        return this.consent.isOptedIn();
    }
    has_opted_out_capturing() {
        return this.consent.isOptedOut();
    }
    get_explicit_consent_status() {
        var t = this.consent.consent;
        return t === Me.GRANTED ? "granted" : t === Me.DENIED ? "denied" : "pending";
    }
    is_capturing() {
        return "always" === this.config.cookieless_mode || ("on_reject" === this.config.cookieless_mode ? this.consent.isExplicitlyOptedOut() || this.consent.isOptedIn() : !this.has_opted_out_capturing());
    }
    clear_opt_in_out_capturing() {
        this.consent.reset(), this.Fr();
    }
    _is_bot() {
        return n ? uo(n, this.config.custom_blocked_useragents) : void 0;
    }
    kr() {
        o && ("visible" === o.visibilityState ? this.dr || (this.dr = !0, this.capture("$pageview", {
            title: o.title
        }, {
            send_instantly: !0
        }), this.vr && (o.removeEventListener("visibilitychange", this.vr), this.vr = null)) : this.vr || (this.vr = this.kr.bind(this), Ht(o, "visibilitychange", this.vr)));
    }
    debug(i) {
        !1 === i ? (null == t || t.console.log("You've disabled debug mode."), localStorage && localStorage.removeItem("ph_debug"), this.set_config({
            debug: !1
        })) : (null == t || t.console.log("You're now in debug mode. All calls to PostHog will be logged in your console.\nYou can disable this with `posthog.debug(false)`."), localStorage && localStorage.setItem("ph_debug", "true"), this.set_config({
            debug: !0
        }));
    }
    L() {
        var t, i, e, r, s, n, o, a = this.gr || {};
        return "advanced_disable_flags" in a ? !!a.advanced_disable_flags : !1 !== this.config.advanced_disable_flags ? !!this.config.advanced_disable_flags : !0 === this.config.advanced_disable_decide ? ($t.warn("Config field 'advanced_disable_decide' is deprecated. Please use 'advanced_disable_flags' instead. The old field will be removed in a future major version."), !0) : (e = "advanced_disable_decide", r = !1, s = $t, n = (i = "advanced_disable_flags") in (t = a) && !C(t[i]), o = e in t && !C(t[e]), n ? t[i] : o ? (s && s.warn("Config field '" + e + "' is deprecated. Please use '" + i + "' instead. The old field will be removed in a future major version."), t[e]) : r);
    }
    Ir(t) {
        if (A(this.config.before_send)) return t;
        var i = P(this.config.before_send) ? this.config.before_send : [
            this.config.before_send
        ], e = t;
        for (var r of i){
            if (e = r(e), A(e)) {
                var s = "Event '" + t.event + "' was rejected in beforeSend function";
                return N(t.event) ? $t.warn(s + ". This can cause unexpected behavior.") : $t.info(s), null;
            }
            e.properties && !R(e.properties) || $t.warn("Event '" + t.event + "' has no properties after beforeSend function, this is likely an error.");
        }
        return e;
    }
    getPageViewId() {
        var t;
        return null == (t = this.pageViewManager.Wt) ? void 0 : t.pageViewId;
    }
    captureTraceFeedback(t, i) {
        this.capture("$ai_feedback", {
            $ai_trace_id: String(t),
            $ai_feedback_text: i
        });
    }
    captureTraceMetric(t, i, e) {
        this.capture("$ai_metric", {
            $ai_trace_id: String(t),
            $ai_metric_name: i,
            $ai_metric_value: String(e)
        });
    }
    constructor(){
        this.webPerformance = new To, this.ur = !1, this.version = c.LIB_VERSION, this.hr = new An, this._calculate_event_properties = this.calculateEventProperties.bind(this), this.config = ko(), this.SentryIntegration = Je, this.sentryIntegration = (t)=>(function(t, i) {
                var e = Ve(t, i);
                return {
                    name: Ge,
                    processEvent: (t)=>e(t)
                };
            })(this, t), this.__request_queue = [], this.__loaded = !1, this.analyticsDefaultEndpoint = "/e/", this.dr = !1, this.vr = null, this.cr = null, this.pr = null, this.featureFlags = new xn(this), this.toolbar = new Ze(this), this.scrollManager = new Zn(this), this.pageViewManager = new ys(this), this.surveys = new qn(this), this.experiments = new po(this), this.exceptions = new cn(this), this.rateLimiter = new Gn(this), this.requestRouter = new co(this), this.consent = new Ae(this), this.externalIntegrations = new mo(this), this.people = {
            set: (t, i, e)=>{
                var r = O(t) ? {
                    [t]: i
                } : t;
                this.setPersonProperties(r), null == e || e({});
            },
            set_once: (t, i, e)=>{
                var r = O(t) ? {
                    [t]: i
                } : t;
                this.setPersonProperties(void 0, r), null == e || e({});
            }
        }, this.on("eventCaptured", (t)=>$t.info('send "' + (null == t ? void 0 : t.event) + '"', t));
    }
}
!function(t, i) {
    for(var e = 0; e < i.length; e++)t.prototype[i[e]] = jt(t.prototype[i[e]]);
}(Io, [
    "identify"
]);
var Ro, Co = (Ro = So[Eo] = new Io, function() {
    function i() {
        i.done || (i.done = !0, $o = !1, Ct(So, function(t) {
            t._dom_loaded();
        }));
    }
    null != o && o.addEventListener ? "complete" === o.readyState ? i() : Ht(o, "DOMContentLoaded", i, {
        capture: !1
    }) : t && $t.error("Browser doesn't support `document.addEventListener` so PostHog couldn't be initialized");
}(), Ro);
;
 //# sourceMappingURL=module.js.map
}),
]);

//# sourceMappingURL=node_modules__pnpm_7e637811._.js.map