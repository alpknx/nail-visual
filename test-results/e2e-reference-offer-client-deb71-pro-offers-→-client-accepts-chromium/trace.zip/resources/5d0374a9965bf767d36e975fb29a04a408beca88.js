(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_src_app_globals_ea8a3ee7.css",
  "static/chunks/node_modules__pnpm_7e637811._.js",
  "static/chunks/apps_web_src_32e46a39._.js"
],
    source: "dynamic"
});
