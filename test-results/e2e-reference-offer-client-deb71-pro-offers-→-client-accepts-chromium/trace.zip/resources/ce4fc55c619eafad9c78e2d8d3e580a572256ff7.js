(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_4abb051b._.js",
  "static/chunks/apps_web_src_3227c635._.js"
],
    source: "dynamic"
});
